# Ephemeral Identity Sandbox (EIS) — Architecture & Dependency Map

> **Purpose:** This file serves as a "memory" document that maps all module boundaries,
> file-level dependencies, data flows, and interface contracts. Use it to understand
> how changes in one file propagate to others.

---

## 1. Project Directory Structure

```
Sandbox_Android/
├── build.gradle.kts                          # Root build config (AGP + Kotlin plugins)
├── settings.gradle.kts                       # Project/module settings
├── gradle.properties                         # JVM & Android build properties
├── ARCHITECTURE.md                           # ← This file
│
└── app/
    ├── build.gradle.kts                      # App module build (deps, SDK versions)
    ├── proguard-rules.pro                    # ProGuard keep rules
    │
    └── src/main/
        ├── AndroidManifest.xml               # App manifest (permissions, components)
        ├── assets/
        │   └── mutation_payload.js           # Module 3: JS mutation payload
        ├── res/
        │   ├── drawable/                     # Vector drawables (icons, UI assets)
        │   ├── layout/
        │   │   ├── activity_main.xml         # Main browser UI layout
        │   │   └── item_console_log.xml      # Dev console log entry card
        │   ├── values/                       # Colors, strings, themes
        │   └── xml/
        │       ├── network_security_config.xml  # DoH trust anchors
        │       └── data_extraction_rules.xml    # No-backup policy
        │
        └── java/io/bandekar/eis/
            ├── EISApplication.kt             # Application class (entry point)
            ├── MainActivity.kt               # Main activity (UI orchestrator)
            ├── lifecycle/
            │   └── SessionLifecycleManager.kt # Module 1: State Controller
            ├── entropy/
            │   └── EntropyEngine.kt          # Module 2: Entropy Genesis Engine
            ├── network/
            │   ├── IntentFirewallWebViewClient.kt  # Module 4: Intent Firewall
            │   └── DohClient.kt                    # Module 4: DoH Resolver
            └── crash/
                ├── CrashHandler.kt           # Module 5: Kotlin Crash Handler
                ├── JsConsoleDatabase.kt      # Module 5: JS Console Capture
                └── WebViewErrorLogger.kt     # Module 5: WebView Error Logging
```

---

## 2. Module-to-File Mapping

| Module | Description | Files |
|--------|-------------|-------|
| **M1** | State Controller (Lifecycle) | `SessionLifecycleManager.kt` |
| **M2** | Entropy Genesis Engine | `EntropyEngine.kt` |
| **M3** | JS Mutation Middleware | `mutation_payload.js` |
| **M4** | Network Security Gateway | `IntentFirewallWebViewClient.kt`, `DohClient.kt` |
| **M5** | Crash Logic & Observability | `CrashHandler.kt`, `JsConsoleDatabase.kt`, `WebViewErrorLogger.kt` |
| — | Application Bootstrap | `EISApplication.kt` |
| — | UI Orchestrator | `MainActivity.kt`, `activity_main.xml`, `item_console_log.xml`, all drawables |

---

## 3. File Dependency Graph (Import Map)

```
Legend:
  ──→  "imports / depends on"
  - - →  "uses at runtime (not via import)"
  ⇄    bidirectional relationship

┌─────────────────────────────────────────────────────────────────────┐
│                        EISApplication.kt                           │
│  ──→ CrashHandler.kt          (installs crash handler)             │
│  ──→ EntropyEngine.kt         (generates initial seed)             │
└─────────────────────────────────────────────────────────────────────┘
                               │
                               │ onCreate()
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        MainActivity.kt                             │
│                                                                     │
│  DEPENDENCIES (imports):                                            │
│  ──→ SessionLifecycleManager.kt  (lifecycle control)               │
│  ──→ IntentFirewallWebViewClient.kt  (WebView client)              │
│  ──→ JsConsoleDatabase.kt       (dev console logs)                 │
│  ──→ EntropyEngine.kt           (qualified ref: inject JS entropy) │
│  ──→ ActivityMainBinding         (generated view binding)          │
│                                                                     │
│  RUNTIME CONNECTIONS:                                               │
│  - - → assets/mutation_payload.js  (loaded as raw string)          │
│  - - → R.layout.item_console_log   (via ConsoleLogAdapter)         │
│                                                                     │
│  CALLBACKS REGISTERED:                                              │
│  ──→ SessionLifecycleManager.setRebuildCallback { rebuildWebView() }│
│  ──→ IntentFirewallWebViewClient(onRenderProcessGoneCallback = …)  │
│                                                                     │
│  INNER CLASS:                                                       │
│  ConsoleLogAdapter ──→ JsConsoleDatabase.LogEntry                  │
│  ConsoleLogAdapter ──→ R.layout.item_console_log                   │
└─────────────────────────────────────────────────────────────────────┘
       │              │              │              │
       │ onCreate()   │ setOnClick   │ purgeSession │ onConsoleMessage
       ▼              ▼              ▼              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   SessionLifecycleManager.kt  (M1)                  │
│                                                                     │
│  DEPENDENCIES (imports):                                            │
│  ──→ EntropyEngine.kt         (calls regenerateSeed on purge)      │
│  ──→ android.webkit.*         (CookieManager, WebStorage, WebView)  │
│                                                                     │
│  PUBLIC API:                                                        │
│  • registerWebView(WebView)          ← MainActivity                │
│  • setRebuildCallback(callback)      ← MainActivity                │
│  • purgeSession()                    ← MainActivity (button click)  │
│                                                                     │
│  DATA FLOW:                                                         │
│  purgeSession() → CookieManager.removeAllCookies()                  │
│                 → WebStorage.deleteAllData()                        │
│                 → WebView.clearCache()                              │
│                 → WebView.clearHistory()                            │
│                 → EntropyEngine.regenerateSeed()                    │
│                 → WebView.destroy()                                 │
│                 → rebuildCallback.onRebuildRequired() → MainActivity│
└─────────────────────────────────────────────────────────────────────┘
       │
       │ regenerateSeed()
       ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     EntropyEngine.kt  (M2)                          │
│                                                                     │
│  DEPENDENCIES: NONE (pure Kotlin + SecureRandom)                   │
│                                                                     │
│  EXPOSED STATE:                                                     │
│  • canvasRNoise: Int  (–1, 0, or +1)                               │
│  • canvasGNoise: Int  (–1, 0, or +1)                               │
│  • canvasBNoise: Int  (–1, 0, or +1)                               │
│  • audioFreqShift: Int  (–10 to +10)                               │
│  • normalizeUserAgent: Boolean                                      │
│  • getCurrentSeed(): ByteArray?  (32 bytes = 256 bits)              │
│                                                                     │
│  PUBLIC API:                                                        │
│  • regenerateSeed()          ← SessionLifecycleManager              │
│                              ← EISApplication (initial)             │
│  • toJsEntropyObject(): String                                      │
│                              ← IntentFirewallWebViewClient          │
│                              ← MainActivity (rebuild injection)     │
│                                                                     │
│  DERIVATION: Byte[0..2] → RGB noise (mod 3: 0→-1, 1→0, 2→+1)      │
│               Byte[3..4] → Audio shift (mod 21, offset -10)        │
│               Byte[5]    → UA normalize flag (bit 0 parity)         │
└─────────────────────────────────────────────────────────────────────┘
       │
       │ toJsEntropyObject() → injected as __EIS_ENTROPY__
       ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   IntentFirewallWebViewClient.kt  (M4)              │
│                                                                     │
│  DEPENDENCIES (imports):                                            │
│  ──→ WebViewErrorLogger.kt    (logs blocks, errors, crashes)       │
│  ──→ EntropyEngine.kt         (reads entropy for JS injection)     │
│  ──→ android.webkit.*         (WebViewClient, WebResourceRequest)   │
│                                                                     │
│  CONSTRUCTOR PARAMETERS:                                            │
│  • mutationPayload: String     ← MainActivity (loaded from assets)  │
│  • onRenderProcessGoneCallback: (() → Unit)? ← MainActivity         │
│                                                                     │
│  WEBVIEW LIFECYCLE HOOKS:                                           │
│  • onPageStarted() → injectEntropyAndMutationPayload()              │
│  • shouldOverrideUrlLoading() → BLOCK non-http/https                │
│  • onReceivedError() → WebViewErrorLogger.logWebViewError()        │
│  • onReceivedHttpError() → WebViewErrorLogger.logHttpError()       │
│  • onRenderProcessGone() → WebViewErrorLogger.logRenderProcessCrash│
│                          → callback?.invoke() → MainActivity rebuild│
│                                                                     │
│  JS INJECTION FLOW:                                                 │
│  1. EntropyEngine.toJsEntropyObject()                               │
│  2. eval("window.__EIS_ENTROPY__ = {...}")                          │
│  3. eval(mutationPayload)  ← assets/mutation_payload.js            │
└─────────────────────────────────────────────────────────────────────┘
       │
       │ native→JS bridge
       ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   assets/mutation_payload.js  (M3)                  │
│                                                                     │
│  INPUT:  window.__EIS_ENTROPY__  (set by IntentFirewallWebViewClient)│
│  OUTPUT: Overrides browser APIs for fingerprinting protection        │
│                                                                     │
│  SECTIONS:                                                          │
│  1. Canvas Spoofing:                                                │
│     - Override HTMLCanvasElement.prototype.getContext               │
│     - Wrap CanvasRenderingContext2D.prototype.getImageData          │
│       → apply ±1 RGB noise to pixel array                          │
│     - Override HTMLCanvasElement.prototype.toDataURL                │
│       → read pixels → apply noise → put back → encode              │
│                                                                     │
│  2. Audio Spoofing:                                                 │
│     - Override AudioContext.prototype.createOscillator              │
│     → inject frequency shift (±0.1 Hz × audioFreqShift)            │
│       on connect() or start()                                       │
│                                                                     │
│  3. User-Agent Normalization:                                       │
│     - Strips build identifiers (Build/XXXXX.XXX)                    │
│     - Normalizes AppleWebKit/Chrome/Safari/Version patch numbers    │
│     - Overrides navigator.userAgent via Object.defineProperty       │
│                                                                     │
│  4. WebRTC Leak Prevention:                                         │
│     - Sets RTCPeerConnection / webkitRTCPeerConnection = undefined  │
│                                                                     │
│  SIGNAL: console.info('[EIS] Identity mutation payload applied.')   │
│          → captured by WebChromeClient.onConsoleMessage()           │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                      DohClient.kt  (M4)                             │
│                                                                     │
│  DEPENDENCIES: okhttp3, okhttp3.dnsoverhttps                        │
│  PROJECT DEPS: NONE (standalone utility)                            │
│                                                                     │
│  PUBLIC API:                                                        │
│  • createDohEnabledClient(): OkHttpClient                           │
│                                                                     │
│  DNS CHAIN:                                                         │
│  1. Cloudflare (1.1.1.1) DoH  ── primary                           │
│  2. Quad9 (9.9.9.9) DoH       ── fallback                          │
│  3. System DNS                 ── final fallback                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                     CrashHandler.kt  (M5)                           │
│                                                                     │
│  DEPENDENCIES: NONE (pure Android SDK)                             │
│                                                                     │
│  CONSTRUCTOR: Context (application context)                         │
│                                                                     │
│  PUBLIC API:                                                        │
│  • install()                        ← EISApplication.onCreate()    │
│  • uncaughtException(thread, throw) ← system (Thread.setDefault)   │
│                                                                     │
│  OUTPUT: writes crashes.txt to Context.getExternalFilesDir(null)    │
│  ROTATION: 1MB max → renames to crashes_old.txt                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                   JsConsoleDatabase.kt  (M5)                        │
│                                                                     │
│  DEPENDENCIES: NONE (pure Kotlin)                                  │
│                                                                     │
│  INTERNAL STATE: In-memory rolling list (max 500 entries)           │
│                                                                     │
│  PUBLIC API:                                                        │
│  • addLogEntry(level, msg, source, line) ← MainActivity            │
│  • getAllEntries(): List<LogEntry>       ← MainActivity             │
│  • clearLogs()                           ← (for future use)         │
│                                                                     │
│  LogEntry data class: timestamp, level, message, sourceId, lineNo   │
│                                                                     │
│  FILTER: Only ERROR and WARNING levels captured                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                   WebViewErrorLogger.kt  (M5)                       │
│                                                                     │
│  DEPENDENCIES: NONE (pure Android Log)                             │
│                                                                     │
│  PUBLIC API (all static):                                           │
│  • logNavigationBlocked(uri, scheme)  ← IntentFirewallWebViewClient │
│  • logWebViewError(url, code, desc)   ← IntentFirewallWebViewClient │
│  • logHttpError(url, code, phrase)    ← IntentFirewallWebViewClient │
│  • logRenderProcessCrash(crashed, pri)← IntentFirewallWebViewClient │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 4. Data Flow Diagrams

### 4.1 Session Purge Flow (User clicks "New Identity")

```
User taps [New Identity]
       │
       ▼
MainActivity.purgeButton.setOnClickListener
       │
       ▼
SessionLifecycleManager.purgeSession()       [Main Thread]
       │
       ├── CookieManager.removeAllCookies()      → Wipes cookies
       ├── WebStorage.deleteAllData()            → Wipes localStorage, IndexedDB
       ├── webView.clearCache(true)              → Wipes HTTP cache
       ├── webView.clearHistory()               → Wipes navigation history
       ├── EntropyEngine.regenerateSeed()        → New 256-bit crypto seed
       │       ├── canvasRNoise = ±1
       │       ├── canvasGNoise = ±1
       │       ├── canvasBNoise = ±1
       │       ├── audioFreqShift = -10..+10
       │       └── normalizeUserAgent = true/false
       ├── webView.destroy()
       └── rebuildCallback.onRebuildRequired()
               │
               ▼
       MainActivity.rebuildWebView()
               │
               ├── createConfiguredWebView()     → New WebView with all settings
               ├── sessionLifecycleManager.registerWebView(newWV)
               ├── injectEntropyAndLoad()        → Sets window.__EIS_ENTROPY__
               └── Console: "WebView rebuilt with fresh identity."
```

### 4.2 Page Load & JS Injection Flow

```
WebView.loadUrl("https://example.com")
       │
       ▼
IntentFirewallWebViewClient.shouldOverrideUrlLoading()
       │
       ├── Scheme == http/https? → allow (return false)
       └── Scheme == anything else → BLOCK (return true)
               │
               ▼
IntentFirewallWebViewClient.onPageStarted(url)
       │
       ▼
injectEntropyAndMutationPayload(webView)
       │
       ├── eval("window.__EIS_ENTROPY__ = {canvasRNoise:…}")
       │       ← EntropyEngine.toJsEntropyObject()
       │
       └── eval(mutationPayload)  ← assets/mutation_payload.js
               │
               ├── CanvasRenderingContext2D.getImageData wrapped
               ├── HTMLCanvasElement.toDataURL wrapped
               ├── AudioContext.createOscillator wrapped
               ├── navigator.userAgent normalized
               └── RTCPeerConnection disabled
```

### 4.3 Render Process Crash Flow

```
WebView render process crashes
       │
       ▼
IntentFirewallWebViewClient.onRenderProcessGone(view, detail)
       │
       ├── WebViewErrorLogger.logRenderProcessCrash(crashed, priority)
       └── onRenderProcessGoneCallback?.invoke()
               │
               ▼
       MainActivity (runOnUiThread)
               │
               ├── rebuildWebView()        → fresh WebView instance
               └── webView.loadUrl(DEFAULT_URL)
```

### 4.4 JS Console Capture Flow

```
Website / Injected JS calls console.error("…") or console.warn("…")
       │
       ▼
WebChromeClient.onConsoleMessage(message)
       │
       ├── message.messageLevel() == ERROR or WARNING?
       │       ▼ Yes
       │   JsConsoleDatabase.addLogEntry(level, msg, source, line)
       │       ▼ (if dev console visible)
       │   MainActivity.refreshConsoleLogs()
       │       ▼
       │   ConsoleLogAdapter.updateEntries(entries)
       └── else→ ignore DEBUG, LOG, TIP
```

---

## 5. Interface Contracts / Callbacks

| Interface / Callback | Defined In | Implemented By | Purpose |
|----------------------|-----------|----------------|---------|
| `WebViewRebuildCallback` | `SessionLifecycleManager` | `MainActivity` (lambda) | Signals WebView needs recreation after purge |
| `onRenderProcessGoneCallback` | `IntentFirewallWebViewClient` (constructor) | `MainActivity` (lambda) | Signals WebView renderer crashed, needs rebuild |
| `Thread.UncaughtExceptionHandler` | Android SDK | `CrashHandler` | Catches all unhandled Kotlin exceptions |
| `WebViewClient` overrides | Android SDK | `IntentFirewallWebViewClient` | URL loading, error handling, render crashes |
| `WebChromeClient` overrides | Android SDK | Anonymous class in `MainActivity` | Progress, title, console messages |
| `__EIS_ENTROPY__` (JS bridge) | `mutation_payload.js` (reader) | `IntentFirewallWebViewClient` (writer) | Passes entropy values from native → JS |

---

## 6. Configuration / Resource Dependencies

### AndroidManifest.xml references:
- `.EISApplication` (application class)
- `.MainActivity` (launcher activity)
- `@xml/network_security_config` (DoH trust)
- `@xml/data_extraction_rules` (backup policy)
- `@drawable/ic_launcher_foreground` (app icon)
- `@string/app_name` (label)
- `@style/Theme.EIS` (theme)

### activity_main.xml references:
| Widget ID | Connects To | Purpose |
|-----------|------------|---------|
| `toolbar` | `binding.toolbar` | Title bar (updated by WebChromeClient) |
| `urlEditText` | `binding.urlEditText` | URL input field |
| `goButton` | `binding.goButton` | Load URL action |
| `progressBar` | `binding.progressBar` | Page load progress |
| `webViewContainer` | `binding.webViewContainer` | WebView parent frame |
| `backButton` | `binding.backButton` | Go back in history |
| `forwardButton` | `binding.forwardButton` | Go forward in history |
| `purgeButton` | `binding.purgeButton` | Trigger session purge |
| `devLogsButton` | `binding.devLogsButton` | Toggle dev console |
| `devConsolePanel` | `binding.devConsolePanel` | Dev console container |
| `devLogsRecyclerView` | `binding.devLogsRecyclerView` | Log entries list |
| `emptyLogsText` | `binding.emptyLogsText` | Empty state message |
| `closeDevConsole` | `binding.closeDevConsole` | Hide dev console |

### item_console_log.xml references:
| Widget ID | Connects To | Purpose |
|-----------|------------|---------|
| `logMessage` | `LogViewHolder.messageView` | Log message text (monospace) |
| `logLevel` | `LogViewHolder.levelView` | Severity badge (ERROR/WARNING) |
| `logSource` | `LogViewHolder.sourceView` | Source file:line number |

---

## 7. Build Dependencies (app/build.gradle.kts)

| Dependency | Version | Used By |
|-----------|---------|---------|
| `androidx.core:core-ktx` | 1.12.0 | EISApplication, ViewBinding |
| `androidx.appcompat:appcompat` | 1.6.1 | Theme, AppCompatActivity |
| `com.google.android.material:material` | 1.11.0 | BottomAppBar, Snackbar, Toolbar, CardView |
| `androidx.constraintlayout:constraintlayout` | 2.1.4 | activity_main.xml layout |
| `androidx.activity:activity-ktx` | 1.8.2 | enableEdgeToEdge, Activity result |
| `androidx.lifecycle:lifecycle-runtime-ktx` | 2.7.0 | Lifecycle-aware coroutines (future) |
| `androidx.lifecycle:lifecycle-viewmodel-ktx` | 2.7.0 | ViewModel support (future) |
| `androidx.webkit:webkit` | 1.10.0 | WebSettingsCompat, WebViewFeature (FORCE_DARK) |
| `com.squareup.okhttp3:okhttp` | 4.12.0 | DohClient HTTP client |
| `com.squareup.okhttp3:okhttp-dnsoverhttps` | 4.12.0 | DnsOverHttps resolver |

---

## 8. Thread Safety Map

| Component | Must Run On | Reason |
|-----------|------------|--------|
| `SessionLifecycleManager.purgeSession()` | **Main Thread** | Calls WebView.destroy(), CookieManager, WebStorage |
| `IntentFirewallWebViewClient.*` | **Main Thread** | All WebViewClient callbacks are main-thread |
| `WebView.evaluateJavascript()` | **Main Thread** | WebView method requirement |
| `MainActivity.rebuildWebView()` | **Main Thread** | Creates/destroys WebView |
| `EntropyEngine.regenerateSeed()` | **Any Thread** | SecureRandom is thread-safe |
| `EntropyEngine.toJsEntropyObject()` | **Any Thread** | @Volatile reads only |
| `JsConsoleDatabase.*` | **Any Thread** | Synchronized on internal list |
| `CrashHandler.uncaughtException()` | **Any Thread** | System-invoked; writes to file |
| `DohClient.createDohEnabledClient()` | **Any Thread** | OkHttp thread-safe |

---

## 9. Change Impact Analysis

When modifying a file, here is the cascade of files that may need changes:

| File Changed | Check/Update These Files |
|-------------|------------------------|
| `EntropyEngine.kt` | `SessionLifecycleManager`, `IntentFirewallWebViewClient`, `MainActivity`, `mutation_payload.js` (if entropy contract changes) |
| `IntentFirewallWebViewClient.kt` | `MainActivity` (constructor params), `WebViewErrorLogger` |
| `SessionLifecycleManager.kt` | `MainActivity` (callback wiring, WebView registration) |
| `mutation_payload.js` | `IntentFirewallWebViewClient` (if injection changes), `MainActivity` (if loading logic changes) |
| `JsConsoleDatabase.kt` | `MainActivity` (WebChromeClient, adapter) |
| `CrashHandler.kt` | `EISApplication` (installation) |
| `DohClient.kt` | Self-contained (no project deps) |
| `WebViewErrorLogger.kt` | `IntentFirewallWebViewClient` |
| `activity_main.xml` | `MainActivity` (view binding fields) |
| `item_console_log.xml` | `ConsoleLogAdapter.LogViewHolder` (view IDs) |
| `AndroidManifest.xml` | `EISApplication`, `MainActivity`, resource references |
| `app/build.gradle.kts` | Any file using new dependencies |

---

## 10. Quick Reference: Key Files by Spec Requirement

| Spec Requirement | Implementation |
|-----------------|---------------|
| "Hardware Passthrough + Identity Mutation" | Core philosophy — no OS/CPU spoofing, only L7 mutation |
| "Canvas, Audio, State mutation per session" | `EntropyEngine` → `mutation_payload.js` |
| "purgeSession() synchronous" | `SessionLifecycleManager.purgeSession()` |
| "256-bit SessionSeed via SecureRandom" | `EntropyEngine.regenerateSeed()` — 32 bytes |
| "JS payload in assets, injected at onPageStarted" | `assets/mutation_payload.js` + `IntentFirewallWebViewClient.onPageStarted()` |
| "Canvas spoofing: getImageData, toDataURL" | `mutation_payload.js` §1 |
| "Audio spoofing: createOscillator frequency jitter" | `mutation_payload.js` §2 |
| "User-Agent normalization" | `mutation_payload.js` §3 |
| "Intent firewall: only http/https" | `IntentFirewallWebViewClient.shouldOverrideUrlLoading()` |
| "WebRTC block" | `WebSettings.setMediaPlaybackRequiresUserGesture(true)` + JS override |
| "DoH via OkHttp" | `DohClient` with Cloudflare + Quad9 |
| "Zero disk persistence" | `allowBackup=false`, `databaseEnabled=false`, `saveFormData=false` |
| "Crash handler → crashes.txt in external files dir" | `CrashHandler` |
| "WebView error interception" | `IntentFirewallWebViewClient.onReceivedError/HttpError` |
| "Render process crash handling" | `IntentFirewallWebViewClient.onRenderProcessGone()` |
| "JS console capture (ERROR/WARNING)" | `WebChromeClient.onConsoleMessage()` → `JsConsoleDatabase` |
| "Hidden developer UI" | `MainActivity.devConsolePanel` (RecyclerView, toggled by button) |
