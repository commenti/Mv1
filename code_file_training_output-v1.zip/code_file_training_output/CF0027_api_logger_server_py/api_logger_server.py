#!/usr/bin/env python3
import os
import json
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

BASE_DIR = "/storage/emulated/0/Download/ChatScraperExports/_api_discovery"
HOST = "127.0.0.1"
PORT = 8765

os.makedirs(BASE_DIR, exist_ok=True)

def safe_write_jsonl(filepath, data):
    """Android storage par bina fsync error ke safe append"""
    line = json.dumps(data, ensure_ascii=False) + "\n"
    with open(filepath, "a", encoding="utf-8") as f:
        f.write(line)
        f.flush()

class APISnifferHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Default noisy HTTP logs band karne ke liye
        pass

    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path == "/ping":
            self.send_response(200)
            self._send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "alive", "mode": "api_sniffer"}).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path != "/log_api":
            self.send_response(404)
            self.end_headers()
            return

        try:
            content_length = int(self.headers.get("Content-Length", 0))
            raw_body = self.rfile.read(content_length).decode("utf-8", errors="replace")
            payload = json.loads(raw_body)

            site_host = payload.get("site_host", "unknown_site").replace(":", "_")
            site_dir = os.path.join(BASE_DIR, site_host)
            os.makedirs(site_dir, exist_ok=True)

            # 1. Raw JSONL stream save karein (Saare captured APIs)
            jsonl_path = os.path.join(site_dir, "captured_requests.jsonl")
            safe_write_jsonl(jsonl_path, payload)

            # 2. Unique Endpoint Catalog update karein (Duplicate URLs hata kar clean blueprint)
            catalog_path = os.path.join(site_dir, "endpoints_summary.json")
            catalog = {}
            if os.path.exists(catalog_path):
                try:
                    with open(catalog_path, "r", encoding="utf-8") as f:
                        catalog = json.load(f)
                except Exception:
                    catalog = {}

            parsed_url = urlparse(payload.get("url", ""))
            endpoint_key = f"{payload.get('method', 'GET')} {parsed_url.netloc}{parsed_url.path}"

            catalog[endpoint_key] = {
                "last_seen": time.strftime("%Y-%m-%d %H:%M:%S"),
                "full_sample_url": payload.get("url"),
                "method": payload.get("method"),
                "status": payload.get("status"),
                "content_type": payload.get("response_Type"),
                "request_headers": payload.get("request_headers", {}),
                "request_body_sample": payload.get("request_body"),
                "response_keys_or_preview": payload.get("response_preview")
            }

            temp_path = catalog_path + ".tmp"
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(catalog, f, indent=2, ensure_ascii=False)
            os.replace(temp_path, catalog_path)

            # Termux Console par clean live print
            print(f"\n\033[92m[CAPTURED]\033[0m [{site_host}] \033[96m{payload.get('method')}\033[0m {payload.get('url')}")
            print(f"   ├─ Status: {payload.get('status')} | Type: {payload.get('response_Type')}")
            hdr_keys = list(payload.get("request_headers", {}).keys())
            if hdr_keys:
                print(f"   ├─ Headers: {', '.join(hdr_keys)}")
            print(f"   └─ Preview: {str(payload.get('response_preview'))[:140]}...")

            self.send_response(200)
            self._send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"ok": True}).encode("utf-8"))

        except Exception as e:
            print(f"\033[91m[ERROR]\033[0m {e}")
            self.send_response(500)
            self._send_cors_headers()
            self.end_headers()

if __name__ == "__main__":
    print("====================================================")
    print(f" 🚀 API DISCOVERY SERVER RUNNING ON http://{HOST}:{PORT}")
    print(f" 📂 Logs Saving To: {BASE_DIR}")
    print("====================================================")
    server = HTTPServer((HOST, PORT), APISnifferHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
