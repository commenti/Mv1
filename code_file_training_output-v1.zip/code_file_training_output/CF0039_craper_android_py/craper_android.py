"""
╔══════════════════════════════════════════════════════════════════════════════╗
║     APIFY DUAL-MODE DATA PIPELINE — v3.0  🚀                                ║
║     Mode 1 : Smart Data Cleaner & Filter                                     ║
║     Mode 2 : Deep Scraper + Brahmastra Content Dedup ⚡                      ║
║     Author  : Elite Python Automation & Data Engineer                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import json
import os
import re
import sys
import time
import shutil
import hashlib
import datetime
import urllib.request
import urllib.error
from html.parser import HTMLParser

# ══════════════════════════════════════════════════════════════════════════════
# SECTION A — GLOBAL CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════

INPUT_FILE  = "raw_apify_data.json"

URL_KEY     = "url"
TITLE_KEY   = "title"
CONTENT_KEY = "text"

ZONE_GARBAGE = "1_Garbage_Zone"
ZONE_MEMORY  = "2_Memory_Zone"
ZONE_CLEAN   = "3_Clean_Data_Zone"
ZONE_OUTPUT  = "Final_Output_Data"

GARBAGE_FILE = "ignored_links.txt"
CLEAN_FILE   = "filtered_clean_data.json"

MEMORY_CHUNK_LIMIT_BYTES = 50 * 1024 * 1024  # 50 MB

SCRAPE_TIMEOUT_SEC = 15
SCRAPE_DELAY_SEC   = 0.5
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

# ══════════════════════════════════════════════════════════════════════════════
# SECTION B — BLACKLIST
# ══════════════════════════════════════════════════════════════════════════════

BLACKLIST = [
    # Social media platforms
    "facebook", "twitter", "instagram", "linkedin", "youtube",
    "tiktok", "pinterest", "snapchat", "reddit", "telegram", "whatsapp",
    # Generic site pages (non-content)
    "contact", "about", "about-us", "privacy", "privacy-policy",
    "terms", "terms-of-service", "terms-and-conditions",
    "cookie", "cookies", "disclaimer",
    # Auth & account pages
    "login", "logout", "signin", "signup", "register",
    "forgot-password", "reset-password", "account", "my-account",
    # Navigation & utility pages
    "faq", "help", "support", "sitemap", "search",
    "cart", "checkout", "subscribe", "unsubscribe",
    # User-added keywords (custom block list)
    "contacts", "rules", "recommendations", "information-about",
    # Ad / tracking patterns
    "cdn-cgi", "ads", "advertisement", "doubleclick",
    # File downloads
    ".pdf", ".zip", ".exe", ".dmg", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".image",
    # Extended user-added custom keywords
    "sitemap", "contacts", "rules-of", "official-information",
    "recomendations", "information-about", "doubleclick",
    "federal-law", "boundaries", "instruction", "rules", "recomendations",
]

# ══════════════════════════════════════════════════════════════════════════════
# SECTION C — DIAMOND WHITELIST 💎
# ══════════════════════════════════════════════════════════════════════════════

DIAMOND_WHITELIST = [
    "tariffs", "icebreaker", "permits", "fdi", "atomflot",
]

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 0 — CONSOLE HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def clear_console():
    os.system("cls" if os.name == "nt" else "clear")

def print_banner():
    clear_console()
    print("╔" + "═" * 63 + "╗")
    print("║   🚀  APIFY DUAL-MODE DATA PIPELINE  v3.0" + " " * 21 + "║")
    print("╠" + "═" * 63 + "╣")
    print("║   Press  1  →  Smart Data Cleaner & Filter" + " " * 19 + "║")
    print("║   Press  2  →  Deep Scraper + Brahmastra ⚡" + " " * 18 + "║")
    print("║   Press  Q  →  Quit" + " " * 42 + "║")
    print("╚" + "═" * 63 + "╝")

def divider(char="─", width=65):
    print(char * width)

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 1 — DIRECTORY SETUP
# ══════════════════════════════════════════════════════════════════════════════

def setup_directories():
    for folder in [ZONE_GARBAGE, ZONE_MEMORY, ZONE_CLEAN, ZONE_OUTPUT]:
        os.makedirs(folder, exist_ok=True)
    print("✅  [SETUP] All pipeline zones are ready.")

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 2 — SMART FOLDER RESET
# ══════════════════════════════════════════════════════════════════════════════

def smart_reset():
    zones_to_wipe = [ZONE_GARBAGE, ZONE_CLEAN, ZONE_OUTPUT]
    print("\n🧹  [RESET] Smart-wiping old data zones...")
    for zone in zones_to_wipe:
        if os.path.exists(zone):
            shutil.rmtree(zone)
            print(f"    🗑️  Wiped  → {zone}")
        os.makedirs(zone, exist_ok=True)
        print(f"    ✅  Fresh  → {zone}")
    print("    🔒  Memory Zone UNTOUCHED → 2_Memory_Zone")

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 3 — DIAMOND WHITELIST ENGINE 💎
# ══════════════════════════════════════════════════════════════════════════════

def is_diamond(url: str) -> bool:
    url_lower = url.lower()
    return any(kw in url_lower for kw in DIAMOND_WHITELIST)

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 4 — BLACKLIST ENGINE
# ══════════════════════════════════════════════════════════════════════════════

_BLACKLIST_SET = set(BLACKLIST)

def is_garbage(url: str) -> bool:
    url_lower = url.lower()
    return any(kw in url_lower for kw in _BLACKLIST_SET)

def send_to_garbage(url: str, garbage_file_path: str):
    with open(garbage_file_path, "a", encoding="utf-8") as f:
        f.write(url + "\n")

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 5 — INFINITE SCALABLE MEMORY (Auto-Chunking)
# ══════════════════════════════════════════════════════════════════════════════

def _get_all_memory_files() -> list:
    files = []
    for fname in os.listdir(ZONE_MEMORY):
        if re.match(r"^memory_v\d+\.txt$", fname):
            files.append(os.path.join(ZONE_MEMORY, fname))
    files.sort(key=lambda p: int(re.search(r"v(\d+)", p).group(1)))
    return files

def _get_active_memory_file() -> str:
    files = _get_all_memory_files()
    if not files:
        path = os.path.join(ZONE_MEMORY, "memory_v1.txt")
        open(path, "a").close()
        return path
    latest = files[-1]
    size   = os.path.getsize(latest)
    if size >= MEMORY_CHUNK_LIMIT_BYTES:
        ver      = int(re.search(r"v(\d+)", latest).group(1))
        new_ver  = ver + 1
        new_path = os.path.join(ZONE_MEMORY, f"memory_v{new_ver}.txt")
        open(new_path, "a").close()
        print(f"\n📦  [MEMORY] Auto-rotated → memory_v{new_ver}.txt  (v{ver} hit 50 MB limit)")
        return new_path
    return latest

def load_full_memory() -> set:
    seen = set()
    for fpath in _get_all_memory_files():
        with open(fpath, "r", encoding="utf-8") as f:
            for line in f:
                stripped = line.strip()
                if stripped:
                    seen.add(stripped)
    return seen

def add_to_memory(url: str, memory_set: set):
    memory_set.add(url)
    active_file = _get_active_memory_file()
    with open(active_file, "a", encoding="utf-8") as f:
        f.write(url + "\n")

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 6 — DATA EXTRACTION (Clean Record Builder)
# ══════════════════════════════════════════════════════════════════════════════

def extract_clean_record(item: dict) -> dict:
    url     = (item.get(URL_KEY) or item.get("pageUrl")
               or item.get("loadedUrl") or "").strip()
    title   = item.get(TITLE_KEY) or item.get("metadata", {}).get("title", "")
    content = item.get(CONTENT_KEY) or item.get("markdown") or item.get("html", "")

    preview = ""
    if isinstance(content, str) and content.strip():
        preview = (content[:500].strip() + "…") if len(content) > 500 else content.strip()

    return {
        "url"            : url,
        "title"          : title.strip() if isinstance(title, str) else "",
        "content_preview": preview,
        "scraped_at"     : datetime.datetime.utcnow().isoformat() + "Z",
    }

def save_clean_batch(clean_records: list, clean_file_path: str):
    existing = []
    if os.path.exists(clean_file_path):
        with open(clean_file_path, "r", encoding="utf-8") as f:
            try:
                existing = json.load(f)
                if not isinstance(existing, list):
                    existing = []
            except json.JSONDecodeError:
                existing = []
    combined = existing + clean_records
    with open(clean_file_path, "w", encoding="utf-8") as f:
        json.dump(combined, f, ensure_ascii=False, indent=2)

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 7 — OPTION 1: SMART CLEANER & FILTER PIPELINE
# ══════════════════════════════════════════════════════════════════════════════

def run_cleaner():
    print("\n" + "═" * 65)
    print("   🧹  MODE 1 — SMART DATA CLEANER & FILTER")
    print("═" * 65)

    smart_reset()
    setup_directories()

    garbage_file_path = os.path.join(ZONE_GARBAGE, GARBAGE_FILE)
    clean_file_path   = os.path.join(ZONE_CLEAN,   CLEAN_FILE)

    if not os.path.exists(INPUT_FILE):
        print(f"\n❌  ERROR: '{INPUT_FILE}' not found. Place it next to this script.\n")
        return

    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        try:
            raw_data = json.load(f)
        except json.JSONDecodeError as e:
            print(f"\n❌  JSON Parse Error: {e}\n")
            return

    if isinstance(raw_data, dict):
        raw_data = raw_data.get("items", [])
    if not isinstance(raw_data, list):
        print("❌  ERROR: Unexpected JSON structure.\n")
        return

    total_items = len(raw_data)
    print(f"\n📂  Loaded {total_items} raw records from '{INPUT_FILE}'")

    memory    = load_full_memory()
    mem_files = _get_all_memory_files()
    print(f"🧠  Memory loaded — {len(memory)} known URLs across {len(mem_files)} chunk(s).")

    count_diamond   = 0
    count_garbage   = 0
    count_duplicate = 0
    count_clean     = 0
    clean_batch     = []

    print("\n" + "─" * 65)
    print("   ⚙️   PROCESSING RECORDS...")
    print("─" * 65)

    for idx, item in enumerate(raw_data, start=1):
        url = (
            item.get(URL_KEY) or item.get("pageUrl")
            or item.get("loadedUrl") or item.get("canonicalUrl") or ""
        ).strip()

        if not url:
            print(f"  [{idx:>5}] ⚠️  SKIPPED — No URL found.")
            count_garbage += 1
            continue

        # Gate 0: Diamond Whitelist 💎
        if is_diamond(url):
            if url in memory:
                count_duplicate += 1
                print(f"  [{idx:>5}] 🔁  DIAMOND-DUP → {url[:65]}")
                continue
            add_to_memory(url, memory)
            clean_record = extract_clean_record(item)
            clean_batch.append(clean_record)
            count_diamond += 1
            count_clean   += 1
            print(f"  [{idx:>5}] 💎  DIAMOND    → {url[:65]}")
            continue

        # Gate 1: Blacklist Engine
        if is_garbage(url):
            send_to_garbage(url, garbage_file_path)
            count_garbage += 1
            print(f"  [{idx:>5}] 🗑️  GARBAGE   → {url[:65]}")
            continue

        # Gate 2: Deduplication Memory
        if url in memory:
            count_duplicate += 1
            print(f"  [{idx:>5}] 🔁  DUPLICATE → {url[:65]}")
            continue

        # Gate 3: Clean Data
        add_to_memory(url, memory)
        clean_record = extract_clean_record(item)
        clean_batch.append(clean_record)
        count_clean += 1
        print(f"  [{idx:>5}] ✅  CLEAN     → {url[:65]}")

    if clean_batch:
        save_clean_batch(clean_batch, clean_file_path)

    print("\n" + "═" * 65)
    print("   📊  CLEANER COMPLETE — FINAL SUMMARY")
    print("═" * 65)
    print(f"   Total Records Processed   : {total_items}")
    print(f"   💎  Diamond VIP Saved      : {count_diamond}")
    print(f"   🗑️   Garbage / Blacklisted  : {count_garbage}")
    print(f"   🔁  Duplicates Skipped     : {count_duplicate}")
    print(f"   ✅  Total Clean Records    : {count_clean}")
    print("─" * 65)
    print(f"   📁  Garbage  → {os.path.join(ZONE_GARBAGE, GARBAGE_FILE)}")
    print(f"   🧠  Memory   → {ZONE_MEMORY}/ (all chunks)")
    print(f"   💎  Clean    → {clean_file_path}")
    print("═" * 65 + "\n")

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 8 — HTML TEXT EXTRACTOR
# ══════════════════════════════════════════════════════════════════════════════

class _TextExtractor(HTMLParser):
    SKIP_TAGS = {"script", "style", "noscript", "head", "meta", "link"}

    def __init__(self):
        super().__init__()
        self._skip  = False
        self._depth = 0
        self.chunks = []

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP_TAGS:
            self._skip  = True
            self._depth = 1

    def handle_endtag(self, tag):
        if self._skip and tag in self.SKIP_TAGS:
            self._depth -= 1
            if self._depth <= 0:
                self._skip = False

    def handle_data(self, data):
        if not self._skip:
            text = data.strip()
            if text:
                self.chunks.append(text)

    def get_text(self) -> str:
        raw = " ".join(self.chunks)
        return re.sub(r"\s{2,}", " ", raw).strip()


def fetch_page_text(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=SCRAPE_TIMEOUT_SEC) as resp:
            raw_bytes    = resp.read()
            content_type = resp.headers.get_content_charset() or "utf-8"
            try:
                html = raw_bytes.decode(content_type, errors="replace")
            except LookupError:
                html = raw_bytes.decode("utf-8", errors="replace")
        parser = _TextExtractor()
        parser.feed(html)
        return parser.get_text()
    except urllib.error.HTTPError as e:
        return f"[HTTP ERROR {e.code}: {e.reason}]"
    except urllib.error.URLError as e:
        return f"[URL ERROR: {e.reason}]"
    except Exception as e:
        return f"[EXCEPTION: {str(e)}]"

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 9 — BRAHMASTRA HELPERS ⚡
# ══════════════════════════════════════════════════════════════════════════════

def _compute_content_hash(text: str) -> str:
    normalized = re.sub(r"\s+", " ", text).strip().lower()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

def _is_error_response(text: str) -> bool:
    return (text.startswith("[HTTP ERROR") or
            text.startswith("[URL ERROR") or
            text.startswith("[EXCEPTION"))

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 10 — OPTION 2: DEEP SCRAPER + BRAHMASTRA CONTENT DEDUP ⚡
# ══════════════════════════════════════════════════════════════════════════════

def run_scraper():
    print("\n" + "═" * 65)
    print("   🕷️   MODE 2 — DEEP SCRAPER + BRAHMASTRA ⚡")
    print("═" * 65)

    clean_file_path = os.path.join(ZONE_CLEAN, CLEAN_FILE)

    if not os.path.exists(clean_file_path):
        print(f"\n❌  ERROR: '{clean_file_path}' not found.")
        print("    Run Mode 1 first to generate clean data.\n")
        return

    with open(clean_file_path, "r", encoding="utf-8") as f:
        try:
            clean_records = json.load(f)
        except json.JSONDecodeError:
            print("❌  ERROR: Could not parse filtered_clean_data.json\n")
            return

    if not clean_records:
        print("⚠️  No records found in clean data. Run Mode 1 first.\n")
        return

    total = len(clean_records)
    print(f"\n📂  {total} clean URLs loaded for scraping.")
    print(f"💾  Output     → {ZONE_OUTPUT}/")
    print(f"⚡  Brahmastra → SHA-256 Content Deduplication ACTIVE")
    print(f"🔄  Temp Memory → Runtime only (auto-destroyed on exit)\n")
    divider()

    os.makedirs(ZONE_OUTPUT, exist_ok=True)

    # Brahmastra runtime memory — lives only during this session
    content_hashes: set = set()

    count_ok                = 0
    count_fail              = 0
    count_content_duplicate = 0

    for idx, record in enumerate(clean_records, start=1):
        url   = record.get("url",   "").strip()
        title = record.get("title", "Untitled").strip()

        if not url:
            print(f"  [{idx:>5}] ⚠️   SKIPPED    — Empty URL.")
            count_fail += 1
            continue

        print(f"  [{idx:>5}] 🌐  Fetching  → {url[:60]}")
        text = fetch_page_text(url)

        # Gate 1: Network error check
        if _is_error_response(text):
            print(f"         ❌  FETCH FAIL — {text[:60]}")
            count_fail += 1
            time.sleep(SCRAPE_DELAY_SEC)
            continue

        # Gate 2: Minimum content guard
        if len(text.strip()) < 100:
            print(f"         ⚠️   TOO SHORT  — Only {len(text)} chars. Skipping.")
            count_fail += 1
            time.sleep(SCRAPE_DELAY_SEC)
            continue

        # Gate 3: ⚡ Brahmastra — SHA-256 content hash check
        content_hash = _compute_content_hash(text)

        if content_hash in content_hashes:
            count_content_duplicate += 1
            print(f"         🔴  BRAHMASTRA REJECTED — Duplicate content!")
            print(f"              Hash: {content_hash[:16]}...  URL: {url[:45]}")
            time.sleep(SCRAPE_DELAY_SEC)
            continue

        # Content is unique — accept and save
        content_hashes.add(content_hash)

        payload = {
            "index"       : idx,
            "url"         : url,
            "title"       : title,
            "scraped_at"  : datetime.datetime.utcnow().isoformat() + "Z",
            "content_hash": content_hash,
            "raw_text"    : text,
            "char_count"  : len(text),
        }

        safe_name = re.sub(r"[^\w\-]", "_", url.split("//")[-1])[:80]
        out_file  = os.path.join(ZONE_OUTPUT, f"{idx:04d}_{safe_name}.json")

        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

        count_ok += 1
        print(f"         ✅  ACCEPTED   — {len(text):,} chars | Hash: {content_hash[:16]}...")
        print(f"              Saved → {os.path.basename(out_file)}")

        time.sleep(SCRAPE_DELAY_SEC)

    # content_hashes auto-destroyed when function exits — no cleanup needed
    final_unique = len(content_hashes)

    print("\n" + "═" * 65)
    print("   📊  SCRAPER + BRAHMASTRA COMPLETE — FINAL SUMMARY")
    print("═" * 65)
    print(f"   Total URLs Attempted        : {total}")
    print(f"   ✅  Unique Content Saved     : {count_ok}")
    print(f"   🔴  Brahmastra Rejected      : {count_content_duplicate}")
    print(f"   ❌  Failed / Errors          : {count_fail}")
    print(f"   🔑  Unique Hashes This Run   : {final_unique}")
    print(f"   💾  Output Folder            : {ZONE_OUTPUT}/")
    print(f"   🧹  Temp Content Memory      : AUTO-DESTROYED ✅")
    print("═" * 65 + "\n")

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 11 — MAIN MENU (The Brain)
# ══════════════════════════════════════════════════════════════════════════════

def main():
    while True:
        print_banner()
        choice = input("\n   👉  Your choice: ").strip().lower()

        if choice == "1":
            run_cleaner()
            input("\n   Press ENTER to return to menu...")

        elif choice == "2":
            run_scraper()
            input("\n   Press ENTER to return to menu...")

        elif choice in ("q", "quit", "exit"):
            print("\n   👋  Goodbye! Pipeline shut down.\n")
            sys.exit(0)

        else:
            print("\n   ❌  Invalid choice. Press 1, 2, or Q.\n")
            time.sleep(1.5)

# ══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    main()
