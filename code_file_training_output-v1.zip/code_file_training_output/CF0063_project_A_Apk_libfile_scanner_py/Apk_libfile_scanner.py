#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Android APK/XAPK/APKS Static & Dynamic Analysis Scanner
Author: Security Researcher
Description: Automated scanner for Android native libraries (.so files)
Optimized for: Termux/Linux (aarch64) using pyelftools
Supports: APK, APKS, XAPK, APKM, ZIP formats
Features: Multi-level extraction, ELF analysis, JNI detection, API hooking points
"""

import os
import sys
import re
import zipfile
import shutil
import subprocess
import struct
import argparse
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Set
import json

# Try to import pyelftools for ELF analysis
try:
    from elftools.elf.elffile import ELFFile
    from elftools.elf.sections import SymbolTableSection
    from elftools.elf.dynamic import DynamicSection
    from elftools.elf.descriptions import describe_e_machine, describe_e_type
    from elftools.common.exceptions import ELFError
    ELFFILES_AVAILABLE = True
except ImportError:
    ELFFILES_AVAILABLE = False
    print("[-] Warning: pyelftools not installed. Install with: pip install pyelftools")

# Color codes for terminal output
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class APKNativeScanner:
    def __init__(self, apk_path: str, output_dir: str = "analysis_output"):
        self.apk_path = Path(apk_path)
        self.output_dir = Path(output_dir)
        self.extracted_path = self.output_dir / "extracted"
        self.so_files: List[Path] = []
        self.nested_apks: List[Path] = []  # Track nested APKs (for APKS/XAPK)
        self.findings: Dict = {
            "apk_info": {},
            "native_libs": [],
            "nested_apks": [],
            "network_indicators": [],
            "jni_functions": [],
            "runtime_hooks": [],
            "suspicious_patterns": []
        }
        
    def print_banner(self):
        banner = f"""
{Colors.OKCYAN}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║          🔍 ANDROID NATIVE LIBRARY ANALYZER 🔍               ║
║              Static & Dynamic Analysis Scanner               ║
║         Supports: APK, APKS, XAPK, APKM, ZIP formats        ║
║                   (Termux/aarch64 Optimized)                 ║
╚══════════════════════════════════════════════════════════════╝
{Colors.ENDC}"""
        print(banner)
        
    def is_zip_file(self, file_path: Path) -> bool:
        """Check if file is a valid ZIP archive"""
        try:
            with zipfile.ZipFile(file_path, 'r') as zf:
                return True
        except (zipfile.BadZipFile, Exception):
            return False
            
    def find_nested_apks(self, directory: Path) -> List[Path]:
        """Find all APK files in directory (recursive)"""
        apk_patterns = ['*.apk', '*.apks', '*.xapk', '*.apkm']
        found_apks = []
        for pattern in apk_patterns:
            found_apks.extend(directory.rglob(pattern))
        return found_apks
        
    def extract_archive(self, archive_path: Path, extract_to: Path, depth: int = 0, max_depth: int = 3) -> bool:
        """Recursively extract ZIP-based archives (APK, APKS, XAPK, etc.)"""
        if depth > max_depth:
            print(f"{Colors.WARNING}[!] Max extraction depth reached for {archive_path.name}{Colors.ENDC}")
            return False
            
        try:
            with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                # Check if this looks like an Android App Bundle (APKS)
                apk_files_in_zip = [name for name in zip_ref.namelist() if name.endswith('.apk')]
                
                if apk_files_in_zip and depth == 0:
                    print(f"{Colors.OKCYAN}[+] Found Android App Bundle format with {len(apk_files_in_zip)} APK(s){Colors.ENDC}")
                    
                # Extract all contents
                zip_ref.extractall(extract_to)
                
                # Look for nested archives
                for item in extract_to.rglob('*'):
                    if item.is_file():
                        # Check if it's an APK or archive
                        if item.suffix.lower() in ['.apk', '.apks', '.xapk', '.apkm', '.zip']:
                            if self.is_zip_file(item):
                                nested_extract = extract_to / f"nested_{depth}_{item.stem}"
                                nested_extract.mkdir(exist_ok=True)
                                print(f"{Colors.OKBLUE}    → Extracting nested: {item.name}{Colors.ENDC}")
                                self.extract_archive(item, nested_extract, depth + 1, max_depth)
                                # Track nested APKs
                                if item.suffix.lower() == '.apk':
                                    self.nested_apks.append(item)
                                    
            return True
            
        except Exception as e:
            if depth == 0:
                print(f"{Colors.FAIL}[-] Extraction failed: {e}{Colors.ENDC}")
            return False
        
    def extract_apk(self) -> bool:
        """Extract APK/XAPK/APKS contents with recursive handling"""
        print(f"\n{Colors.HEADER}[*] Analyzing: {self.apk_path}{Colors.ENDC}")
        
        if not self.apk_path.exists():
            print(f"{Colors.FAIL}[-] File not found: {self.apk_path}{Colors.ENDC}")
            return False
            
        # Check if it's a valid archive
        if not self.is_zip_file(self.apk_path):
            print(f"{Colors.FAIL}[-] Not a valid ZIP-based archive (APK/XAPK/APKS){Colors.ENDC}")
            return False
            
        # Clean previous extraction
        if self.extracted_path.exists():
            shutil.rmtree(self.extracted_path)
            
        self.extracted_path.mkdir(parents=True, exist_ok=True)
        
        # Extract main archive recursively
        print(f"{Colors.HEADER}[*] Extracting archive...{Colors.ENDC}")
        if not self.extract_archive(self.apk_path, self.extracted_path):
            return False
            
        # Find all .so files recursively
        self.so_files = list(self.extracted_path.rglob("*.so"))
        
        # Also check for .so files in lib/ directories specifically
        lib_dirs = list(self.extracted_path.rglob("lib/"))
        for lib_dir in lib_dirs:
            if lib_dir.is_dir():
                arch_dirs = ['arm64-v8a', 'armeabi-v7a', 'x86', 'x86_64']
                for arch in arch_dirs:
                    arch_path = lib_dir / arch
                    if arch_path.exists():
                        print(f"{Colors.OKGREEN}[+] Found architecture directory: {arch_path.relative_to(self.extracted_path)}{Colors.ENDC}")
        
        print(f"{Colors.OKGREEN}[+] Extraction complete!{Colors.ENDC}")
        print(f"{Colors.OKBLUE}[+] Found {len(self.so_files)} native libraries (.so files){Colors.ENDC}")
        
        if self.nested_apks:
            print(f"{Colors.OKBLUE}[+] Processed {len(self.nested_apks)} nested APK files{Colors.ENDC}")
            
        # Show directory structure
        if not self.so_files:
            print(f"{Colors.WARNING}[!] No .so files found. Showing extracted structure:{Colors.ENDC}")
            self._show_directory_structure(self.extracted_path, level=0, max_level=2)
            
        return True
        
    def _show_directory_structure(self, path: Path, level: int = 0, max_level: int = 2):
        """Display directory structure for debugging"""
        if level > max_level:
            return
        prefix = "    " * level + ("└── " if level > 0 else "")
        try:
            for item in sorted(path.iterdir(), key=lambda x: (x.is_file(), x.name)):
                if item.name.startswith('.'):
                    continue
                if item.is_dir():
                    print(f"{prefix}{item.name}/")
                    self._show_directory_structure(item, level + 1, max_level)
                else:
                    if item.suffix in ['.apk', '.so', '.dex', '.xml']:
                        print(f"{prefix}{item.name}")
        except PermissionError:
            pass
    
    def detect_architecture(self, data: bytes) -> str:
        """Detect architecture from ELF header"""
        if len(data) < 20:
            return "Unknown"
            
        # Check ELF magic
        if data[:4] != b'\x7fELF':
            return "Invalid ELF"
            
        # e_machine is at offset 18 (2 bytes) - little endian
        try:
            machine = struct.unpack('<H', data[18:20])[0]
        except:
            return "Unknown"
        
        arch_map = {
            0x03: "x86",
            0x3E: "x86_64",
            0x28: "ARM32",
            0xB7: "ARM64/AArch64",
            0xF3: "RISC-V"
        }
        
        return arch_map.get(machine, f"Unknown (0x{machine:04x})")
            
    def analyze_so_file_pyelftools(self, so_path: Path) -> Dict:
        """Analyze .so file using pyelftools"""
        findings = {
            "file_name": so_path.name,
            "file_path": str(so_path),
            "architecture": "Unknown",
            "elf_type": "Unknown",
            "imports": [],
            "exports": [],
            "strings": [],
            "jni_functions": [],
            "network_apis": [],
            "memory_apis": [],
            "crypto_apis": [],
            "suspicious_strings": [],
            "sections": []
        }
        
        try:
            with open(so_path, 'rb') as f:
                # First detect architecture from raw header
                header_data = f.read(20)
                findings["architecture"] = self.detect_architecture(header_data)
                f.seek(0)
                
                if not ELFFILES_AVAILABLE:
                    return self._analyze_with_strings(so_path)
                
                try:
                    elffile = ELFFile(f)
                    
                    # Get ELF type
                    findings["elf_type"] = describe_e_type(elffile.header['e_type'])
                    
                    # Get sections info
                    for section in elffile.iter_sections():
                        findings["sections"].append({
                            "name": section.name,
                            "type": section.header['sh_type'],
                            "size": hex(section.header['sh_size'])
                        })
                    
                    # Extract dynamic symbols (exports and imports)
                    for section in elffile.iter_sections():
                        if isinstance(section, SymbolTableSection):
                            for symbol in section.iter_symbols():
                                sym_name = symbol.name
                                if not sym_name:
                                    continue
                                    
                                # Check if it's an export or import
                                if symbol.entry['st_shndx'] == 'SHN_UNDEF':
                                    findings["imports"].append(sym_name)
                                else:
                                    findings["exports"].append(sym_name)
                                
                                # JNI Function Detection
                                if "JNI_OnLoad" in sym_name:
                                    findings["jni_functions"].append({
                                        "name": sym_name,
                                        "type": "JNI_OnLoad",
                                        "address": hex(symbol.entry['st_value']) if symbol.entry['st_value'] else "Unknown"
                                    })
                                elif sym_name.startswith("Java_"):
                                    findings["jni_functions"].append({
                                        "name": sym_name,
                                        "type": "JNI_Binding",
                                        "address": hex(symbol.entry['st_value']) if symbol.entry['st_value'] else "Unknown"
                                    })
                                
                                # Network API Detection
                                network_patterns = ["socket", "connect", "send", "recv", "curl", 
                                                  "http", "SSL", "TLS", "openssl", "getaddrinfo", 
                                                  "inet_addr", "gethostbyname", "getaddrinfo_a"]
                                if any(pattern in sym_name.lower() for pattern in network_patterns):
                                    findings["network_apis"].append(sym_name)
                                
                                # Memory/Runtime API Detection
                                memory_patterns = ["mmap", "mprotect", "ptrace", "dlopen", "dlsym", 
                                                 "malloc", "calloc", "memcpy", "memset", "free",
                                                 "realloc", "memmove", "dlclose", "dlerror"]
                                if any(pattern in sym_name.lower() for pattern in memory_patterns):
                                    findings["memory_apis"].append(sym_name)
                                
                                # Crypto API Detection
                                crypto_patterns = ["AES", "DES", "RSA", "SHA", "MD5", "encrypt", 
                                                 "decrypt", "cipher", "EVP_", "HMAC", "CRC", "BCrypt"]
                                if any(pattern in sym_name for pattern in crypto_patterns):
                                    findings["crypto_apis"].append(sym_name)
                    
                    # Extract strings from .rodata and .data sections
                    for section in elffile.iter_sections():
                        if section.name in ['.rodata', '.data', '.dynstr', '.strtab']:
                            try:
                                data = section.data()
                                strings = self._extract_strings(data)
                                findings["strings"].extend(strings)
                            except:
                                pass
                                
                except ELFError as e:
                    # If pyelftools fails, fallback to strings
                    return self._analyze_with_strings(so_path)
                    
        except Exception as e:
            return self._analyze_with_strings(so_path)
            
        return findings
        
    def _analyze_with_strings(self, so_path: Path) -> Dict:
        """Fallback analysis using strings command"""
        findings = {
            "file_name": so_path.name,
            "file_path": str(so_path),
            "architecture": "Unknown (Fallback mode)",
            "elf_type": "Unknown",
            "imports": [],
            "exports": [],
            "strings": [],
            "jni_functions": [],
            "network_apis": [],
            "memory_apis": [],
            "crypto_apis": [],
            "suspicious_strings": [],
            "sections": []
        }
        
        try:
            # Run strings command with minimum length 4
            result = subprocess.run(["strings", "-n", "4", str(so_path)], 
                                  capture_output=True, text=True, timeout=30)
            all_strings = result.stdout.split('\n')
            
            findings["strings"] = all_strings[:1000]  # Limit to first 1000
            
            # Search for JNI functions
            for s in all_strings:
                if "JNI_OnLoad" in s:
                    findings["jni_functions"].append({"name": s, "type": "JNI_OnLoad"})
                elif s.startswith("Java_"):
                    findings["jni_functions"].append({"name": s, "type": "JNI_Binding"})
                    
                # Network indicators
                if any(pattern in s.lower() for pattern in ["http://", "https://", "socket", "curl", "wget", "fetch"]):
                    if s not in findings["network_apis"]:
                        findings["network_apis"].append(s)
                    
                # Memory operations
                if any(pattern in s.lower() for pattern in ["mmap", "ptrace", "dlopen", "mprotect", "malloc"]):
                    if s not in findings["memory_apis"]:
                        findings["memory_apis"].append(s)
                        
                # Suspicious patterns (URLs, IPs, etc)
                if re.match(r'https?://[^\s]+', s):
                    findings["suspicious_strings"].append({"type": "URL", "value": s})
                elif re.match(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', s):
                    findings["suspicious_strings"].append({"type": "IP Address", "value": s})
                    
        except Exception as e:
            pass
            
        return findings
        
    def _extract_strings(self, data: bytes, min_length: int = 4) -> List[str]:
        """Extract printable strings from binary data"""
        strings = []
        current = []
        
        for byte in data:
            if 32 <= byte <= 126:  # Printable ASCII
                current.append(chr(byte))
            else:
                if len(current) >= min_length:
                    strings.append(''.join(current))
                current = []
                
        if len(current) >= min_length:
            strings.append(''.join(current))
            
        return strings
        
    def scan_all_libraries(self):
        """Scan all discovered .so files"""
        if not self.so_files:
            print(f"\n{Colors.WARNING}[!] No native libraries to scan{Colors.ENDC}")
            return
            
        print(f"\n{Colors.HEADER}[*] Scanning {len(self.so_files)} native libraries...{Colors.ENDC}")
        
        for i, so_file in enumerate(self.so_files, 1):
            print(f"{Colors.OKBLUE}    [{i}/{len(self.so_files)}] Analyzing: {so_file.name}{Colors.ENDC}")
            
            if ELFFILES_AVAILABLE:
                analysis = self.analyze_so_file_pyelftools(so_file)
            else:
                analysis = self._analyze_with_strings(so_file)
                
            self.findings["native_libs"].append(analysis)
            
    def identify_main_logic(self):
        """Identify main logic/entry points"""
        print(f"\n{Colors.HEADER}[*] Identifying Main Logic & Entry Points...{Colors.ENDC}")
        
        if not self.findings["native_libs"]:
            print(f"{Colors.WARNING}[!] No libraries to analyze{Colors.ENDC}")
            return
            
        main_candidates = []
        
        for lib in self.findings["native_libs"]:
            score = 0
            reasons = []
            
            # JNI_OnLoad presence indicates initialization logic
            jni_onload = [f for f in lib["jni_functions"] if f["type"] == "JNI_OnLoad"]
            if jni_onload:
                score += 50
                reasons.append("Contains JNI_OnLoad (Initialization)")
                
            # Multiple JNI bindings indicate main logic
            jni_bindings = [f for f in lib["jni_functions"] if f["type"] == "JNI_Binding"]
            if len(jni_bindings) > 5:
                score += 30
                reasons.append(f"High JNI binding count ({len(jni_bindings)})")
            elif len(jni_bindings) > 0:
                score += 15
                reasons.append(f"JNI bindings present ({len(jni_bindings)})")
                
            # Network activity indicates C2 communication
            if lib["network_apis"]:
                score += 20
                reasons.append("Network API usage detected")
                
            # Memory manipulation indicates packing/obfuscation
            if len(lib["memory_apis"]) > 3:
                score += 15
                reasons.append("Heavy memory operations (Possible packing)")
            elif len(lib["memory_apis"]) > 0:
                score += 5
                reasons.append("Memory operations present")
                
            # Crypto operations
            if lib["crypto_apis"]:
                score += 10
                reasons.append("Cryptographic functions detected")
                
            if score > 0:
                main_candidates.append({
                    "library": lib["file_name"],
                    "architecture": lib["architecture"],
                    "score": score,
                    "reasons": reasons,
                    "jni_functions": lib["jni_functions"],
                    "network_apis": lib["network_apis"][:5],  # Top 5
                    "memory_apis": lib["memory_apis"][:5],
                    "crypto_apis": lib["crypto_apis"][:5]
                })
                
        # Sort by score
        main_candidates.sort(key=lambda x: x["score"], reverse=True)
        self.findings["main_logic_candidates"] = main_candidates
        
    def detect_injection_points(self):
        """Detect potential hooking/injection points"""
        print(f"\n{Colors.HEADER}[*] Analyzing Runtime/Injection Points...{Colors.ENDC}")
        
        if not self.findings["native_libs"]:
            return
            
        critical_functions = {
            "mmap": "Memory mapping - Code injection possible",
            "mprotect": "Change memory permissions - Bypass NX",
            "ptrace": "Process tracing - Anti-debug/Injection",
            "dlopen": "Dynamic loading - Library injection",
            "dlsym": "Symbol resolution - API hooking",
            "dlclose": "Dynamic unloading",
            "memcpy": "Memory copy - Stack/Heap overflow",
            "strcpy": "String copy - Buffer overflow",
            "malloc": "Heap allocation - UAF/Double free",
            "free": "Memory free - UAF vulnerabilities"
        }
        
        injection_points = []
        
        for lib in self.findings["native_libs"]:
            for api in lib["memory_apis"]:
                for func, desc in critical_functions.items():
                    if func in api.lower():
                        injection_points.append({
                            "library": lib["file_name"],
                            "function": api,
                            "description": desc,
                            "risk_level": "HIGH" if func in ["ptrace", "dlopen", "mmap", "dlsym"] else "MEDIUM"
                        })
                        
        self.findings["injection_points"] = injection_points
        
    def detect_obfuscation(self):
        """Detect obfuscation and anti-analysis techniques"""
        print(f"\n{Colors.HEADER}[*] Checking for Obfuscation/Anti-Analysis...{Colors.ENDC}")
        
        if not self.findings["native_libs"]:
            return
            
        obfuscation_indicators = []
        
        for lib in self.findings["native_libs"]:
            # Check for common obfuscator signatures
            obfuscators = {
                "ollvm": "OLLVM Obfuscation",
                "obfuscate": "Generic Obfuscation",
                "protect": "Protection Mechanism",
                "anti": "Anti-analysis Code",
                "debug": "Debug Detection",
                "root": "Root Detection",
                "emulator": "Emulator Detection",
                "frida": "Frida Detection",
                "xposed": "Xposed Detection"
            }
            
            for string in lib["strings"]:
                for indicator, desc in obfuscators.items():
                    if indicator in string.lower():
                        obfuscation_indicators.append({
                            "library": lib["file_name"],
                            "indicator": string,
                            "type": desc
                        })
                        
        self.findings["obfuscation_indicators"] = obfuscation_indicators
        
    def generate_report(self):
        """Generate comprehensive terminal report"""
        print(f"\n{Colors.OKGREEN}{Colors.BOLD}")
        print("=" * 70)
        print("                    📊 ANALYSIS REPORT 📊")
        print("=" * 70)
        print(f"{Colors.ENDC}")
        
        # APK Info
        print(f"{Colors.HEADER}[+] APK Information:{Colors.ENDC}")
        print(f"    File: {self.apk_path.name}")
        print(f"    Size: {self.apk_path.stat().st_size / 1024 / 1024:.2f} MB")
        print(f"    Native Libraries: {len(self.so_files)}")
        
        if self.nested_apks:
            print(f"    Nested APKs Found: {len(self.nested_apks)}")
            
        # Main Logic Identification
        print(f"\n{Colors.OKCYAN}{Colors.BOLD}[🎯] MAIN LOGIC IDENTIFICATION:{Colors.ENDC}")
        if self.findings.get("main_logic_candidates"):
            for i, candidate in enumerate(self.findings["main_logic_candidates"][:3], 1):
                risk_color = Colors.FAIL if candidate["score"] > 70 else Colors.WARNING if candidate["score"] > 40 else Colors.OKGREEN
                print(f"\n    {risk_color}[{i}] {candidate['library']} (Score: {candidate['score']}/100){Colors.ENDC}")
                print(f"    Architecture: {candidate['architecture']}")
                print(f"    Indicators:")
                for reason in candidate["reasons"]:
                    print(f"        • {reason}")
                    
                if candidate["jni_functions"]:
                    print(f"    {Colors.OKGREEN}JNI Functions:{Colors.ENDC}")
                    for jni in candidate["jni_functions"][:5]:
                        addr = jni.get('address', 'Unknown')
                        print(f"        → {jni['name']} [{addr}] ({jni['type']})")
                        
                if candidate["crypto_apis"]:
                    print(f"    {Colors.WARNING}Crypto APIs:{Colors.ENDC}")
                    for api in candidate["crypto_apis"][:3]:
                        print(f"        🔐 {api}")
        else:
            print(f"    {Colors.WARNING}No clear main logic candidates found{Colors.ENDC}")
            
        # Network Indicators
        print(f"\n{Colors.OKCYAN}{Colors.BOLD}[🌐] NETWORK & API CALLS:{Colors.ENDC}")
        network_found = False
        for lib in self.findings["native_libs"]:
            if lib["network_apis"]:
                network_found = True
                print(f"\n    {Colors.OKBLUE}Library: {lib['file_name']}{Colors.ENDC}")
                unique_apis = list(set(lib["network_apis"]))[:10]
                for api in unique_apis:
                    print(f"        ⚡ {api}")
                    
        if not network_found:
            print(f"    {Colors.WARNING}No obvious network APIs detected{Colors.ENDC}")
            
        # Injection Points
        print(f"\n{Colors.OKCYAN}{Colors.BOLD}[⚠️]  RUNTIME/INJECTION POINTS:{Colors.ENDC}")
        if self.findings.get("injection_points"):
            # Remove duplicates
            seen = set()
            unique_points = []
            for point in self.findings["injection_points"]:
                key = (point["library"], point["function"])
                if key not in seen:
                    seen.add(key)
                    unique_points.append(point)
                    
            for point in unique_points:
                color = Colors.FAIL if point["risk_level"] == "HIGH" else Colors.WARNING
                print(f"\n    {color}[{point['risk_level']}] {point['function']}{Colors.ENDC}")
                print(f"        Library: {point['library']}")
                print(f"        Risk: {point['description']}")
        else:
            print(f"    {Colors.OKGREEN}No critical injection points detected{Colors.ENDC}")
            
        # Obfuscation Detection
        if self.findings.get("obfuscation_indicators"):
            print(f"\n{Colors.OKCYAN}{Colors.BOLD}[🛡️]  OBFUSCATION/ANTI-ANALYSIS:{Colors.ENDC}")
            for indicator in self.findings["obfuscation_indicators"][:5]:
                print(f"    {Colors.WARNING}[!] {indicator['type']}{Colors.ENDC}")
                print(f"        Library: {indicator['library']}")
                print(f"        String: {indicator['indicator']}")
                
        # Detailed Library Analysis
        if self.findings["native_libs"]:
            print(f"\n{Colors.OKCYAN}{Colors.BOLD}[📚] DETAILED LIBRARY ANALYSIS:{Colors.ENDC}")
            for lib in self.findings["native_libs"]:
                print(f"\n    {Colors.BOLD}{lib['file_name']}{Colors.ENDC}")
                print(f"    Path: {lib['file_path']}")
                print(f"    Architecture: {lib['architecture']}")
                print(f"    ELF Type: {lib.get('elf_type', 'Unknown')}")
                print(f"    JNI Functions: {len(lib['jni_functions'])}")
                print(f"    Network APIs: {len(lib['network_apis'])}")
                print(f"    Memory APIs: {len(lib['memory_apis'])}")
                print(f"    Crypto APIs: {len(lib['crypto_apis'])}")
                print(f"    Total Strings: {len(lib['strings'])}")
        else:
            print(f"\n{Colors.WARNING}[!] No native libraries analyzed{Colors.ENDC}")
            
        # Suspicious Strings
        print(f"\n{Colors.OKCYAN}{Colors.BOLD}[🔍] SUSPICIOUS STRINGS:{Colors.ENDC}")
        suspicious_found = False
        for lib in self.findings["native_libs"]:
            if lib.get("suspicious_strings"):
                suspicious_found = True
                for item in lib["suspicious_strings"][:5]:
                    print(f"    {Colors.FAIL}[{item['type']}] {item['value']}{Colors.ENDC}")
                    print(f"        Source: {lib['file_name']}")
                    
        if not suspicious_found:
            print(f"    {Colors.OKGREEN}No suspicious URLs/IPs found{Colors.ENDC}")
            
        # Recommendations
        print(f"\n{Colors.OKGREEN}{Colors.BOLD}[💡] RECOMMENDATIONS:{Colors.ENDC}")
        if self.findings.get("main_logic_candidates"):
            top_candidate = self.findings["main_logic_candidates"][0]
            print(f"    1. 🎯 Primary Target: {top_candidate['library']}")
            print(f"       Architecture: {top_candidate['architecture']}")
            print(f"       Focus dynamic analysis on this library")
            print(f"    2. 🪝 Hook JNI_OnLoad to intercept initialization")
            print(f"    3. 📡 Monitor network APIs for C2 communication")
            print(f"    4. 🔍 Check memory APIs for anti-debugging")
            
            if top_candidate.get("crypto_apis"):
                print(f"    5. 🔐 Analyze cryptographic implementations")
        else:
            print(f"    {Colors.WARNING}No specific targets identified{Colors.ENDC}")
            if not self.so_files:
                print(f"    {Colors.WARNING}This app may use Java-only code or the .so files are in a different format{Colors.ENDC}")
                
        print(f"\n{Colors.OKGREEN}{Colors.BOLD}")
        print("=" * 70)
        print("                    Analysis Complete!")
        print("=" * 70)
        print(f"{Colors.ENDC}")
        
    def save_json_report(self):
        """Save findings to JSON file"""
        report_path = self.output_dir / "analysis_report.json"
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(self.findings, f, indent=2, ensure_ascii=False, default=str)
        print(f"\n{Colors.OKGREEN}[+] Detailed report saved to: {report_path}{Colors.ENDC}")
        
    def run(self):
        """Execute full analysis pipeline"""
        self.print_banner()
        
        if not ELFFILES_AVAILABLE:
            print(f"{Colors.WARNING}[!] Running in fallback mode (strings only){Colors.ENDC}")
            print(f"{Colors.WARNING}[!] Install pyelftools for better analysis: pip install pyelftools{Colors.ENDC}")
        
        if not self.extract_apk():
            return False
            
        self.scan_all_libraries()
        self.identify_main_logic()
        self.detect_injection_points()
        self.detect_obfuscation()
        self.generate_report()
        self.save_json_report()
        
        return True

def main():
    parser = argparse.ArgumentParser(
        description="Android APK/XAPK/APKS Native Library Analyzer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Example usage:
    python3 apk_scanner.py /path/to/app.apk
    python3 apk_scanner.py /path/to/app.apks
    python3 apk_scanner.py /path/to/app.xapk -o custom_output
    
Supported formats:
    .apk  - Standard Android Package
    .apks - Android App Bundle (Split APK)
    .xapk - Extended APK (contains multiple APKs)
    .apkm - APKMirror format
    .zip  - Generic ZIP archive
    
Termux Installation:
    pkg install python python-pip binutils
    pip install pyelftools
        """
    )
    
    parser.add_argument("apk", help="Path to APK/APKS/XAPK file")
    parser.add_argument("-o", "--output", default="analysis_output", 
                       help="Output directory for analysis results")
    parser.add_argument("--strings-only", action="store_true",
                       help="Force strings-only analysis (no ELF parsing)")
    
    args = parser.parse_args()
    
    # Force strings-only mode if requested
    if args.strings_only:
        global ELFFILES_AVAILABLE
        ELFFILES_AVAILABLE = False
        
    scanner = APKNativeScanner(args.apk, args.output)
    success = scanner.run()
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
