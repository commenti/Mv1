
_______________________install______________________

# Termux पर
pkg install python python-pip binutils
pip install pyelftools

# Run
python3 apk_scanner.py /path/to/app.apk

example 


python3 apk_scanner.py /storage/emulated/0/Download/Base.apks/
