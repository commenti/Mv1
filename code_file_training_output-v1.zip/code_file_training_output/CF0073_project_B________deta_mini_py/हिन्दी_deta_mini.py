import os
import json
import time
import requests
import base64
from Crypto.Cipher import DES
from Crypto.Util.Padding import unpad

# ==========================================
# 📂 DIRECTORY STRUCTURE CONSTANTS
# ==========================================
INPUT_DIR = "1_Input_Questions"
OUTPUT_DIR = "2_Output_Answers"

os.makedirs(INPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ==========================================
# 🧹 DATA SANITIZER (100% Natural Data Preserver)
# ==========================================
def clean_ai_response(text: str) -> str:
    """सिर्फ फालतू स्पेस हटाएगा, लेकिन ओरिजिनल सिंबल्स (., ?, !, इमोजी) को 100% सुरक्षित रखेगा।"""
    if not text or not isinstance(text, str):
        return ""
    return text.strip()

# ==========================================
# 🔌 CUSTOM API 1: WECALL (Dynamic Payload + DES Decryption)
# ==========================================
def call_wecall(query: str) -> str:
    APP_KEY = b"20190826"
    APP_IV  = b"00514321"
    
    URL = "https://chatai.wecall.info/chat_new"
    
    headers = {
        "Host": "chatai.wecall.info",
        "pk": "com.ai.chat.bot.aichat",
        "ver": "212",
        "Content-Type": "application/json; charset=utf-8",
        "User-Agent": "okhttp/4.11.0"
    }
    
    payload = {
        "conversation": [],
        "model": 4, 
        "query": query
    }
    
    response = requests.post(URL, headers=headers, json=payload, timeout=60)
    response.raise_for_status()
    
    encrypted_text = response.text
    if not encrypted_text: 
        return ""
        
    cipher = DES.new(APP_KEY, DES.MODE_CBC, APP_IV)
    decrypted_bytes = cipher.decrypt(base64.b64decode(encrypted_text))
    decrypted = unpad(decrypted_bytes, DES.block_size).decode('utf-8')
    
    answer = decrypted
    if "{" in decrypted:
        try:
            data = json.loads(decrypted)
            answer = data.get("data", {}).get("answer", decrypted)
        except json.JSONDecodeError:
            pass
            
    return clean_ai_response(answer)

# ==========================================
# 🔌 CUSTOM API 2: CHATGAI (Static Payload - CURRENTLY DISABLED)
# ==========================================
def call_chatgai(query: str) -> str:
    URL = "https://api.chatgai.fun/common/sse/chat"
    
    headers = {
        "user-agent": "Dart/3.6 (dart:io)",
        "content-type": "application/json",
        "accept-encoding": "gzip",
        "host": "api.chatgai.fun"
    }
    
    static_payload = {
        "bundle": "com.aichatmaster.chat.gp",
        "security": "98156D0B138114A70A868DE0F4F1BCE27E39CC0DF87C0CFC0821CBF07579E204CD8C543BD45734867647E0D4651924D7605CAE42970FD0E2DFD63DA8E769A16E4D57B3DA584A37DD29E31D0ABF1F21C8A796CFEBF1BFD0E1F01B0649557972B4BD001F559C4C99FA3F11E541316F7A8A73866175FD6CDAFDE9F71298BF4B8A0DAA29742766A80CD0F6E62BAD2E604A444B0151A3B38B53A1C499CD42D63B47F1E644E378F595C7F831530B573D5CE12E20B9900A44BB1BB17DBD33601EF5688E199B20157F80467AD7186036189A2803DBA5047DDF8CB98F49796E693CC844943A3FF6F9B5F561464A97EACD9572A2373965FED3DCE4F60C6BE66D321B2C158E39D621415F2F9A2423BD60763315AFFB5475F2F293D8A0333EE31B55DFC857C0DAF5D8FD15F7788C3CAD6FA932467FA0508F6E5C7F173065BE948F111203221EA043F9107BB17CC2500B668DAD3CBC6048B374B4069CAFA97B47606735C7D8A36A66EEA351CA97D8003A2FE97CCFB18E6597F455E7A1ADA7D8E1AF9CE21A1913"
    }
    
    response = requests.post(URL, headers=headers, json=static_payload, stream=True, timeout=60)
    response.raise_for_status()
    
    full_response = ""
    for line in response.iter_lines():
        if line:
            decoded_line = line.decode('utf-8')
            if decoded_line.startswith("data:"):
                json_str = decoded_line.replace("data: ", "").strip()
                if json_str == "[DONE]":
                    break
                try:
                    data = json.loads(json_str)
                    chunk = data.get("data", {}).get("answer", "")
                    full_response += chunk
                except json.JSONDecodeError:
                    pass
                    
    return clean_ai_response(full_response)

# ==========================================
# 🔄 SMART API ROUTER (2-Question Rule)
# ==========================================
class SmartAPIRouter:
    def __init__(self):
        self.apis = [
            {"name": "WeCall_API", "func": call_wecall}
            # {"name": "ChatGai_API", "func": call_chatgai} 
        ]
        self.current_api_index = 0
        self.questions_served = 0

    def get_ai_response(self, question: str) -> str:
        while True:
            api = self.apis[self.current_api_index]
            try:
                print(f"  -> Sending to {api['name']}...")
                response = api["func"](question)
                
                if not response.strip():
                    raise ValueError("Received empty response from server")
                
                self.questions_served += 1
                if self.questions_served >= 2:
                    if len(self.apis) > 1:
                        print(f"  -> [Router] {api['name']} served 2 questions. Shifting API...")
                        self._switch_api()
                    else:
                        self.questions_served = 0 
                
                return response

            except Exception as e:
                print(f"  -> ❌ [ERROR] {api['name']} failed: {str(e)}")
                print("  -> 🔄 Switching API immediately to avoid crash...")
                time.sleep(1) 
                self._switch_api()

    def _switch_api(self):
        if len(self.apis) > 1:
            self.current_api_index = (self.current_api_index + 1) % len(self.apis)
        self.questions_served = 0

# ==========================================
# 🛡️ ATOMIC FILE OPERATIONS (Untouched)
# ==========================================
def atomic_write(filepath: str, data: list):
    """Saves file atomically using a .tmp file to prevent corruption on crash."""
    tmp_path = filepath + ".tmp"
    with open(tmp_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    os.replace(tmp_path, filepath)

# ==========================================
# 🚀 CORE ENGINE (Untouched - Perfectly Stable)
# ==========================================
def run_data_mining_engine():
    router = SmartAPIRouter()
    print("\n🚀 [SYSTEM STARTED] Local Engine Running on Custom APIs...\n")

    while True:
        input_files = sorted([f for f in os.listdir(INPUT_DIR) if f.endswith('.json')])
        
        if not input_files:
            print("⏳ No input JSON files found in 1_Input_Questions/. Waiting...")
            time.sleep(5)
            continue

        for filename in input_files:
            input_filepath = os.path.join(INPUT_DIR, filename)
            output_filename = filename.replace(".json", "_completed.json")
            output_filepath = os.path.join(OUTPUT_DIR, output_filename)

            print(f"\n📂 Processing File: {filename}")

            while True:
                try:
                    with open(input_filepath, 'r', encoding='utf-8') as f:
                        input_data = json.load(f)
                except json.JSONDecodeError:
                    print(f"⚠️ Invalid JSON in {filename}. Skipping file.")
                    break
                except FileNotFoundError:
                    break

                if not input_data or len(input_data) == 0:
                    os.remove(input_filepath)
                    print(f"🗑️ [DELETED] File {filename} is empty. Moving to next.")
                    break

                current_item = input_data[0]
                user_question = current_item.get("user_question", "").strip()

                if not user_question:
                    input_data.pop(0)
                    atomic_write(input_filepath, input_data)
                    continue

                print(f"\n❓ [Q] {user_question[:60]}...")

                ai_reply = router.get_ai_response(user_question)
                print(f"✅ [A] {ai_reply[:60]}...") 

                output_data = []
                if os.path.exists(output_filepath):
                    with open(output_filepath, 'r', encoding='utf-8') as f:
                        try:
                            output_data = json.load(f)
                        except json.JSONDecodeError:
                            pass
                
                output_data.append({
                    "user_question": user_question,
                    "ai_response": ai_reply
                })
                atomic_write(output_filepath, output_data)
                
                input_data.pop(0)
                atomic_write(input_filepath, input_data)
                
                print("✂️ [SAFE CUT] Data paired, saved to output, and popped from input.")

                time.sleep(2)

if __name__ == "__main__":
    try:
        run_data_mining_engine()
    except KeyboardInterrupt:
        print("\n🛑 [STOPPED] System halted safely. No data corrupted.")
