# MEMORY_MAP — File Relationship Map

This file is the project's memory map.

Its job is to answer:
“Which file is responsible for what, and which files depend on it?”

## Core flow

chat/api
→ model_profile
→ input_guard
→ context_manager
→ memory/store + summary
→ room_router
→ room_loader
→ prompt_composer
→ model_runtime
→ output_manager

## File map

| File | Main job | Reads | Writes/Calls |
|---|---|---|---|
| `config/model_profiles.json` | Defines 1B–10B model profiles and limits | model/runtime metadata | read by API, context manager, runtime |
| `config/system_limits.json` | Global safe budgets and system limits | — | read by context manager/output manager |
| `architecture/ARCHITECTURE.md` | Main architecture map | — | human reference |
| `architecture/architecture.mmd` | Machine-readable diagram | — | human/tool reference |
| `memory/conversation_store.md` | Design for full-history storage | — | used by memory layer |
| `memory/summary_policy.md` | Summary rules | context policy | used by summary manager |
| `registry/room_registry.json` | Lists available rooms | — | read by router/loader |
| `registry/room_manifest.example.json` | Defines room package format | — | template for new rooms |
| `data/schemas/dataset.schema.json` | Dataset record rules | — | used by ingestion/training |
| `data/examples/dataset.example.jsonl` | Example JSONL dataset | schema | used for testing |
| `ARCHITECTURE.md` | Main blueprint | — | human reference |

## Dependency rules

1. `Model Runtime` must not depend on the Chat UI.
2. `Context Manager` may depend on model profile and memory services, not on UI rendering.
3. `Room Router` reads the room registry; it should not know room implementation internals.
4. `Room Loader` loads room packages; it should not decide whether a room is relevant.
5. `Prompt Composer` assembles data but should not train models.
6. `Training` must be separate from inference/runtime.
7. Full history must stay available even after summarization.
8. Summary is a derived memory layer, not the only source of truth.
9. Model-specific code should stay behind `Model Runtime`.

## Safe change rule

When changing the model size:
- normally change `config/model_profiles.json`
- update the runtime adapter if the model family/protocol changes
- do NOT rewrite the Context Manager, Room Router, or memory design unless their contracts actually change.

When changing context behavior:
- normally change `Context Manager`, `Summary Manager`, and/or `system_limits`.

When adding a room:
- add the room package
- add/update the room registry
- do not rewrite the Core architecture.

When changing the UI:
- do not change model logic unless the UI/model contract itself changes.
