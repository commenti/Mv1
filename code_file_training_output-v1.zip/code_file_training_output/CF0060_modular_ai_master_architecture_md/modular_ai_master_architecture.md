# Modular AI — Master Architecture Map

Version: 1.0
Purpose: Permanent reference architecture for the project.
Initial test target: 1B-parameter Core, with the system designed to support 1B–10B model profiles without rewriting the whole application.

---

## 1. MASTER ONE-LINE ARCHITECTURE

User → Chat/API → Model Profile → Context Manager → Conversation Memory/Summary → Relevance Selector → Room Router → Required Room(s) → Prompt Composer → Core Model Runtime → Output Manager → User

---

## 2. CORE IDEA

The project is one modular AI system, not one giant neural network.

- Core = the main language/conversation/reasoning engine.
- Rooms = specialized capability modules such as Python, Math, Physics, Biology, Electronics, etc.
- Router = decides which room(s) are needed.
- Context Manager = decides exactly what information can be sent to the model within its context and output limits.
- Memory = keeps the full conversation/history outside the model.
- Summary system = compresses old conversation when needed instead of sending the full history every time.
- Model Runtime = the only layer that directly depends on the current model (1B, 2B, ... 10B).
- Training system = adds knowledge/skills gradually instead of requiring the whole system to be retrained every time.

---

## 3. CORE MODEL ARCHITECTURE

### Core responsibilities

The Core should mainly handle:

1. Language understanding.
2. Conversation.
3. General instruction following.
4. Basic reasoning/planning.
5. Understanding which specialized capability is needed.
6. Combining outputs from Rooms into a final response.

The Core is not expected to contain every domain's detailed knowledge.

### Important rule

A larger parameter count does not automatically mean a larger context window.

Context size must be treated as a separate model/runtime property.

---

## 4. ROOM ARCHITECTURE

A Room is a specialized module connected to the Core through a stable interface.

Examples:

- Python Room
- Coding Room
- Math Room
- Physics Room
- Biology Room
- Electronics Room
- Robotics Room
- Algorithms Room

A Room may later contain one or more of these:

- specialized model/adaptor parameters
- external knowledge/data
- tools/executors
- indexes/retrieval data
- room-specific instructions

Important: not every dataset must become neural parameters. Large factual datasets can remain external knowledge while small specialized behavior can be trained into a Room.

---

## 5. TOTAL PARAMETER ARCHITECTURE

The long-term goal can be expressed as:

Total system capacity = Core parameters + Room parameters + other neural modules

The target of 1T parameters does NOT mean the Core alone must contain 1T parameters.

Example only (not a fixed allocation):

- Core: language/conversation/general reasoning
- Python Room: Python specialization
- Math Room: mathematics specialization
- Physics Room: physics specialization
- Biology Room: biology specialization
- Other Rooms: additional domains

The actual parameter allocation will be decided experimentally.

External knowledge should NOT be counted as neural parameters merely because it is part of the overall AI system.

---

## 6. CONTEXT WINDOW ARCHITECTURE

The application, not the model alone, controls what is sent to the model.

Flow:

Full conversation/history
        ↓
Stored outside the model
        ↓
Context Manager
        ↓
Token budget calculation
        ↓
Old history summarized when necessary
        ↓
Relevant exact information preserved
        ↓
Relevant Rooms selected
        ↓
Prompt Composer
        ↓
Model

### Context Manager responsibilities

- Know the configured model profile.
- Know the model's actual maximum context when available.
- Apply a safe application-level budget.
- Reserve space for output.
- Reserve space for system instructions and room instructions.
- Select only relevant conversation/history.
- Trigger summarization when history becomes too large.
- Prevent accidental overflow.
- Never assume that parameter count equals context length.

### Example budget model

MAX_CONTEXT = model_context_limit

INPUT_BUDGET = MAX_CONTEXT - reserved_system - reserved_output - safety_margin

The exact numbers will be configurable and tested with the actual model.

---

## 7. CONVERSATION MEMORY + SUMMARY

Do NOT send the entire conversation to the model on every request.

Store the full history externally.

When the active context becomes too large:

1. Call the summary process.
2. Create a compact structured summary.
3. Preserve important exact snippets separately (for example code, errors, user requirements, decisions).
4. Keep recent turns in full.
5. Send only the useful combination to the next model call.

Recommended logical memory layers:

- Recent turns
- Active task state
- Structured summary
- Important exact facts/snippets
- Full archived conversation

The full history remains recoverable even after summarization.

---

## 8. MODEL PROFILE SYSTEM (INITIAL RANGE: 1B–10B)

At startup/configuration time, the system can have a model profile containing:

- parameter label: 1B / 2B / ... / 10B
- actual context limit
- safe input budget
- output limit
- tokenizer information
- protocol/runtime type
- model identifier/path
- capabilities/limitations

Important: the 1B–10B parameter label is a testing/configuration field. It is not used as the mathematical source of the context window.

Example:

model_profile = {
  size_label: "1B",
  context_limit: ...,
  max_output: ...,
  tokenizer: ...,
  runtime: ...
}

Later the same application can load a 7B or 10B model by changing the profile/runtime configuration.

---

## 9. ROUTER ARCHITECTURE

User request
    ↓
Global understanding
    ↓
Select zero, one, or multiple Rooms
    ↓
Load only required Rooms
    ↓
Run them through the Core workflow

Examples:

"Hello" → Core only

"Why does this Python code give a syntax error?" → Core + Python Room + optional Python execution tool

"Calculate this and explain the physics" → Core + Math Room + Physics Room

Router modes can be:

- manual
- automatic
- hybrid

The initial prototype should start simple and prefer explicit/controlled routing.

---

## 10. MODEL RUNTIME ARCHITECTURE

The application should never hard-code the current model throughout the codebase.

Instead:

Application
   ↓
Model Runtime Interface
   ↓
Current Model Adapter
   ↓
1B / 2B / 5B / 7B / 10B

This allows model upgrades without rewriting the Chat UI, Context Manager, Router, Rooms, Memory, and training system.

Only the model-specific runtime/adapter/configuration should normally change when the model changes.

If a future model uses a fundamentally different tokenizer/protocol/architecture, only the affected compatibility layer should be updated.

---

## 11. INCREMENTAL TRAINING ARCHITECTURE

Training is allowed to happen in small batches over time.

Example:

small dataset
   ↓
quality/dedup check
   ↓
choose destination:
   ├─ Core training
   ├─ Room training
   └─ external Knowledge Store
   ↓
evaluate
   ↓
keep version
   ↓
add next dataset later

A tiny dataset does NOT need to be forced into the Core's weights.

For the first prototype, the priority is to verify the system with a small model and small training increments rather than attempting a huge model immediately.

---

## 12. TRAINING + ROOM VERSION SAFETY

Each trained Room should remember:

- Room ID
- Room version
- Core model version/hash
- interface version
- tokenizer compatibility
- dataset fingerprint
- training configuration
- evaluation results
- dependencies

If the Core changes significantly, compatibility must be checked before loading old Rooms.

---

## 13. OUTPUT ARCHITECTURE

Model output passes through an Output Manager before reaching the user.

Output Manager can handle:

- output token limit
- malformed output detection
- tool-call/result handling
- formatting normalization
- safety/policy checks as required by the application
- response logging

The model should not be trusted to manage the application's total context budget by itself.

---

## 14. INITIAL 1B TEST PLAN

Phase 1 — Core test

- 1B model
- basic conversation
- simple instruction following
- context manager
- output limit
- memory/history handling

Phase 2 — Python Room

- add a small Python dataset
- test Python-related routing
- test code understanding
- optionally connect a Python execution/checking tool

Phase 3 — More Rooms

- add Math
- add Physics
- add other domains one at a time

Phase 4 — Scale

- improve Room quality
- improve routing
- improve context compression
- test larger models
- increase model size only when hardware and results justify it

---

# 15. FINAL FOLDER STRUCTURE

```text
modular-ai/
│
├── app/
│   ├── api/                    # Chat/API entry points
│   ├── orchestration/          # Main request flow
│   └── lifecycle/              # Startup/shutdown
│
├── core/
│   ├── model/                  # Core model files/config
│   ├── runtime/                # Model runtime interface
│   ├── adapters/               # Model-specific adapters
│   ├── tokenizer/              # Tokenizer integration
│   └── interfaces/             # Stable interfaces/contracts
│
├── context/
│   ├── manager/                # Main context controller
│   ├── budget/                 # Token budgeting
│   ├── summarizer/             # Conversation summarization
│   ├── selector/               # Relevant-history selection
│   └── policies/               # Context policies per model profile
│
├── memory/
│   ├── conversation/           # Full conversation storage
│   ├── summaries/              # Structured summaries
│   ├── facts/                  # Important exact facts/snippets
│   └── archive/                # Long-term raw history
│
├── router/
│   ├── classifier/             # Request/domain classification
│   ├── selector/               # Room selection
│   └── policies/               # Routing rules
│
├── rooms/
│   ├── registry/               # Room metadata/registry
│   ├── common/                 # Shared Room interface
│   ├── python/
│   │   ├── manifest/
│   │   ├── model/
│   │   ├── knowledge/
│   │   ├── tools/
│   │   └── tests/
│   ├── math/
│   ├── physics/
│   ├── biology/
│   ├── electronics/
│   └── .../
│
├── training/
│   ├── ingest/                 # New data intake
│   ├── clean/                  # Quality filtering
│   ├── dedup/                  # Exact/near/semantic duplicate checks
│   ├── datasets/               # Prepared datasets
│   ├── core/                   # Core training pipelines
│   ├── rooms/                  # Room training pipelines
│   ├── incremental/            # Small-step/continued training
│   └── evaluation/             # Training/eval gates
│
├── knowledge/
│   ├── indexes/                # Search/retrieval indexes
│   ├── documents/              # External knowledge
│   └── metadata/               # Sources, hashes, dates, provenance
│
├── tools/
│   ├── python/
│   ├── math/
│   └── common/
│
├── profiles/
│   ├── 1b/
│   ├── 2b/
│   ├── 3b/
│   ├── 4b/
│   ├── 5b/
│   ├── 6b/
│   ├── 7b/
│   ├── 8b/
│   ├── 9b/
│   └── 10b/
│
├── config/
│   ├── models/
│   ├── context/
│   ├── rooms/
│   ├── routing/
│   └── system/
│
├── safety/
│   ├── input/
│   └── output/
│
├── tests/
│   ├── core/
│   ├── context/
│   ├── router/
│   ├── rooms/
│   └── integration/
│
├── docs/
│   ├── architecture/
│   ├── training/
│   └── experiments/
│
├── scripts/
│   ├── setup/
│   ├── training/
│   └── evaluation/
│
└── data/
    ├── incoming/
    ├── processed/
    ├── training/
    ├── evaluation/
    └── archive/
```

---

## 16. MOST IMPORTANT DESIGN RULES

1. Core model and application logic remain separate.
2. Context management happens in the application/runtime layer.
3. Full conversation is stored externally; only relevant context is sent to the model.
4. Summary is created when context grows too large; important exact information is preserved separately.
5. Room selection is handled by the Router, not by blindly sending every Room to every request.
6. Model-specific code stays inside Model Runtime/Adapters.
7. 1B is the first test model, not a permanent architectural limitation.
8. The architecture must support 1B–10B by configuration/profile changes rather than rewrites.
9. Incremental training is supported.
10. A new dataset can become Core training, a Room, or external knowledge depending on its purpose.
11. Parameter count and context-window size are separate properties.
12. Room/Core compatibility must be versioned.
13. Full raw training data and conversation history should be retained so later versions can be rebuilt/evaluated.

---

## 17. PROJECT NORTH STAR

Start small → verify the architecture with a 1B model → add one Room at a time → train in small increments → control context intelligently → keep model-specific code isolated → scale the Core and total Room capacity only when hardware and test results justify it.
