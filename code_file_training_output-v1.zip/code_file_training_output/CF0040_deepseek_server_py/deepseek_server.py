#!/usr/bin/env python3
import os
import json
import time
from http.server import HTTPServer, BaseHTTPRequestHandler

BASE_DIR = "/storage/emulated/0/Download/ChatScraperExports/deepseek"
HOST = "127.0.0.1"
PORT = 8765

os.makedirs(os.path.join(BASE_DIR, "json_conversations"), exist_ok=True)

class DeepSeekServerHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Termux console साफ रखने के लिए default http logs बंद
        pass

    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path == "/ping":
            self.send_response(200)
            self._send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "alive", "target": "deepseek"}).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path != "/ingest_batch":
            self.send_response(404)
            self.end_headers()
            return

        try:
            content_length = int(self.headers.get("Content-Length", 0))
            raw_body = self.rfile.read(content_length).decode("utf-8", errors="replace")
            payload = json.loads(raw_body)
            
            conversations = payload.get("conversations", [])
            saved_count = 0

            jsonl_path = os.path.join(BASE_DIR, "all_conversations.jsonl")
            master_index_path = os.path.join(BASE_DIR, "all_conversations_index.json")
            ledger_path = os.path.join(BASE_DIR, "state_ledger.json")

            # Load existing index & ledger
            index_data = {}
            if os.path.exists(master_index_path):
                try:
                    with open(master_index_path, "r", encoding="utf-8") as f:
                        index_data = json.load(f)
                except Exception:
                    index_data = {}

            ledger = {}
            if os.path.exists(ledger_path):
                try:
                    with open(ledger_path, "r", encoding="utf-8") as f:
                        ledger = json.load(f)
                except Exception:
                    ledger = {}

            for chat in conversations:
                chat_id = chat.get("chat_session_id") or chat.get("id") or "unknown_id"
                title = chat.get("title", "Untitled Chat")
                # Filename safe string
                safe_title = "".join(c for c in title if c.isalnum() or c in (' ', '_', '-')).strip()[:50]
                if not safe_title:
                    safe_title = "chat"

                filename = f"{chat_id}__{safe_title}.json"
                file_path = os.path.join(BASE_DIR, "json_conversations", filename)

                # 1. Save Individual Pretty JSON (Atomic write)
                temp_json = file_path + ".tmp"
                with open(temp_json, "w", encoding="utf-8") as jf:
                    json.dump(chat, jf, indent=2, ensure_ascii=False)
                    jf.flush()
                    os.fsync(jf.fileno())
                os.replace(temp_json, file_path)

                # 2. Append to Master JSONL
                line = json.dumps(chat, ensure_ascii=False) + "\n"
                with open(jsonl_path, "a", encoding="utf-8") as jlf:
                    jlf.write(line)
                    jlf.flush()
                    os.fsync(jlf.fileno())

                # Update index & ledger
                index_data[chat_id] = {
                    "title": title,
                    "filename": filename,
                    "updated_at": chat.get("updated_at", time.time())
                }
                ledger[chat_id] = "completed"
                saved_count += 1

            # Save atomic index & ledger
            for path, data in [(master_index_path, index_data), (ledger_path, ledger)]:
                tmp_p = path + ".tmp"
                with open(tmp_p, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(tmp_p, path)

            print(f"\n\033[92m[SUCCESS]\033[0m Batch processed: {saved_count} chats saved to {BASE_DIR}")

            self.send_response(200)
            self._send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "ok", "saved": saved_count}).encode("utf-8"))

        except Exception as e:
            print(f"\n\033[91m[ERROR]\033[0m {e}")
            self.send_response(500)
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({"error": str(e)}).encode("utf-8"))

if __name__ == "__main__":
    print("====================================================")
    print(f" 🚀 DEEPSEEK BULK SERVER RUNNING ON http://{HOST}:{PORT}")
    print(f" 📂 Storage: {BASE_DIR}")
    print("====================================================")
    server = HTTPServer((HOST, PORT), DeepSeekServerHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
