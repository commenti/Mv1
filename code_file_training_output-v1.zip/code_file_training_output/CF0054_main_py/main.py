#!/usr/bin/env python3
"""
Lightweight proxy-browser backend.

No Chromium/Firefox, no Docker, no WebRTC. A single Python process:
  - Fetches pages server-side with httpx and rewrites every link, script,
    stylesheet, image, and form so subsequent navigation stays inside
    the proxy.
  - The VISITOR'S OWN real browser still renders the HTML/CSS and still
    executes any JavaScript on the page — that part is genuine, because
    it's their actual Chrome/Firefox doing it, not us.
  - What is NOT genuine: the *initial* request to the target site is made
    by this server (via httpx), not by the visitor's browser. Sites that
    run bot-detection/JS challenges (Cloudflare, etc.) see our server's
    fingerprint at that point and can still block or challenge it. Plain
    sites without such protection work normally, JS included.
  - Downloads are intercepted server-side, saved into a per-session temp
    folder (never the visitor's real disk), tracked with exact progress
    since we control the stream, and wiped when the session ends.

Run:
    python main.py --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

import argparse
import asyncio
import ipaddress
import logging
import os
import re
import shutil
import socket
import tempfile
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, Optional
from urllib.parse import urljoin, urlparse, quote, unquote

import httpx
from bs4 import BeautifulSoup
from fastapi import FastAPI, Request, Response, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware


# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

def _env(name: str, default: str) -> str:
    return os.environ.get(name, default)


HOME_URL = _env("HOME_URL", "https://www.google.com")
REQUEST_TIMEOUT_SEC = float(_env("REQUEST_TIMEOUT_SEC", "15"))
MAX_DOWNLOAD_BYTES = int(_env("MAX_DOWNLOAD_BYTES", str(200 * 1024 * 1024)))  # 200MB cap
SESSION_IDLE_TIMEOUT_SEC = float(_env("SESSION_IDLE_TIMEOUT_SEC", "1800"))  # 30 min
FAKE_UA = _env(
    "FAKE_UA",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
)
LOG_LEVEL = _env("LOG_LEVEL", "INFO")

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("proxy")

# Content types the browser can render inline; anything else past this list
# (or anything with a Content-Disposition: attachment header) is treated
# as a download rather than displayed.
RENDERABLE_PREFIXES = (
    "text/html", "text/css", "text/plain", "text/javascript",
    "application/javascript", "application/x-javascript",
    "application/json", "image/", "font/", "application/font",
    "application/xml", "text/xml", "application/manifest+json",
)

REWRITE_ATTRS = {
    "a": ["href"],
    "link": ["href"],
    "script": ["src"],
    "img": ["src"],
    "source": ["src", "srcset"],
    "form": ["action"],
    "iframe": ["src"],
}

CSS_URL_RE = re.compile(r"url\(\s*(['\"]?)([^'\")]+)\1\s*\)")


# --------------------------------------------------------------------------
# SSRF protection — this is a public, unauthenticated proxy, so it must not
# be usable to reach internal/private network resources of its own host.
# --------------------------------------------------------------------------

def is_safe_public_host(hostname: str) -> bool:
    try:
        infos = socket.getaddrinfo(hostname, None)
    except socket.gaierror:
        return False

    for info in infos:
        ip_str = info[4][0]
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            return False
        if (
            ip.is_private or ip.is_loopback or ip.is_link_local
            or ip.is_multicast or ip.is_reserved or ip.is_unspecified
        ):
            return False
    return True


def validate_target_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise HTTPException(status_code=400, detail="Only http/https URLs are allowed")
    if not parsed.hostname:
        raise HTTPException(status_code=400, detail="Invalid URL")
    if not is_safe_public_host(parsed.hostname):
        raise HTTPException(status_code=403, detail="Target host is not allowed")
    return url


# --------------------------------------------------------------------------
# Download tracking
# --------------------------------------------------------------------------

@dataclass
class DownloadEntry:
    id: str
    name: str
    total_bytes: int
    received_bytes: int = 0
    status: str = "downloading"  # downloading | complete | error
    created_at: float = field(default_factory=time.time)
    path: str = ""

    def percent(self) -> float:
        if self.total_bytes <= 0:
            return 0.0
        return min(100.0, (self.received_bytes / self.total_bytes) * 100.0)

    def public_dict(self) -> dict:
        d = {k: v for k, v in asdict(self).items() if k != "path"}
        d["percent"] = round(self.percent(), 1)
        return d


# --------------------------------------------------------------------------
# Session state — one per visitor, entirely in-memory, destroyed on end.
# --------------------------------------------------------------------------

@dataclass
class SessionState:
    id: str
    client: httpx.AsyncClient
    download_dir: Path
    downloads: Dict[str, DownloadEntry] = field(default_factory=dict)
    last_active: float = field(default_factory=time.time)
    ws_clients: list = field(default_factory=list)

    async def broadcast(self, payload: dict) -> None:
        dead = []
        for ws in self.ws_clients:
            try:
                await ws.send_json(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.ws_clients.remove(ws)


class SessionManager:
    def __init__(self) -> None:
        self._sessions: Dict[str, SessionState] = {}
        self._lock = asyncio.Lock()

    async def get_or_create(self, session_id: Optional[str]) -> SessionState:
        async with self._lock:
            if session_id and session_id in self._sessions:
                state = self._sessions[session_id]
                state.last_active = time.time()
                return state

            new_id = session_id or uuid.uuid4().hex
            download_dir = Path(tempfile.mkdtemp(prefix=f"proxysess_{new_id}_"))
            client = httpx.AsyncClient(
                follow_redirects=False,
                timeout=REQUEST_TIMEOUT_SEC,
                headers={"User-Agent": FAKE_UA},
            )
            state = SessionState(id=new_id, client=client, download_dir=download_dir)
            self._sessions[new_id] = state
            log.info("New session created: %s", new_id)
            return state

    async def get(self, session_id: str) -> Optional[SessionState]:
        async with self._lock:
            return self._sessions.get(session_id)

    async def end(self, session_id: str) -> bool:
        async with self._lock:
            state = self._sessions.pop(session_id, None)
        if not state:
            return False
        try:
            await state.client.aclose()
        except Exception:
            pass
        shutil.rmtree(state.download_dir, ignore_errors=True)
        log.info("Session ended and wiped: %s", session_id)
        return True

    async def sweep_idle(self) -> None:
        now = time.time()
        async with self._lock:
            stale_ids = [
                sid for sid, st in self._sessions.items()
                if now - st.last_active > SESSION_IDLE_TIMEOUT_SEC
            ]
        for sid in stale_ids:
            log.info("Sweeping idle session: %s", sid)
            await self.end(sid)


sessions = SessionManager()


# --------------------------------------------------------------------------
# URL rewriting helpers
# --------------------------------------------------------------------------

def proxy_url_for(target: str) -> str:
    return f"/proxy?url={quote(target, safe='')}"


def absolutize_and_proxify(raw: str, base_url: str) -> str:
    raw = raw.strip()
    if not raw or raw.startswith(("javascript:", "data:", "mailto:", "tel:", "#")):
        return raw
    try:
        absolute = urljoin(base_url, raw)
    except ValueError:
        return raw
    return proxy_url_for(absolute)


def rewrite_srcset(value: str, base_url: str) -> str:
    parts = []
    for candidate in value.split(","):
        candidate = candidate.strip()
        if not candidate:
            continue
        pieces = candidate.split()
        url_part = pieces[0]
        descriptor = " ".join(pieces[1:])
        new_url = absolutize_and_proxify(url_part, base_url)
        parts.append(f"{new_url} {descriptor}".strip())
    return ", ".join(parts)


def rewrite_css_urls(css_text: str, base_url: str) -> str:
    def _sub(match: re.Match) -> str:
        original = match.group(2)
        if original.startswith("data:"):
            return match.group(0)
        new_url = absolutize_and_proxify(original, base_url)
        return f"url('{new_url}')"
    return CSS_URL_RE.sub(_sub, css_text)


def rewrite_html(html_text: str, base_url: str) -> str:
    soup = BeautifulSoup(html_text, "lxml")

    # Respect a <base> tag if the page declares one, then strip it since
    # everything is now absolute and proxied anyway.
    base_tag = soup.find("base", href=True)
    effective_base = urljoin(base_url, base_tag["href"]) if base_tag else base_url
    if base_tag:
        base_tag.decompose()

    for tag_name, attrs in REWRITE_ATTRS.items():
        for tag in soup.find_all(tag_name):
            for attr in attrs:
                if not tag.has_attr(attr):
                    continue
                if attr == "srcset":
                    tag[attr] = rewrite_srcset(tag[attr], effective_base)
                else:
                    tag[attr] = absolutize_and_proxify(tag[attr], effective_base)

    # Inline <style> blocks and style="" attributes with url(...) refs.
    for style_tag in soup.find_all("style"):
        if style_tag.string:
            style_tag.string.replace_with(rewrite_css_urls(style_tag.string, effective_base))

    for tag in soup.find_all(style=True):
        tag["style"] = rewrite_css_urls(tag["style"], effective_base)

    # Meta refresh redirects.
    for meta in soup.find_all("meta", attrs={"http-equiv": re.compile("refresh", re.I)}):
        content = meta.get("content", "")
        m = re.search(r"url=(.+)$", content, re.I)
        if m:
            target = m.group(1).strip("'\" ")
            new_target = absolutize_and_proxify(target, effective_base)
            meta["content"] = re.sub(r"url=.+$", f"url={new_target}", content, flags=re.I)

    # Inject a small client-side shim: relative fetch()/XHR calls made by
    # the page's own JS (running for real in the visitor's browser) get
    # routed back through the proxy too, so same-origin API calls keep
    # working after the initial load.
    shim = soup.new_tag("script")
    shim.string = f"""
    (function() {{
        const PROXY_PREFIX = "/proxy?url=";
        const BASE = {effective_base!r};
        function toProxied(u) {{
            try {{
                const abs = new URL(u, BASE).href;
                if (abs.startsWith(window.location.origin)) return abs;
                return PROXY_PREFIX + encodeURIComponent(abs);
            }} catch (e) {{ return u; }}
        }}
        const origFetch = window.fetch;
        window.fetch = function(input, init) {{
            if (typeof input === "string") input = toProxied(input);
            return origFetch(input, init);
        }};
        const origOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url, ...rest) {{
            return origOpen.call(this, method, toProxied(url), ...rest);
        }};
    }})();
    """
    if soup.head:
        soup.head.insert(0, shim)
    elif soup.html:
        soup.html.insert(0, shim)

    return str(soup)


# --------------------------------------------------------------------------
# FastAPI app
# --------------------------------------------------------------------------

app = FastAPI(title="Lightweight Proxy Browser", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

_sweeper_stop = asyncio.Event()


@app.on_event("startup")
async def on_startup():
    async def sweeper():
        while not _sweeper_stop.is_set():
            try:
                await sessions.sweep_idle()
            except Exception:
                log.exception("Idle sweep failed")
            await asyncio.sleep(60)
    asyncio.create_task(sweeper())
    log.info("Proxy browser backend started. Home URL: %s", HOME_URL)


async def _get_session(request: Request, response: Response) -> SessionState:
    session_id = request.cookies.get("sid")
    state = await sessions.get_or_create(session_id)
    if session_id != state.id:
        response.set_cookie("sid", state.id, httponly=True, samesite="lax")
    return state


@app.get("/", response_class=HTMLResponse)
async def home():
    return RedirectResponse(url=proxy_url_for(HOME_URL))


@app.get("/proxy")
async def proxy_get(request: Request, response: Response, url: str):
    target = unquote(url)
    validate_target_url(target)
    state = await _get_session(request, response)
    state.last_active = time.time()

    try:
        upstream = await state.client.get(target)
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Upstream site timed out")
    except httpx.RequestError as exc:
        log.warning("Upstream fetch failed for %s: %s", target, exc)
        raise HTTPException(status_code=502, detail=f"Could not reach target site: {exc}")

    # Manual redirect handling so the redirect target also goes through /proxy.
    if upstream.status_code in (301, 302, 303, 307, 308):
        location = upstream.headers.get("location")
        if location:
            absolute = urljoin(target, location)
            redirect = RedirectResponse(url=proxy_url_for(absolute), status_code=302)
            redirect.set_cookie("sid", state.id, httponly=True, samesite="lax")
            return redirect

    content_type = upstream.headers.get("content-type", "").lower()
    disposition = upstream.headers.get("content-disposition", "")

    is_attachment = "attachment" in disposition.lower()
    is_renderable = any(content_type.startswith(p) for p in RENDERABLE_PREFIXES)

    if is_attachment or not is_renderable:
        return await _handle_download(state, target, upstream, content_type, disposition)

    if content_type.startswith("text/html"):
        try:
            rewritten = rewrite_html(upstream.text, target)
        except Exception:
            log.exception("HTML rewrite failed for %s, serving raw content", target)
            rewritten = upstream.text
        resp = HTMLResponse(content=rewritten, status_code=upstream.status_code)
        resp.set_cookie("sid", state.id, httponly=True, samesite="lax")
        return resp

    if content_type.startswith("text/css"):
        rewritten_css = rewrite_css_urls(upstream.text, target)
        return Response(content=rewritten_css, media_type="text/css")

    # Other renderable types (images, fonts, js, json) — pass through as-is.
    return Response(content=upstream.content, media_type=content_type or "application/octet-stream")


async def _handle_download(
    state: SessionState, target: str, upstream: httpx.Response,
    content_type: str, disposition: str,
) -> HTMLResponse:
    filename = None
    m = re.search(r'filename\*?="?([^";]+)"?', disposition)
    if m:
        filename = os.path.basename(unquote(m.group(1)))
    if not filename:
        filename = os.path.basename(urlparse(target).path) or f"download-{uuid.uuid4().hex[:8]}"

    total_bytes = int(upstream.headers.get("content-length", "0") or 0)
    if total_bytes > MAX_DOWNLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds the maximum allowed download size")

    download_id = uuid.uuid4().hex
    dest_path = state.download_dir / f"{download_id}_{filename}"
    entry = DownloadEntry(id=download_id, name=filename, total_bytes=total_bytes, path=str(dest_path))
    state.downloads[download_id] = entry
    await state.broadcast({"type": "download_update", "data": entry.public_dict()})

    received = 0
    try:
        with open(dest_path, "wb") as f:
            async for chunk in upstream.aiter_bytes(chunk_size=65536):
                f.write(chunk)
                received += len(chunk)
                if received > MAX_DOWNLOAD_BYTES:
                    raise HTTPException(status_code=413, detail="Download exceeded size limit mid-transfer")
                entry.received_bytes = received
                await state.broadcast({"type": "download_update", "data": entry.public_dict()})
        entry.status = "complete"
        entry.received_bytes = max(entry.received_bytes, entry.total_bytes)
    except Exception as exc:
        entry.status = "error"
        log.warning("Download failed for %s: %s", filename, exc)
    finally:
        await state.broadcast({"type": "download_update", "data": entry.public_dict()})

    html = f"""
    <html><body style="font-family:sans-serif;background:#0f1724;color:#e0e6f0;
    display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
      <div style="text-align:center">
        <p>Saved: <strong>{filename}</strong></p>
        <p style="opacity:.7;font-size:13px">Check the Downloads panel. It will not survive
        this session and cannot be installed as an app.</p>
        <button onclick="history.back()" style="padding:8px 16px;border-radius:6px;
        border:none;background:#2f6feb;color:white;cursor:pointer">Go back</button>
      </div>
    </body></html>
    """
    return HTMLResponse(content=html)


@app.get("/api/downloads")
async def list_downloads(request: Request, response: Response):
    state = await _get_session(request, response)
    return {"downloads": [d.public_dict() for d in state.downloads.values()]}


@app.delete("/api/downloads/{download_id}")
async def delete_download(download_id: str, request: Request, response: Response):
    state = await _get_session(request, response)
    entry = state.downloads.get(download_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Download not found")
    try:
        Path(entry.path).unlink(missing_ok=True)
    except OSError as exc:
        log.warning("Failed to delete file for %s: %s", download_id, exc)
    del state.downloads[download_id]
    await state.broadcast({"type": "download_removed", "data": {"id": download_id}})
    return {"deleted": download_id}


@app.post("/api/session/end")
async def end_session(request: Request):
    session_id = request.cookies.get("sid")
    if not session_id:
        return {"ended": False}
    ended = await sessions.end(session_id)
    resp = Response(status_code=200)
    resp.delete_cookie("sid")
    return {"ended": ended}


@app.websocket("/ws/downloads")
async def downloads_ws(ws: WebSocket):
    session_id = ws.cookies.get("sid")
    if not session_id:
        await ws.close(code=4001)
        return
    state = await sessions.get(session_id)
    if not state:
        await ws.close(code=4004)
        return

    await ws.accept()
    state.ws_clients.append(ws)
    try:
        await ws.send_json({"type": "snapshot", "data": [d.public_dict() for d in state.downloads.values()]})
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        if ws in state.ws_clients:
            state.ws_clients.remove(ws)


@app.get("/api/health")
async def health():
    return {"status": "ok"}


def main() -> None:
    parser = argparse.ArgumentParser(description="Lightweight proxy browser backend")
    parser.add_argument("--host", default=_env("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(_env("PORT", "8000")))
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()

    import uvicorn
    uvicorn.run("main:app", host=args.host, port=args.port, reload=args.reload, log_level=LOG_LEVEL.lower())


if __name__ == "__main__":
    main()
