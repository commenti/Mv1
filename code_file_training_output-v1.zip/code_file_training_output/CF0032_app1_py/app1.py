"""
Telegram-to-Website Gallery App (v2)
--------------------------------------
Kya naya hai is version me:
  1. Image ab PURI dikhegi (crop nahi hogi) - YouTube jaisa layout:
     media upar, title/description/hashtag/link neeche.
  2. Photo ke alawa Video aur Audio bhi support karta hai, aur
     donon HTML5 <video>/<audio> tag se STREAM hote hain (seek bhi kar
     sakte hain beech me se).
  3. Auto-refresh ab JavaScript se hota hai (har 5 second me), page
     reload nahi hota, isliye chal rahe video/audio bhi disturb nahi
     honge, aur naya upload bina app restart kiye khud-ba-khud aa jaayega.

Local testing ke liye:
    1) pip install -r requirements.txt
    2) Neeche CONFIG section me BOT_TOKEN aur ADMIN_CHAT_ID daalein
    3) python app.py
    4) Browser: http://127.0.0.1:5000
    5) Bot ko photo/video/audio bhejiye, caption me:
            Title: Sunset Beach
            Description: Evening walk on the beach
            Hashtag: #travel #nature
            Link: https://example.com/beach-info

IMPORTANT LIMIT: Telegram Bot API se bot sirf 20MB tak ki file
download kar sakta hai. Bade video is limit se upar fail ho jaayenge
(neeche terminal me [ERROR] dikhega).

NOTE: Agar aapke paas pehle wali (v1) gallery.db file hai, to use
delete kar dein taaki naya schema clean bane:
    rm gallery.db
"""

import os
import re
import time
import uuid
import sqlite3
import threading
from datetime import datetime

import requests
from flask import Flask, render_template_string, send_from_directory, jsonify, Response

# ============================================================
# CONFIG -- Yahan apni values daalein
# ============================================================
BOT_TOKEN = "8823855710:AAH9couwpgdq8EaHou8pnOAoVCYDBs7LydE"        # BotFather se mila token
ADMIN_CHAT_ID = "8374289893"      # Sirf isi chat_id se messages accept honge

# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "gallery.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
TELEGRAM_API = f"https://api.telegram.org/bot{BOT_TOKEN}"
TELEGRAM_FILE_API = f"https://api.telegram.org/file/bot{BOT_TOKEN}"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)


# ============================================================
# DATABASE HELPERS (SQLite -- ek simple local file, koi bill nahi)
# ============================================================
def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS gallery (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            description TEXT,
            hashtags TEXT,
            link TEXT,
            media_type TEXT,
            media_path TEXT,
            created_at TEXT
        )
        """
    )
    # Purani DB file me agar naye columns missing hain to add kar dein
    existing_cols = {row[1] for row in conn.execute("PRAGMA table_info(gallery)").fetchall()}
    for col, coltype in [("description", "TEXT"), ("media_type", "TEXT"), ("media_path", "TEXT")]:
        if col not in existing_cols:
            conn.execute(f"ALTER TABLE gallery ADD COLUMN {col} {coltype}")
    conn.commit()
    conn.close()


def save_entry(title, description, hashtags, link, media_type, media_path):
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """INSERT INTO gallery
           (title, description, hashtags, link, media_type, media_path, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (title, description, hashtags, link, media_type, media_path,
         datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    )
    conn.commit()
    conn.close()


def get_all_entries():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("SELECT * FROM gallery ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# CAPTION PARSER -- Title / Description / Hashtag / Link
# ============================================================
def parse_caption(caption):
    if not caption:
        return "(No title)", "", "", ""

    title_match = re.search(r"title\s*:\s*(.+)", caption, re.IGNORECASE)
    desc_match = re.search(r"desc(?:ription)?\s*:\s*(.+)", caption, re.IGNORECASE)
    hashtag_match = re.search(r"hashtag\s*:\s*(.+)", caption, re.IGNORECASE)
    link_match = re.search(r"link\s*:\s*(.+)", caption, re.IGNORECASE)

    if not (title_match or desc_match or hashtag_match or link_match):
        # Structured format nahi mila -> poori caption title bana do
        return caption.strip(), "", "", ""

    title = title_match.group(1).strip() if title_match else "(No title)"
    description = desc_match.group(1).strip() if desc_match else ""
    hashtags = hashtag_match.group(1).strip() if hashtag_match else ""
    link = link_match.group(1).strip() if link_match else ""
    return title, description, hashtags, link


# ============================================================
# TELEGRAM POLLING (background thread)
# ============================================================
def default_ext(media_type):
    return {"photo": ".jpg", "video": ".mp4", "audio": ".mp3"}.get(media_type, "")


def download_media(file_id, media_type):
    """Telegram se media download karke local static/uploads me save karta hai."""
    file_info = requests.get(f"{TELEGRAM_API}/getFile", params={"file_id": file_id}, timeout=15).json()
    if not file_info.get("ok"):
        raise RuntimeError(f"getFile failed: {file_info}")

    file_path = file_info["result"]["file_path"]
    file_url = f"{TELEGRAM_FILE_API}/{file_path}"

    ext = os.path.splitext(file_path)[1] or default_ext(media_type)
    local_filename = f"{uuid.uuid4().hex}{ext}"
    local_full_path = os.path.join(UPLOAD_FOLDER, local_filename)

    resp = requests.get(file_url, timeout=60)
    resp.raise_for_status()
    with open(local_full_path, "wb") as f:
        f.write(resp.content)

    return f"uploads/{local_filename}"  # relative path served via /static/


def detect_media(message):
    """Message me photo/video/audio/voice/document me se jo bhi mila,
    uska (media_type, file_id) return karta hai. Nahi mila to (None, None)."""
    if message.get("photo"):
        return "photo", message["photo"][-1]["file_id"]

    if message.get("video"):
        return "video", message["video"]["file_id"]

    if message.get("audio"):
        return "audio", message["audio"]["file_id"]

    if message.get("voice"):
        return "audio", message["voice"]["file_id"]

    document = message.get("document")
    if document:
        mime = document.get("mime_type", "")
        if mime.startswith("video/"):
            return "video", document["file_id"]
        if mime.startswith("audio/"):
            return "audio", document["file_id"]
        if mime.startswith("image/"):
            return "photo", document["file_id"]

    return None, None


def process_update(update):
    try:
        message = update.get("message")
        if not message:
            return

        chat_id = str(message.get("chat", {}).get("id", ""))

        # ---- PRIVACY CHECK: sirf admin ka chat_id allow hai ----
        if chat_id != str(ADMIN_CHAT_ID):
            print(f"[IGNORED] Unauthorized chat_id: {chat_id}")
            return

        media_type, file_id = detect_media(message)
        if not media_type:
            print("[SKIPPED] Message me photo/video/audio nahi mila.")
            return

        caption = message.get("caption", "")
        title, description, hashtags, link = parse_caption(caption)

        print(f"[RECEIVED] type={media_type} title={title!r}")
        media_path = download_media(file_id, media_type)
        save_entry(title, description, hashtags, link, media_type, media_path)
        print(f"[SAVED] {title} ({media_type})")

    except Exception as e:
        # Kuch bhi galat ho, polling thread kabhi crash nahi hona chahiye
        print(f"[ERROR] process_update fail hua: {e}")


def telegram_polling_loop():
    print("Telegram polling shuru ho gayi hai... (Ctrl+C se rokein)")
    offset = None
    while True:
        try:
            params = {"timeout": 30}
            if offset is not None:
                params["offset"] = offset

            resp = requests.get(f"{TELEGRAM_API}/getUpdates", params=params, timeout=35)
            data = resp.json()

            if not data.get("ok"):
                print(f"[TELEGRAM ERROR] {data}")
                time.sleep(5)
                continue

            for update in data.get("result", []):
                offset = update["update_id"] + 1
                process_update(update)

        except requests.exceptions.RequestException as e:
            print(f"[NETWORK ERROR] {e} -- 5 second me retry karega")
            time.sleep(5)
        except Exception as e:
            print(f"[UNEXPECTED ERROR] {e} -- polling jaari rahegi")
            time.sleep(5)


def start_polling_supervisor():
    """Agar kisi wajah se polling thread mar jaaye, to use dobara start
    kar deta hai -- taaki app restart kiye bina bhi polling chalti rahe."""
    def supervisor():
        while True:
            t = threading.Thread(target=telegram_polling_loop, daemon=True)
            t.start()
            t.join()
            print("[SUPERVISOR] Polling thread ruk gayi thi, dobara start kar rahe hain...")
            time.sleep(2)

    threading.Thread(target=supervisor, daemon=True).start()


# ============================================================
# WEBSITE (HTML isi file me embedded hai)
# ============================================================
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Private Gallery</title>
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: -apple-system, Segoe UI, Roboto, sans-serif;
            background: #0f1115;
            color: #e6e6e6;
            margin: 0;
            padding: 24px;
        }
        h1 { text-align: center; margin-bottom: 4px; }
        .subtitle {
            text-align: center;
            color: #9aa0a6;
            margin-bottom: 32px;
            font-size: 14px;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            max-width: 1300px;
            margin: 0 auto;
        }
        .card {
            background: #1a1d24;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.4);
        }
        /* Media (photo/video) ke liye fixed-ratio box jisme PURI cheez
           dikhe (object-fit: contain) -- crop nahi hoti */
        .media-box {
            width: 100%;
            aspect-ratio: 16 / 10;
            background: #000;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .media-box img, .media-box video {
            width: 100%;
            height: 100%;
            object-fit: contain;
            display: block;
            background: #000;
        }
        .audio-box {
            padding: 20px 14px 4px 14px;
            background: #12151b;
        }
        .audio-box audio { width: 100%; }
        .card-body { padding: 14px; }
        .card-body h3 { margin: 0 0 6px 0; font-size: 17px; }
        .description {
            color: #c7c9cc;
            font-size: 13.5px;
            margin-bottom: 8px;
            line-height: 1.4;
        }
        .hashtags { color: #4da3ff; font-size: 13px; margin-bottom: 8px; }
        .link a { color: #7fdc7f; font-size: 13px; word-break: break-all; }
        .timestamp { color: #6b7280; font-size: 11px; margin-top: 8px; }
        .empty { text-align: center; color: #6b7280; margin-top: 60px; }
        .live-dot {
            display: inline-block;
            width: 8px; height: 8px;
            background: #3ddc84;
            border-radius: 50%;
            margin-right: 6px;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse { 0%,100% {opacity:1;} 50% {opacity:.3;} }
    </style>
</head>
<body>
    <h1>Private Gallery</h1>
    <p class="subtitle"><span class="live-dot"></span>Live -- naya upload khud-ba-khud yahan aa jaayega</p>

    <div id="gallery" class="grid"></div>
    <p id="emptyMsg" class="empty" style="display:none;">Abhi tak koi upload nahi hua. Apne Telegram bot ko photo/video/audio bhejiye!</p>

<script>
let lastRenderedIds = "";

function mediaHtml(entry) {
    if (entry.media_type === "video") {
        return `<div class="media-box"><video controls preload="metadata" src="/static/${entry.media_path}"></video></div>`;
    }
    if (entry.media_type === "audio") {
        return `<div class="audio-box"><audio controls preload="metadata" src="/static/${entry.media_path}"></audio></div>`;
    }
    return `<div class="media-box"><img src="/static/${entry.media_path}" alt="${entry.title}"></div>`;
}

function render(entries) {
    const idsKey = entries.map(e => e.id).join(",");
    if (idsKey === lastRenderedIds) return; // kuch naya nahi, DOM chhedo mat (video/audio chalte rahenge)
    lastRenderedIds = idsKey;

    const gallery = document.getElementById("gallery");
    const emptyMsg = document.getElementById("emptyMsg");

    if (entries.length === 0) {
        gallery.innerHTML = "";
        emptyMsg.style.display = "block";
        return;
    }
    emptyMsg.style.display = "none";

    gallery.innerHTML = entries.map(entry => `
        <div class="card">
            ${mediaHtml(entry)}
            <div class="card-body">
                <h3>${entry.title}</h3>
                ${entry.description ? `<div class="description">${entry.description}</div>` : ""}
                ${entry.hashtags ? `<div class="hashtags">${entry.hashtags}</div>` : ""}
                ${entry.link ? `<div class="link"><a href="${entry.link}" target="_blank">${entry.link}</a></div>` : ""}
                <div class="timestamp">${entry.created_at}</div>
            </div>
        </div>
    `).join("");
}

async function fetchEntries() {
    try {
        const res = await fetch("/api/entries", {cache: "no-store"});
        const data = await res.json();
        render(data);
    } catch (e) {
        console.error("Fetch failed:", e);
    }
}

fetchEntries();
setInterval(fetchEntries, 5000); // har 5 second me check karega
</script>
</body>
</html>
"""


@app.route("/")
def index():
    resp = Response(render_template_string(HTML_TEMPLATE))
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/api/entries")
def api_entries():
    resp = jsonify(get_all_entries())
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/static/uploads/<path:filename>")
def uploaded_file(filename):
    # conditional=True (Flask default) => Range requests supported =>
    # video/audio seek/streaming kaam karta hai
    return send_from_directory(UPLOAD_FOLDER, filename, conditional=True)


# ============================================================
# STARTUP
# ============================================================
if __name__ == "__main__":
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE" or ADMIN_CHAT_ID == "YOUR_CHAT_ID_HERE":
        print("=" * 60)
        print("Pehle CONFIG section me BOT_TOKEN aur ADMIN_CHAT_ID daalein!")
        print("=" * 60)

    init_db()
    start_polling_supervisor()

    print("Website chal rahi hai: http://127.0.0.1:5000")
    app.run(debug=False, port=5000)