import json
import re
import os
import logging
from typing import Dict

# CONFIGURATION
BLACKLIST_FILE = "blacklist.json"
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("SecurityFortress")

# --------------------------------------------------
# ATTACK SIGNATURES (REGEX)
# --------------------------------------------------
ATTACK_PATTERNS = {
    "XSS": re.compile(r"(<script>|<iframe>|javascript:|onerror=|onload=)", re.IGNORECASE),
    "SQL_INJECTION": re.compile(r"(DROP TABLE|SELECT \*|UNION ALL|OR 1=1|--|INSERT INTO)", re.IGNORECASE),
    "DIR_TRAVERSAL": re.compile(r"(\.\./|\.\.\\|/etc/passwd|c:\\windows)", re.IGNORECASE),
    "CMD_INJECTION": re.compile(r"(curl |wget |chmod |rm -rf|\|\||&&)", re.IGNORECASE)
}

def load_blacklist() -> Dict[str, str]:
    """Loads the blacklist from disk."""
    if not os.path.exists(BLACKLIST_FILE):
        return {}
    try:
        with open(BLACKLIST_FILE, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        return {}

def save_blacklist(data: Dict[str, str]):
    """Persists the blacklist to disk."""
    with open(BLACKLIST_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def is_ip_banned(ip: str) -> bool:
    """
    GATEKEEPER CHECK.
    Returns True if the IP is permanently banned.
    """
    blacklist = load_blacklist()
    return ip in blacklist

def ban_ip(ip: str, reason: str):
    """
    PUNISHMENT SYSTEM.
    Permanently adds IP to blacklist.json.
    """
    blacklist = load_blacklist()
    if ip not in blacklist:
        blacklist[ip] = reason
        save_blacklist(blacklist)
        logger.critical(f"⛔ IP BANNED PERMANENTLY: {ip} | Reason: {reason}")

def scan_for_attack(input_string: str, ip: str) -> bool:
    """
    TRAP SYSTEM.
    Scans input against regex signatures.
    If malicious, BANS IP IMMEDIATELY.
    """
    if not input_string:
        return False

    for attack_type, pattern in ATTACK_PATTERNS.items():
        if pattern.search(input_string):
            reason = f"Attack Detected: {attack_type} in payload '{input_string}'"
            ban_ip(ip, reason)
            return True # Attack detected
    return False