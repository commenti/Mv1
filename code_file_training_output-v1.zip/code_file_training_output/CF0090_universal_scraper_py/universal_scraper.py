#!/usr/bin/env python3
import os
import re
import sys
import json
import time
import gzip
import zlib
import threading
import urllib.request
import urllib.error
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

# ==============================================================================
# DIRECTORY & FILE PATHS
# ==============================================================================
BASE_DIR = "/storage/emulated/0/Download/ChatScraperSystem"
API_VAULT_DIR = os.path.join(BASE_DIR, "api_vault")
API_JSON_FILE = os.path.join(API_VAULT_DIR, "apis.json")
API_JSONL_BACKUP = os.path.join(API_VAULT_DIR, "apis_raw_stream.jsonl")
RESULTS_DIR = os.path.join(BASE_DIR, "results")

HOST = "127.0.0.1"
PORT = 8765
CURRENT_MODE = "IDLE"  # "FIND_API" or "SCRAPE"

os.makedirs(API_VAULT_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

FILE_LOCK = threading.Lock()
STATE_LOCK = threading.Lock()

# Live HUD State for Browser Overlay
HUD_STATE = {
    "running": False,
    "mode": "IDLE",
    "phase": "idle",        # idle | paginating | downloading | token_expired | error | completed | stopped
    "site_host": "",
    "total_chats": 0,
    "completed_chats": 0,
    "skipped_chats": 0,
    "failed_chats": 0,
    "speed_chats_per_sec": 0.0,
    "eta_seconds": 0,
    "start_time": 0.0,
    "stop_requested": False,
    "error_reason": "",
    "message": "Ready"
}

UUID_REGEX = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')


# ==============================================================================
# SAFE ANDROID STORAGE HELPERS (NO EPERM / FSYNC CRASHES)
# ==============================================================================
def safe_fsync(fd):
    try:
        os.fsync(fd)
    except OSError:
        pass


def atomic_write_json(filepath, data):
    tmp_path = filepath + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.flush()
        safe_fsync(f.fileno())
    os.replace(tmp_path, filepath)


def append_jsonl(filepath, data):
    line = json.dumps(data, ensure_ascii=False) + "\n"
    with open(filepath, "a", encoding="utf-8") as f:
        f.write(line)
        f.flush()
        safe_fsync(f.fileno())


def load_json_file(filepath, default_val):
    if not os.path.exists(filepath):
        return default_val
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"\033[91m[JSON READ ERROR]\033[0m {filepath} में सिंटैक्स एरर है: {e}")
        return default_val


def sanitize_filename(name):
    cleaned = re.sub(r'[\\/*?:"<>|\r\n\t]+', "_", str(name or "Untitled")).strip()
    return cleaned[:60] or "Untitled"


# ==============================================================================
# LAYER 3: DUAL-FORMAT STORAGE ENGINE (JSON + JSONL + LEDGER IN results/)
# ==============================================================================
class UniversalStorageEngine:
    def __init__(self, site_host):
        safe_site = site_host.replace(":", "_") or "unknown_site"
        self.site_dir = os.path.join(RESULTS_DIR, safe_site)
        self.conv_dir = os.path.join(self.site_dir, "json_conversations")
        os.makedirs(self.conv_dir, exist_ok=True)

        self.jsonl_path = os.path.join(self.site_dir, "all_conversations.jsonl")
        self.master_json_path = os.path.join(self.site_dir, "all_conversations_master.json")
        self.index_json_path = os.path.join(self.site_dir, "all_conversations_index.json")
        self.ledger_path = os.path.join(self.site_dir, "state_ledger.json")

        self.lock = threading.Lock()
        self.ledger = load_json_file(self.ledger_path, {})
        self.index = load_json_file(self.index_json_path, {})

    def is_already_saved(self, chat_id, updated_at=None):
        entry = self.ledger.get(str(chat_id))
        if not entry:
            return False
        if updated_at and entry.get("updated_at") and entry.get("updated_at") != updated_at:
            return False
        return True

    def save_chat(self, chat_id, title, updated_at, raw_data, clean_messages=None):
        with self.lock:
            cid = str(chat_id)
            safe_title = sanitize_filename(title)
            filename = f"{cid}__{safe_title}.json"
            indiv_path = os.path.join(self.conv_dir, filename)

            record = {
                "chat_id": cid,
                "title": title,
                "updated_at": updated_at,
                "scraped_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "messages": clean_messages if clean_messages is not None else [],
                "raw_response": raw_data
            }

            # 1. Save Individual Pretty JSON
            atomic_write_json(indiv_path, record)

            # 2. Append to Master JSONL
            append_jsonl(self.jsonl_path, record)

            # 3. Update Index & Resume Ledger
            self.index[cid] = {
                "chat_id": cid,
                "title": title,
                "updated_at": updated_at,
                "file": f"json_conversations/{filename}"
            }
            self.ledger[cid] = {
                "status": "completed",
                "title": title,
                "updated_at": updated_at,
                "saved_at": record["scraped_at"]
            }

            atomic_write_json(self.index_json_path, self.index)
            atomic_write_json(self.ledger_path, self.ledger)

    def build_master_bundle(self):
        with self.lock:
            all_items = []
            for fname in sorted(os.listdir(self.conv_dir)):
                if fname.endswith(".json"):
                    fpath = os.path.join(self.conv_dir, fname)
                    try:
                        with open(fpath, "r", encoding="utf-8") as f:
                            all_items.append(json.load(f))
                    except Exception:
                        pass
            atomic_write_json(self.master_json_path, {
                "exported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "total_conversations": len(all_items),
                "conversations": all_items
            })


# ==============================================================================
# MODE 1: API FIND & CAPTURE ENGINE (Saves to api_vault/apis.json)
# ==============================================================================
def auto_classify_endpoint(url, method, resp_preview):
    """Automatically guesses if an API is a LIST_API, DETAIL_API, or OTHER"""
    u_lower = url.lower()
    preview_str = json.dumps(resp_preview, ensure_ascii=False).lower() if resp_preview else ""

    # Detail API patterns (has specific chat_id / uuid in query or path)
    if any(k in u_lower for k in ["history_messages", "chat_session_id=", "conversation_id=", "/messages"]):
        return "DETAIL_API"
    if UUID_REGEX.search(url) and not any(k in u_lower for k in ["settings", "did=", "device"]):
        return "DETAIL_API"

    # List API patterns (pagination / session list)
    if any(k in u_lower for k in ["fetch_page", "conversations", "chat_sessions", "session/list", "chat_list", "threads"]):
        return "LIST_API"
    if any(k in preview_str for k in ["chat_sessions", "has_more", '"items":']):
        return "LIST_API"

    return "OTHER_API"


def save_captured_api_to_vault(payload):
    """Mode 1: Tampermonkey se aaye API ko deduplicate karke apis.json me save karta hai"""
    with FILE_LOCK:
        url = payload.get("url", "")
        method = payload.get("method", "GET").upper()
        site_host = payload.get("site_host", "unknown")
        headers = payload.get("request_headers", {})
        req_body = payload.get("request_body")
        resp_preview = payload.get("response_preview")

        # Normalize signature so same endpoint doesn't repeat 100 times
        parsed = urlparse(url)
        # Replace UUIDs in path with {ID} just for deduplication key
        norm_path = UUID_REGEX.sub("{UUID}", parsed.path)
        query_keys = sorted(parse_qs(parsed.query).keys())
        signature = f"{method} {parsed.netloc}{norm_path}?{'&'.join(query_keys)}"

        vault_data = load_json_file(API_JSON_FILE, {"instructions": "", "apis": []})
        if isinstance(vault_data, list):
            apis_list = vault_data
        else:
            apis_list = vault_data.get("apis", [])

        role_guess = auto_classify_endpoint(url, method, resp_preview)

        # Update existing endpoint if signature matches, else append new
        existing_idx = None
        for idx, item in enumerate(apis_list):
            if item.get("_signature") == signature:
                existing_idx = idx
                break

        entry = {
            "id": (existing_idx + 1) if existing_idx is not None else (len(apis_list) + 1),
            "role": role_guess,  # LIST_API | DETAIL_API | OTHER_API
            "site_host": site_host,
            "method": method,
            "url": url,
            "headers": headers,
            "request_body": req_body,
            "status": payload.get("status", 200),
            "last_captured": time.strftime("%Y-%m-%d %H:%M:%S"),
            "response_preview": resp_preview,
            "_signature": signature
        }

        if existing_idx is not None:
            # Merge latest non-empty headers (keep latest Bearer token)
            merged_headers = dict(apis_list[existing_idx].get("headers", {}))
            merged_headers.update({k: v for k, v in headers.items() if v})
            entry["headers"] = merged_headers
            # Keep user's manual role if they already edited it
            if apis_list[existing_idx].get("role") in ("LIST_API", "DETAIL_API", "DIRECT_API"):
                entry["role"] = apis_list[existing_idx]["role"]
            apis_list[existing_idx] = entry
            is_new = False
        else:
            apis_list.append(entry)
            is_new = True

        output_doc = {
            "_instructions": (
                "इस फाइल में Mode 1 से कैप्चर किए गए API हैं। स्क्रैप करने से पहले फालतू (OTHER_API) ब्लॉक हटा दें "
                "और सिर्फ काम के API (जैसे LIST_API और DETAIL_API) छोड़कर फाइल सेव करें, फिर Mode 2 चलाएं।"
            ),
            "total_saved_apis": len(apis_list),
            "apis": apis_list
        }

        atomic_write_json(API_JSON_FILE, output_doc)
        append_jsonl(API_JSONL_BACKUP, entry)

        tag_color = "\033[92m" if role_guess in ("LIST_API", "DETAIL_API") else "\033[90m"
        status_tag = "NEW" if is_new else "UPDATED"
        print(f"{tag_color}[{status_tag} #{entry['id']} | {role_guess}]\033[0m [{site_host}] {method} {url[:95]}")


# ==============================================================================
# MODE 2: UNIVERSAL SCRAPE ENGINE (Reads from api_vault/apis.json -> results/)
# ==============================================================================
def execute_http_request(method, url, headers, body=None, timeout=25):
    """Executes HTTP call with captured headers & automatic gzip/deflate decoding"""
    parsed = urlparse(url)
    origin = f"{parsed.scheme}://{parsed.netloc}"
    req_headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate",
        "Origin": origin,
        "Referer": origin + "/"
    }
    for k, v in (headers or {}).items():
        if v and k.lower() not in ("host", "content-length", "accept-encoding"):
            req_headers[k] = v

    data_bytes = None
    if body and method.upper() in ("POST", "PUT", "PATCH"):
        if isinstance(body, (dict, list)):
            data_bytes = json.dumps(body).encode("utf-8")
        elif isinstance(body, str):
            data_bytes = body.encode("utf-8")

    req = urllib.request.Request(url, data=data_bytes, headers=req_headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw_bytes = resp.read()
            encoding = (resp.info().get("Content-Encoding") or "").lower()
            if "gzip" in encoding:
                raw_bytes = gzip.decompress(raw_bytes)
            elif "deflate" in encoding:
                raw_bytes = zlib.decompress(raw_bytes)
            text = raw_bytes.decode("utf-8", errors="replace")
            try:
                return resp.status, json.loads(text)
            except Exception:
                return resp.status, {"_raw_text": text}
    except urllib.error.HTTPError as he:
        err_body = ""
        try:
            err_body = he.read().decode("utf-8", errors="replace")[:300]
        except Exception:
            pass
        return he.code, {"_http_error": he.code, "_error_body": err_body}
    except Exception as e:
        return 0, {"_network_error": str(e)}


def extract_conversations_from_json(data):
    """
    Universal parser: Kisi bhi website (DeepSeek, ChatGPT, Claude, etc.) ke
    List API JSON response ke andar se conversation objects (id + title) dhoondhta hai.
    """
    found = []

    def walk(node):
        if isinstance(node, list):
            # Check if this list looks like a list of chat sessions
            for item in node:
                if isinstance(item, dict):
                    cid = (
                        item.get("id")
                        or item.get("chat_session_id")
                        or item.get("conversation_id")
                        or item.get("uuid")
                        or item.get("session_id")
                        or item.get("thread_id")
                    )
                    # Verify it looks like a conversation item (has title, updated_at, or messages/snippet)
                    has_meta = any(k in item for k in ("title", "name", "updated_at", "create_time", "inserted_at", "summary"))
                    if cid and has_meta:
                        found.append({
                            "id": str(cid),
                            "title": item.get("title") or item.get("name") or item.get("summary") or "Untitled Chat",
                            "updated_at": item.get("updated_at") or item.get("update_time") or item.get("inserted_at") or item.get("create_time"),
                            "raw_item": item
                        })
                    else:
                        walk(item)
        elif isinstance(node, dict):
            for k, v in node.items():
                walk(v)

    walk(data)
    return found


def extract_universal_messages(data):
    """Kisi bhi website ke Detail API JSON se messages list nikalta hai"""
    messages = []

    # 1. ChatGPT mapping object style
    if isinstance(data, dict) and isinstance(data.get("mapping"), dict):
        for node_id, node in data["mapping"].items():
            msg = node.get("message") if isinstance(node, dict) else None
            if isinstance(msg, dict):
                author = (msg.get("author") or {}).get("role", "unknown")
                content_obj = msg.get("content") or {}
                parts = content_obj.get("parts") or []
                text = "\n".join(str(p) for p in parts if isinstance(p, (str, int, float)))
                if text:
                    messages.append({
                        "message_id": msg.get("id") or node_id,
                        "role": author,
                        "content": text,
                        "created_at": msg.get("create_time")
                    })
        return messages

    # 2. Standard array style (DeepSeek, Claude, Qwen, etc.)
    def find_msg_list(node):
        if isinstance(node, dict):
            for key in ("chat_messages", "messages", "history", "items", "turns"):
                if isinstance(node.get(key), list) and len(node[key]) > 0:
                    return node[key]
            for v in node.values():
                res = find_msg_list(v)
                if res:
                    return res
        return None

    raw_list = find_msg_list(data)
    if isinstance(raw_list, list):
        for m in raw_list:
            if not isinstance(m, dict):
                continue
            role = m.get("role") or m.get("sender") or m.get("author") or "unknown"
            content = m.get("content") or m.get("text") or ""
            thinking = m.get("thinking_content") or m.get("reasoning_content") or ""
            if not content and isinstance(m.get("fragments"), list):
                content = "\n".join(str(f.get("content", "")) for f in m["fragments"] if isinstance(f, dict))
            messages.append({
                "message_id": m.get("message_id") or m.get("id") or m.get("uuid"),
                "role": role,
                "content": content,
                "thinking_content": thinking,
                "created_at": m.get("inserted_at") or m.get("created_at") or m.get("timestamp")
            })
    return messages


def build_detail_url_for_chat(template_url, chat_id):
    """
    Detail API ke sample URL me jahan purana chat_id ya UUID tha,
    wahan naya chat_id automatically fit karta hai.
    """
    if "{CHAT_ID}" in template_url:
        return template_url.replace("{CHAT_ID}", str(chat_id))

    parsed = urlparse(template_url)
    qs = parse_qs(parsed.query, keep_blank_values=True)

    # Check common query parameters first (e.g., ?chat_session_id=xxx, ?conversation_id=xxx, ?id=xxx)
    for key in list(qs.keys()):
        if any(k in key.lower() for k in ("chat_session_id", "conversation_id", "session_id", "chat_id", "thread_id", "id")):
            qs[key] = [str(chat_id)]
            new_query = urlencode(qs, doseq=True)
            return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))

    # Otherwise replace the last UUID in the URL path (e.g., /backend-api/conversation/<uuid>)
    matches = list(UUID_REGEX.finditer(template_url))
    if matches:
        last_match = matches[-1]
        return template_url[:last_match.start()] + str(chat_id) + template_url[last_match.end():]

    # Fallback: replace last path segment
    path_parts = parsed.path.rstrip("/").split("/")
    if len(path_parts) > 1:
        path_parts[-1] = str(chat_id)
        new_path = "/".join(path_parts)
        return urlunparse((parsed.scheme, parsed.netloc, new_path, parsed.params, parsed.query, parsed.fragment))

    return template_url


def paginate_universal_list_api(list_api_entry):
    """
    Universal Pagination: List API se saare pages loop karke 100% chats nikalta hai.
    Supports DeepSeek cursor, ChatGPT offset/limit, next_cursor, aur single-page lists.
    """
    base_url = list_api_entry["url"]
    method = list_api_entry.get("method", "GET")
    headers = list_api_entry.get("headers", {})
    body = list_api_entry.get("request_body")

    all_sessions = []
    seen_ids = set()

    # Check if this is DeepSeek style (lte_cursor.pinned)
    is_deepseek = "lte_cursor.pinned" in base_url
    pinned_passes = ["true", "false"] if is_deepseek else [None]

    for pinned_val in pinned_passes:
        current_url = base_url
        if is_deepseek:
            # Reset cursor for each pass
            parsed = urlparse(base_url)
            qs = parse_qs(parsed.query)
            qs["lte_cursor.pinned"] = [pinned_val]
            qs.pop("lte_cursor.updated_at", None)
            current_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, urlencode(qs, doseq=True), parsed.fragment))

        page = 0
        offset = 0

        while True:
            with STATE_LOCK:
                if HUD_STATE["stop_requested"]:
                    return all_sessions

            page += 1
            status, resp_data = execute_http_request(method, current_url, headers, body)

            # Check for Expired Token / Cloudflare Error
            if status in (401, 403):
                raise PermissionError(
                    f"HTTP {status} (Token Expired या Cloudflare Block)! URL: {current_url}"
                )
            if status == 0 or status >= 400:
                raise RuntimeError(
                    f"API Request Failed (Status: {status}) -> {resp_data}"
                )

            batch = extract_conversations_from_json(resp_data)
            new_in_batch = 0
            for item in batch:
                if item["id"] not in seen_ids:
                    seen_ids.add(item["id"])
                    all_sessions.append(item)
                    new_in_batch += 1

            print(f" \033[96m[LIST PAGE {page}]\033[0m Found {new_in_batch} chats (Total so far: {len(all_sessions)})")
            with STATE_LOCK:
                HUD_STATE["total_chats"] = len(all_sessions)
                HUD_STATE["message"] = f"Discovering chats... ({len(all_sessions)} found)"

            if new_in_batch == 0:
                break

            # 1. DeepSeek Pagination Check (has_more + lte_cursor.updated_at)
            biz = (resp_data.get("data") or {}).get("biz_data") if isinstance(resp_data.get("data"), dict) else None
            target_dict = biz if isinstance(biz, dict) else resp_data
            if is_deepseek and isinstance(target_dict, dict):
                has_more = target_dict.get("has_more", False)
                last_updated = batch[-1].get("updated_at")
                if has_more and last_updated:
                    parsed = urlparse(current_url)
                    qs = parse_qs(parsed.query)
                    qs["lte_cursor.updated_at"] = [str(last_updated)]
                    current_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, urlencode(qs, doseq=True), parsed.fragment))
                    continue
                break

            # 2. Offset/Limit Pagination Check (ChatGPT style: ?offset=0&limit=28)
            parsed = urlparse(current_url)
            qs = parse_qs(parsed.query)
            if "offset" in qs and "limit" in qs:
                limit_val = int(qs["limit"][0])
                offset += len(batch)
                total_avail = resp_data.get("total")
                if total_avail and offset >= int(total_avail):
                    break
                if len(batch) < limit_val:
                    break
                qs["offset"] = [str(offset)]
                current_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, urlencode(qs, doseq=True), parsed.fragment))
                continue

            # 3. Generic next_cursor Pagination Check
            next_cursor = resp_data.get("next_cursor") or (resp_data.get("data") or {}).get("next_cursor")
            if next_cursor and "cursor" in qs:
                qs["cursor"] = [str(next_cursor)]
                current_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, urlencode(qs, doseq=True), parsed.fragment))
                continue

            break

    return all_sessions


def update_hud_metrics():
    with STATE_LOCK:
        done = HUD_STATE["completed_chats"] + HUD_STATE["skipped_chats"] + HUD_STATE["failed_chats"]
        total = HUD_STATE["total_chats"]
        elapsed = max(time.time() - HUD_STATE["start_time"], 0.1)
        speed = round(done / elapsed, 2)
        rem = max(total - done, 0)
        HUD_STATE["speed_chats_per_sec"] = speed
        HUD_STATE["eta_seconds"] = int(rem / speed) if speed > 0 else 0


def run_universal_scrape_job():
    """
    Mode 2 Core Engine:
    api_vault/apis.json ko padhta hai, List API aur Detail API uthata hai,
    aur saara data scrape karke results/<site_host>/ me save karta hai.
    """
    vault_doc = load_json_file(API_JSON_FILE, {})
    apis_list = vault_doc if isinstance(vault_doc, list) else vault_doc.get("apis", [])

    if not apis_list:
        print(f"\n\033[91m[EMPTY VAULT]\033[0m '{API_JSON_FILE}' खाली है! पहले Mode 1 चलाकर API कैप्चर करें।")
        return

    # Merge headers across all kept APIs from the same site so Authorization token is never missed
    site_host = apis_list[0].get("site_host", "unknown_site")
    merged_headers = {}
    for entry in apis_list:
        for k, v in (entry.get("headers") or {}).items():
            if v:
                merged_headers[k] = v

    # Separate into LIST_API, DETAIL_API, or DIRECT_API
    list_api = None
    detail_api = None
    other_apis = []

    for entry in apis_list:
        role = entry.get("role") or auto_classify_endpoint(entry.get("url", ""), entry.get("method", "GET"), entry.get("response_preview"))
        entry["headers"] = {**merged_headers, **(entry.get("headers") or {})}
        if role == "LIST_API" and not list_api:
            list_api = entry
        elif role == "DETAIL_API" and not detail_api:
            detail_api = entry
        else:
            other_apis.append(entry)

    # Smart fallback if user left exactly 2 APIs without checking role names
    if not list_api and not detail_api and len(apis_list) >= 2:
        list_api = apis_list[0]
        detail_api = apis_list[1]

    storage = UniversalStorageEngine(site_host)

    with STATE_LOCK:
        HUD_STATE.update({
            "running": True,
            "mode": "SCRAPE",
            "phase": "paginating",
            "site_host": site_host,
            "total_chats": 0,
            "completed_chats": 0,
            "skipped_chats": 0,
            "failed_chats": 0,
            "start_time": time.time(),
            "stop_requested": False,
            "error_reason": "",
            "message": f"Starting scrape for {site_host}..."
        })

    print("\n====================================================")
    print(f" ⚡ STARTING UNIVERSAL SCRAPE MODE")
    print(f" 🌐 Website       : {site_host}")
    print(f" 📄 Source Config : {API_JSON_FILE}")
    print(f" 📂 Saving To     : {storage.site_dir}")
    print("====================================================")

    try:
        # CASE 1: Full List + Detail Bulk Scraping (Standard Chat History Pattern)
        if list_api and detail_api:
            print(f" ├─ List API   : {list_api['url'][:80]}")
            print(f" └─ Detail API : {detail_api['url'][:80]}\n")

            sessions = paginate_universal_list_api(list_api)
            total = len(sessions)

            with STATE_LOCK:
                HUD_STATE["total_chats"] = total
                HUD_STATE["phase"] = "downloading"

            if total == 0:
                print("\033[93m[WARN]\033[0m List API से 0 चैट्स मिलीं।")
                with STATE_LOCK:
                    HUD_STATE["running"] = False
                    HUD_STATE["phase"] = "completed"
                    HUD_STATE["message"] = "0 chats found."
                return

            print(f"\n\033[92m[DISCOVERED]\033[0m कुल {total} चैट्स मिलीं! अब Parallel Bulk Download शुरू हो रहा है (6 Workers)...\n")

            def download_worker(sess):
                with STATE_LOCK:
                    if HUD_STATE["stop_requested"]:
                        return "stopped"

                cid = sess["id"]
                title = sess["title"]
                updated_at = sess.get("updated_at")

                if storage.is_already_saved(cid, updated_at):
                    with STATE_LOCK:
                        HUD_STATE["skipped_chats"] += 1
                    update_hud_metrics()
                    print(f" \033[90m[SKIPPED - ALREADY SAVED]\033[0m {title[:45]} ({cid})")
                    return "skipped"

                target_url = build_detail_url_for_chat(detail_api["url"], cid)
                status, detail_json = execute_http_request(
                    detail_api.get("method", "GET"),
                    target_url,
                    detail_api["headers"],
                    detail_api.get("request_body")
                )

                if status in (401, 403):
                    raise PermissionError(f"HTTP {status} (Token Expired / Unauthorized) on chat {cid}")
                if status == 0 or status >= 400:
                    raise RuntimeError(f"HTTP {status} failed for {cid}")

                clean_msgs = extract_universal_messages(detail_json)
                storage.save_chat(cid, title, updated_at, detail_json, clean_msgs)

                with STATE_LOCK:
                    HUD_STATE["completed_chats"] += 1
                    HUD_STATE["message"] = f"Saved: {title[:35]}"
                update_hud_metrics()

                done_now = HUD_STATE["completed_chats"] + HUD_STATE["skipped_chats"]
                print(f" \033[92m[{done_now}/{total} SAVED]\033[0m {title[:45]} ({len(clean_msgs)} msgs)")
                return "saved"

            with ThreadPoolExecutor(max_workers=6) as pool:
                futures = [pool.submit(download_worker, s) for s in sessions]
                for fut in as_completed(futures):
                    with STATE_LOCK:
                        if HUD_STATE["stop_requested"]:
                            break
                    try:
                        fut.result()
                    except PermissionError as pe:
                        # Token expired mid-scrape! Stop immediately and alert user
                        with STATE_LOCK:
                            HUD_STATE["stop_requested"] = True
                            HUD_STATE["running"] = False
                            HUD_STATE["phase"] = "token_expired"
                            HUD_STATE["error_reason"] = str(pe)
                            HUD_STATE["message"] = f"❌ API TOKEN EXPIRED ({pe})! Run Mode 1 again."
                        print(f"\n\033[91m====================================================\033[0m")
                        print(f"\033[91m ❌ [API EXPIRED / AUTH ERROR]: {pe}\033[0m")
                        print(f"\033[93m 💡 समाधान: वेबसाइट का टोकन एक्सपायर हो गया है। स्क्रिप्ट में Mode 1 चुनें और ब्राउज़र रिफ्रेश करें।\033[0m")
                        print(f"\033[92m ✅ चिंता न करें: अब तक सेव हुईं {HUD_STATE['completed_chats']} चैट्स सुरक्षित हैं और अगली बार स्किप हो जाएंगी!\033[0m")
                        print(f"\033[91m====================================================\033[0m\n")
                        return
                    except Exception as ex:
                        with STATE_LOCK:
                            HUD_STATE["failed_chats"] += 1
                        update_hud_metrics()
                        print(f" \033[91m[ERROR]\033[0m {ex}")

        # CASE 2: Direct API Scraping (Agar user ne apis.json me 1 ya N direct APIs rakhe hain)
        else:
            print(" \033[93m[DIRECT MODE]\033[0m अलग List+Detail जोड़ी नहीं मिली। apis.json के सभी URLs को सीधे स्क्रैप किया जा रहा है...\n")
            with STATE_LOCK:
                HUD_STATE["total_chats"] = len(apis_list)
                HUD_STATE["phase"] = "downloading"

            for idx, entry in enumerate(apis_list, start=1):
                url = entry.get("url", "")
                method = entry.get("method", "GET")
                hdrs = entry.get("headers", {})
                body = entry.get("request_body")

                status, resp_json = execute_http_request(method, url, hdrs, body)
                if status in (401, 403):
                    raise PermissionError(f"HTTP {status} Token Expired on {url}")
                if status == 0 or status >= 400:
                    print(f" \033[91m[FAILED #{idx}]\033[0m HTTP {status} -> {url}")
                    with STATE_LOCK:
                        HUD_STATE["failed_chats"] += 1
                    continue

                clean_msgs = extract_universal_messages(resp_json)
                cid = f"api_{idx}_{int(time.time())}"
                storage.save_chat(cid, f"Direct_API_{idx}", int(time.time()), resp_json, clean_msgs)
                with STATE_LOCK:
                    HUD_STATE["completed_chats"] += 1
                update_hud_metrics()
                print(f" \033[92m[{idx}/{len(apis_list)} SAVED]\033[0m {url[:75]}")

        # Build Final Master JSON Bundle
        storage.build_master_bundle()

        with STATE_LOCK:
            HUD_STATE["running"] = False
            HUD_STATE["phase"] = "completed"
            HUD_STATE["message"] = (
                f"Done! Saved: {HUD_STATE['completed_chats']}, "
                f"Skipped: {HUD_STATE['skipped_chats']}, "
                f"Failed: {HUD_STATE['failed_chats']}"
            )

        print("\n====================================================")
        print(f" 🎉 SCRAPING COMPLETED SUCCESSFULLY!")
        print(f" ✅ Newly Saved   : {HUD_STATE['completed_chats']}")
        print(f" ⏭️  Skipped (Old) : {HUD_STATE['skipped_chats']}")
        print(f" ❌ Failed        : {HUD_STATE['failed_chats']}")
        print(f" 📂 Results Path  : {storage.site_dir}")
        print("====================================================\n")

    except PermissionError as pe:
        with STATE_LOCK:
            HUD_STATE["running"] = False
            HUD_STATE["phase"] = "token_expired"
            HUD_STATE["error_reason"] = str(pe)
            HUD_STATE["message"] = f"❌ Token Expired: {pe}"
        print(f"\n\033[91m====================================================\033[0m")
        print(f"\033[91m ❌ [API EXPIRED / BLOCKED]: {pe}\033[0m")
        print(f"\033[93m 💡 समाधान: API टोकन एक्सपायर हो गया है। कृपया मेनू से Mode 1 चुनें और वेबसाइट को एक बार रिफ्रेश करें।\033[0m")
        print(f"\033[91m====================================================\033[0m\n")

    except Exception as e:
        with STATE_LOCK:
            HUD_STATE["running"] = False
            HUD_STATE["phase"] = "error"
            HUD_STATE["error_reason"] = str(e)
            HUD_STATE["message"] = f"Error: {e}"
        print(f"\n\033[91m[SCRAPE ERROR]\033[0m {e}\n")


# ==============================================================================
# HTTP SERVER FOR TAMPERMONKEY COMMUNICATION (BOTH MODES)
# ==============================================================================
class UniversalServerHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def _send_json(self, code, data):
        self.send_response(code)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def do_OPTIONS(self):
        self._send_json(200, {"ok": True})

    def do_GET(self):
        if self.path == "/status":
            with STATE_LOCK:
                done = HUD_STATE["completed_chats"] + HUD_STATE["skipped_chats"] + HUD_STATE["failed_chats"]
                total = HUD_STATE["total_chats"]
                rem = max(total - done, 0)
                pct = int((done / total) * 100) if total > 0 else 0
                out = dict(HUD_STATE)
                out["server_mode"] = CURRENT_MODE
                out["done_chats"] = done
                out["remaining_chats"] = rem
                out["percent"] = pct
            self._send_json(200, out)
        else:
            self._send_json(404, {"error": "Not found"})

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length).decode("utf-8", errors="replace") if length > 0 else "{}"
        try:
            payload = json.loads(raw)
        except Exception:
            payload = {}

        # Endpoint 1: Tampermonkey sends captured API requests here
        if self.path == "/capture_api":
            if CURRENT_MODE == "FIND_API":
                save_captured_api_to_vault(payload)
                self._send_json(200, {"ok": True, "mode": "FIND_API", "saved": True})
            else:
                # Even in SCRAPE mode, if browser sends fresh auth headers for the same site, auto-refresh token in apis.json!
                self._send_json(200, {"ok": True, "mode": CURRENT_MODE, "saved": False})
            return

        # Endpoint 2: Trigger Scrape Mode from Browser button
        if self.path == "/trigger_scrape":
            with STATE_LOCK:
                if HUD_STATE["running"]:
                    self._send_json(200, {"ok": True, "already_running": True})
                    return
            threading.Thread(target=run_universal_scrape_job, daemon=True).start()
            self._send_json(200, {"ok": True, "started": True})
            return

        # Endpoint 3: Emergency Stop from Browser HUD
        if self.path == "/stop":
            with STATE_LOCK:
                HUD_STATE["stop_requested"] = True
                HUD_STATE["running"] = False
                HUD_STATE["phase"] = "stopped"
                HUD_STATE["message"] = "Stopped by user."
            print("\n\033[91m[EMERGENCY STOP]\033[0m यूज़र ने स्क्रैपिंग रोक दी।")
            self._send_json(200, {"ok": True})
            return

        self._send_json(404, {"error": "Unknown route"})


# ==============================================================================
# INTERACTIVE HELPER: AUTO-CLEAN GARBAGE FROM apis.json
# ==============================================================================
def interactive_clean_vault():
    vault_doc = load_json_file(API_JSON_FILE, {})
    apis_list = vault_doc if isinstance(vault_doc, list) else vault_doc.get("apis", [])
    if not apis_list:
        print(f"\n\033[93m[INFO]\033[0m '{API_JSON_FILE}' में अभी कोई API नहीं है।")
        return

    print("\n---------------- CURRENT CAPTURED APIs ----------------")
    for idx, item in enumerate(apis_list, start=1):
        role = item.get("role", "OTHER_API")
        color = "\033[92m" if role in ("LIST_API", "DETAIL_API") else "\033[90m"
        print(f" [{idx}] {color}{role:10}\033[0m | {item.get('method')} {item.get('url')[:75]}")
    print("-------------------------------------------------------")
    print(" [A] Auto-Keep ONLY 'LIST_API' & 'DETAIL_API' (गार्बेज अपने-आप हटाएं)")
    print(" [M] Manual Select (जैसे: 1,3 लिखकर सिर्फ उन्हें रखें)")
    print(" [B] Back to Main Menu (आप सीधे फाइल को टेक्स्ट एडिटर में भी एडिट कर सकते हैं)")

    choice = input("\nअपना विकल्प चुनें (A/M/B): ").strip().upper()
    if choice == "A":
        kept = [x for x in apis_list if x.get("role") in ("LIST_API", "DETAIL_API")]
        if not kept:
            print("\033[91m[WARN]\033[0m कोई LIST_API या DETAIL_API ऑटो-डिटेक्ट नहीं हुआ। कृपया Manual [M] या टेक्स्ट एडिटर का उपयोग करें।")
            return
        for i, x in enumerate(kept, 1):
            x["id"] = i
        atomic_write_json(API_JSON_FILE, {"total_saved_apis": len(kept), "apis": kept})
        print(f"\033[92m[CLEANED]\033[0m गार्बेज हटा दिया गया! अब '{API_JSON_FILE}' में सिर्फ {len(kept)} ज़रूरी API बचे हैं।")
    elif choice == "M":
        nums = input("जिन API नंबरों को रखना है उन्हें कॉमा से लिखें (उदा. 2,5): ").strip()
        keep_indices = {int(n.strip()) for n in nums.split(",") if n.strip().isdigit()}
        kept = [x for idx, x in enumerate(apis_list, start=1) if idx in keep_indices]
        for i, x in enumerate(kept, 1):
            x["id"] = i
        atomic_write_json(API_JSON_FILE, {"total_saved_apis": len(kept), "apis": kept})
        print(f"\033[92m[SAVED]\033[0m अब '{API_JSON_FILE}' में सिर्फ आपके चुने हुए {len(kept)} API सेव हो गए हैं।")


# ==============================================================================
# MAIN MENU LOOP
# ==============================================================================
def main():
    global CURRENT_MODE

    # Start background HTTP server once so Tampermonkey is always connected
    server = ThreadingHTTPServer((HOST, PORT), UniversalServerHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()

    while True:
        print("\n====================================================")
        print(" 🚀 UNIVERSAL AI CHAT SCRAPER (2-MODE SYSTEM)")
        print("====================================================")
        print(f" 📄 API JSON File  : {API_JSON_FILE}")
        print(f" 📂 Results Folder : {RESULTS_DIR}")
        print("----------------------------------------------------")
        print(" [1] 🔍 MODE 1: API FIND MODE   (Tampermonkey से नए API पकड़कर apis.json में सेव करें)")
        print(" [2] ⚡ MODE 2: SCRAPE MODE     (apis.json से क्लीन किए गए API उठाकर बल्क स्क्रैप करें)")
        print(" [3] 🧹 VIEW / CLEAN apis.json  (गार्बेज API हटाने का शॉर्टकट या फाइल चेक करें)")
        print(" [0] ❌ EXIT")
        print("====================================================")

        choice = input("अपना मोड चुनें (1 / 2 / 3 / 0): ").strip()

        if choice == "1":
            clear_q = input("\nक्या 'apis.json' के पुराने डेटा को साफ करके नया कैप्चर शुरू करें? (Y/n): ").strip().lower()
            if clear_q in ("", "y", "yes"):
                atomic_write_json(API_JSON_FILE, {"total_saved_apis": 0, "apis": []})
                print("\033[92m[RESET]\033[0m apis.json साफ कर दिया गया है।")

            CURRENT_MODE = "FIND_API"
            with STATE_LOCK:
                HUD_STATE["mode"] = "FIND_API"
                HUD_STATE["phase"] = "idle"
                HUD_STATE["message"] = "Mode 1 Active: Capturing APIs to apis.json"

            print("\n====================================================")
            print(" 📡 MODE 1 (API FIND MODE) ACTIVE!")
            print(f" 👉 अब ब्राउज़र में कोई भी वेबसाइट खोलें, चैट लिस्ट स्क्रॉल करें और 1 चैट पर क्लिक करें।")
            print(f" 👉 सारे काम के API '{API_JSON_FILE}' में सेव हो रहे हैं।")
            print(" 👉 जब कैप्चर हो जाए, तो मेनू में वापस आने के लिए [ENTER] दबाएं...")
            print("====================================================\n")
            try:
                input()
            except KeyboardInterrupt:
                pass
            CURRENT_MODE = "IDLE"
            print(f"\n\033[93m[PAUSED]\033[0m Mode 1 रोक दिया गया। आप '{API_JSON_FILE}' को टेक्स्ट एडिटर में क्लीन कर सकते हैं या [3] दबाकर क्लीन कर सकते हैं।")

        elif choice == "2":
            CURRENT_MODE = "SCRAPE"
            run_universal_scrape_job()
            CURRENT_MODE = "IDLE"

        elif choice == "3":
            interactive_clean_vault()

        elif choice == "0":
            print("\nExiting Universal Scraper. Goodbye!")
            sys.exit(0)


if __name__ == "__main__":
    main()
