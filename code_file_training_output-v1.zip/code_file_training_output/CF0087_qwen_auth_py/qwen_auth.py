import requests
import time
import uuid
import json

TOKEN = ""
CHAT_ID = ""

# अपनी डिटेल्स यहाँ डालें (HTML वाले टूल से)
X_MINI_WUA = "a+gQcm7yAYQ1VRFxZyC9XrZLxsIzF42WwrcGgCQy0+PFz6aBGQ5M0uoGc5l4PKfZgF02sJ5SdNytk28x8/EohbRyRku025VeuWAtklwxSeYpe9ac/Lh4uH64URsbfu5vE5p9ttFw5T9Io8us3F/X3s9okkVuNe1RE0sF1Vcx9TDhrYQ=="
EMAIL = "fasox89127@noxgem.com"
PASSWORD = "415b7b84f715cacacb7f145a4aa405b69826fd82531dbea6b36a0f2187282497"
USER_AGENT = "Dalvik/2.1.0 (Linux; U; Android 15; SM-A146B Build/AP3A.240905.015.A2) AliApp(QWENCHAT/1.14.1)"

session = requests.Session()

def login_and_get_chat():
    global TOKEN, CHAT_ID
    print("[Auth] System login kar raha hai...")
    
    try:
        # --- 1. LOGIN REQUEST ---
        login_url = "https://chat.qwen.ai/api/v2/auths/signin"
        headers = {
            "User-Agent": USER_AGENT,
            "Content-Type": "application/json",
            "x-mini-wua": X_MINI_WUA
        }
        res = session.post(login_url, headers=headers, json={"email": EMAIL, "password": PASSWORD})
        
        if res.status_code != 200: 
            print(f"[Auth] ❌ Login Failed! Status Code: {res.status_code}")
            print(f"[Detector] Raw Response: {res.text}")
            return False
            
        TOKEN = res.json()['data']['token']
        print("[Auth] ✅ Token mil gaya!")
        session.cookies.set("token", TOKEN, domain=".qwen.ai")
        
        # --- 2. CREATE CHAT REQUEST (यहीं पिछली बार क्रैश हुआ था) ---
        chat_headers = {
            "User-Agent": USER_AGENT,
            "Authorization": f"Bearer {TOKEN}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Platform": "android",
            "source": "app"
        }
        
        print("[Auth] Naya session (Chat ID) bana raha hoon...")
        chat_res = session.post("https://chat.qwen.ai/api/v2/chats/new", headers=chat_headers, json={"chat_mode": "normal", "project_id": ""})
        
        # DETECTOR MODE: यहाँ हम चेक करेंगे कि सर्वर ने क्या जवाब दिया
        if chat_res.status_code == 200:
            try:
                CHAT_ID = chat_res.json()['data']['id']
                print(f"[Auth] ✅ Session Ready! Chat ID: {CHAT_ID}")
                return True
            except json.JSONDecodeError:
                print("[Detector] ❌ Status 200 aaya, lekin response JSON nahi hai!")
                print(f"[Detector] Raw Response Text: '{chat_res.text}'")
                return False
        else:
            print(f"[Auth] ❌ Chat banane mein error aaya! Status Code: {chat_res.status_code}")
            print(f"[Detector] Server ka asli jawab: '{chat_res.text}'")
            return False
            
    except Exception as e:
        print(f"[Auth] ❌ Code Crash Error: {e}")
        return False

def ask_qwen(message_history):
    if not TOKEN or not CHAT_ID:
        if not login_and_get_chat(): 
            return "Error: Authentication ya Chat creation fail ho gaya."
        
    url = f"https://chat.qwen.ai/api/v2/chat/completions?chat_id={CHAT_ID}"
    headers = {
        "User-Agent": USER_AGENT,
        "Authorization": f"Bearer {TOKEN}", 
        "Content-Type": "application/json", 
        "Accept": "text/event-stream",
        "X-Platform": "android",
        "source": "app",
        "x-mini-wua": X_MINI_WUA
    }
    
    # incremental_output: True add karna zaroori hai
    payload = {
        "stream": True, 
        "incremental_output": True, 
        "chat_id": CHAT_ID, 
        "chat_mode": "normal", 
        "model": "qwen3.5-plus",
        "timestamp": int(time.time()),
        "messages": message_history
    }

    full_response = ""
    try:
        response = session.post(url, headers=headers, json=payload, stream=True)
        
        # DETECTOR: Agar HTTP error aaye toh yahan print hoga
        if response.status_code != 200:
            return f"[Detector] API Error {response.status_code}: {response.text}"

        for line in response.iter_lines():
            if line:
                decoded = line.decode('utf-8')
                if decoded.startswith("data: "):
                    try:
                        chunk = json.loads(decoded[6:])
                        if "choices" in chunk and len(chunk["choices"]) > 0:
                            delta = chunk["choices"][0].get("delta", {})
                            if delta.get("phase") == "answer" and "content" in delta:
                                full_response += delta["content"]
                    except: pass
                    
        # DETECTOR: Agar server blank response de toh
        if not full_response:
            return "[Detector] Server ne 200 OK diya, par jawab khali tha. Shayad message ka format galat hai."
            
        return full_response
    except Exception as e:
        return f"[Error] Code Exception: {str(e)}"
