# Modular AI — Final Architecture Blueprint

## 1. Main idea in one line

USER → CHAT/API → MODEL PROFILE → INPUT GUARD → CONTEXT MANAGER → MEMORY/SUMMARY → ROOM ROUTER → ROOM LOADER → PROMPT COMPOSER → CORE MODEL → OUTPUT MANAGER → USER

## 2. What the system is

The project starts with a 1B Core model for testing.

The Core is the main language/interaction brain. Rooms add specialized capability or knowledge:

- Python / Coding
- Math
- Physics
- Biology
- Electronics
- Robotics
- other future rooms

The total future system may become very large, but the project does not need to build everything at once.

Only the rooms needed for the current task are loaded.

## 3. Final modules

### A. Chat/API Layer
The user-facing program talks to the model through this layer.

Responsibilities:
- receive user input
- start/load a session
- select the current model profile
- call the runtime
- return the answer

The UI is kept separate from the core architecture.

### B. Model Profile
Defines what the currently selected model can safely handle.

Example:
- parameter label: 1B
- actual model identifier
- context limit
- output limit
- tokenizer
- protocol
- model path/API endpoint

Important:
Parameter count does NOT determine context length.
The real context limit comes from the model/runtime.
The profile stores the real limit and our own safety budget.

### C. Input Guard
Checks incoming text before the model receives it.

Responsibilities:
- basic size check
- invalid/empty input handling
- request limits
- optional security/safety checks

### D. Context Manager
This is one of the most important modules.

It decides exactly what goes into the model request.

It controls:
- system instructions
- current user message
- relevant recent conversation
- conversation summary
- important exact facts
- selected room information
- output reservation
- total token budget

It NEVER blindly sends the entire conversation.

### E. Conversation Store
Stores the full conversation outside the active model context.

The full history remains available on disk/database even when it is not sent to the model.

### F. Summary Manager
When the conversation becomes too large, the system calls a model to create a compact summary.

The summary keeps:
- current goal
- decisions already made
- important facts
- active rooms
- unfinished tasks
- important exact references

Important exact data such as code/error text may be stored separately so a summary does not accidentally destroy it.

### G. Relevance Selector
Chooses which old information is actually needed for the current request.

This prevents irrelevant history from consuming context.

### H. Room Router
Determines which rooms are needed.

Examples:
- Python question → Python room
- Physics question → Physics room
- Python + Math → both rooms

The router can support:
1. automatic selection
2. manual selection later
3. hybrid selection

### I. Room Loader
Loads only the needed rooms.

Flow:
DISK → RAM → GPU/accelerator (when needed)

Unused rooms stay stored on disk.

### J. Room Types

A room is a logical module, not necessarily one fixed neural technology.

A room may contain:
- a small neural adapter
- knowledge files/indexes
- tools
- a specialized expert
- a combination of these

For the first prototype, keep rooms simple.

### K. Prompt Composer
Builds the final request sent to the Core.

Logical order:

SYSTEM
+ SUMMARY
+ IMPORTANT EXACT MEMORY
+ RELEVANT RECENT HISTORY
+ ROOM CONTEXT
+ CURRENT USER INPUT

The composer must stay below the model's real context limit.

### L. Model Runtime
One stable interface talks to the currently selected model.

The rest of the application should not care whether the model is:
1B → 2B → 3B → 7B → 10B

Only the runtime/profile changes.

### M. Output Manager
Controls:
- maximum output tokens
- response validation
- truncation handling
- streaming
- error handling

## 4. Context-window policy

The system uses a token budget.

Available context is conceptually:

TOTAL MODEL CONTEXT
= INPUT AREA + OUTPUT RESERVE

The input area is divided between:
- system instructions
- summary
- exact memory
- relevant history
- room context
- current user message

The system should leave an output reserve.

If the budget is exceeded:
1. remove low-value old history
2. compress old history into a summary
3. reduce optional room context
4. keep current user input
5. keep important exact memory
6. only then consider a hard failure

Never depend on the model to fix an oversized request by itself.

## 5. Model-size testing policy

The first prototype supports profiles from 1B to 10B.

These are TEST PROFILES, not a claim that parameter count determines context.

Example profile range:
- 1B
- 2B
- 3B
- 4B
- 5B
- 6B
- 7B
- 8B
- 9B
- 10B

Each profile contains its actual:
- context limit
- output limit
- tokenizer
- runtime settings

When a larger model is introduced, the application should not need to be redesigned.

## 6. Progressive training plan

Training is incremental.

Stage 1:
Train/test the 1B Core with a very small dataset.

Stage 2:
Verify basic language and simple interaction.

Stage 3:
Add a small Python room and test it.

Stage 4:
Add more rooms one at a time.

Stage 5:
Increase training data only when the current capability is stable.

Stage 6:
When better compute becomes available, move to larger models and/or larger room models.

The training pipeline should always keep the source datasets archived.

## 7. Important design rule

Do NOT assume:

parameter count = required dataset size

Do NOT assume:

parameter count = context length

Do NOT assume:

all knowledge must be stored inside neural parameters.

Use:
- parameters for learned behavior/capability
- external memory/knowledge for large reference information
- rooms for specialization
- tools for deterministic operations

## 8. Room lifecycle

NEW DATASET
→ DEDUPLICATION
→ QUALITY CHECK
→ DECIDE ROOM TYPE
→ TRAIN/INDEX
→ EVALUATE
→ PACKAGE
→ REGISTER
→ AVAILABLE FOR ROUTING

A room can later be:
- upgraded
- disabled
- rolled back
- replaced
- unloaded

## 9. Compatibility rule

Every room records:
- core version/hash
- interface version
- tokenizer compatibility
- room type
- dependencies
- dataset fingerprint
- evaluation result

This prevents an old room from silently being used with an incompatible Core.

## 10. 1B prototype scope

For the first test, keep it small:

Core:
- 1B model

Rooms:
- Python
- optionally Math

System:
- Model Profile
- Context Manager
- Conversation Store
- Summary Manager
- Room Router
- Room Loader
- Prompt Composer
- Model Runtime
- Output Manager

Do NOT build a huge UI first.
Get the runtime, context, and room flow working first.

## 11. Final architecture principle

The Core is stable.
The Rooms are replaceable/addable.
The Context Manager controls what reaches the Core.
The API/Runtime layer controls model-specific limits.
The full conversation stays outside the active context.
Only relevant information is sent to the model.
