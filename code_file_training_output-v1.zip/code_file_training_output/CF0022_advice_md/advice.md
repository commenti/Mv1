

---

§1 — module docstring (replace)

```python
# OLD
"""
cardgen / core/blocklist.py

High-security issuer prefix gate.
If a generated PAN starts with any blocked prefix, it is regenerated.
Blocked list lives in data/blocklist.json and is user-editable.
"""

# NEW
"""
cardgen / core/blocklist.py

High-security issuer prefix gate.
Sources (both optional, merged at construction):
  - data/blocklist.json    : explicit prefix entries (curated)
  - data/issuer_registry.json : augmented via a caller-supplied
                               blocked-issuer-name set (defunct,
                               merged, sanctioned, or manually flagged)

Match API unchanged: match(), is_blocked(), all_entries(), __len__.
New: is_issuer_blocked(name) for name-based lookups.
"""
```

---

§2 — imports (replace)

```python
# OLD
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

# NEW
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

# Path already imported — no other changes needed
```

---

§3 — BlockedEntry dataclass (add field)

```python
# OLD
@dataclass(frozen=True, slots=True)
class BlockedEntry:
    prefix: str
    issuer: str
    country: str
    network: str

# NEW — add source with default so existing constructors don't break
@dataclass(frozen=True, slots=True)
class BlockedEntry:
    prefix: str
    issuer: str
    country: str
    network: str
    source: str = "static"      # "static" | "registry"
```

---

§4 — Blocklist.__slots__ (replace)

```python
# OLD
__slots__ = ("_entries", "_by_len")

# NEW — add issuer index for name-based lookup
__slots__ = ("_entries", "_by_len", "_issuers")
```

---

§5 — Blocklist.__init__ (replace)

```python
# OLD
def __init__(self, entries: Iterable[BlockedEntry]) -> None:
    entries = tuple(entries)
    self._entries: tuple[BlockedEntry, ...] = entries
    bucket: dict[int, dict[str, BlockedEntry]] = {}
    for e in entries:
        bucket.setdefault(len(e.prefix), {})[e.prefix] = e
    self._by_len: dict[int, dict[str, BlockedEntry]] = bucket

# NEW — also build issuer-name index
def __init__(self, entries: Iterable[BlockedEntry]) -> None:
    entries = tuple(entries)
    self._entries: tuple[BlockedEntry, ...] = entries
    bucket: dict[int, dict[str, BlockedEntry]] = {}
    issuers: set[str] = set()
    for e in entries:
        bucket.setdefault(len(e.prefix), {})[e.prefix] = e
        issuers.add(e.issuer)
    self._by_len: dict[int, dict[str, BlockedEntry]] = bucket
    self._issuers: frozenset[str] = frozenset(issuers)
```

---

§6 — new classmethod from_sources (insert after from_json)

```python
# NEW — merges blocklist.json with registry-derived blocks
@classmethod
def from_sources(
    cls,
    blocklist_path: Path,
    registry_path: Path | None = None,
    blocked_issuer_names: Iterable[str] = (),
) -> "Blocklist":
    entries: list[BlockedEntry] = list(cls._read_blocklist_json(blocklist_path))

    if registry_path is not None and registry_path.exists():
        wanted = {str(n).strip() for n in blocked_issuer_names if str(n).strip()}
        if wanted:
            entries.extend(cls._registry_entries_for(registry_path, wanted))

    if not entries:
        raise ValueError("blocklist has no entries — refusing to run unguarded")
    return cls(entries)


@staticmethod
def _read_blocklist_json(path: Path) -> list[BlockedEntry]:
    if not path.exists():
        raise FileNotFoundError(f"blocklist json missing: {path}")
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise ValueError("blocklist.json must be a JSON array")
    out: list[BlockedEntry] = []
    for i, row in enumerate(raw):
        try:
            prefix = str(row["prefix"]).strip()
            if not prefix.isdigit():
                raise ValueError("prefix must be digits only")
            out.append(BlockedEntry(
                prefix=prefix,
                issuer=str(row["issuer"]),
                country=str(row["country"]),
                network=str(row["network"]).upper(),
                source="static",
            ))
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"blocklist.json[{i}] invalid: {exc}") from exc
    return out


@staticmethod
def _registry_entries_for(
    registry_path: Path,
    wanted_issuers: set[str],
) -> list[BlockedEntry]:
    raw = json.loads(registry_path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise ValueError("issuer_registry.json must be a JSON array")
    out: list[BlockedEntry] = []
    for row in raw:
        issuer = str(row.get("issuer", "")).strip()
        if issuer not in wanted_issuers:
            continue
        iin = str(row.get("iin", "")).strip()
        if not iin.isdigit() or len(iin) < 6:
            continue
        out.append(BlockedEntry(
            prefix=iin,                                 # full IIN as prefix
            issuer=issuer,
            country=str(row.get("country", "")),
            network=str(row.get("network", "")).upper(),
            source="registry",
        ))
    return out
```

---

§7 — from_json (replace with thin wrapper)

```python
# OLD — full body
@classmethod
def from_json(cls, path: Path) -> "Blocklist":
    ... (full body)

# NEW — keep for backward compat, route through _read_blocklist_json
@classmethod
def from_json(cls, path: Path) -> "Blocklist":
    entries = cls._read_blocklist_json(path)
    if not entries:
        raise ValueError("blocklist.json is empty — refusing to run unguarded")
    return cls(entries)
```

---

§8 — new method is_issuer_blocked (insert after is_blocked)

```python
# NEW
def is_issuer_blocked(self, issuer_name: str) -> bool:
    """True if this issuer name appears in any blocked entry."""
    return str(issuer_name).strip() in self._issuers
```

---

§9 — all_entries (replace)

```python
# OLD — 4 fields per row
return [
    {"prefix": e.prefix, "issuer": e.issuer,
     "country": e.country, "network": e.network}
    for e in self._entries
]

# NEW — include source
return [
    {"prefix": e.prefix, "issuer": e.issuer,
     "country": e.country, "network": e.network,
     "source": e.source}
    for e in self._entries
]
```

---

summary — file ke kaunse hisse badle

# Section Change
1 module docstring rewritten — two sources, new method
2 imports koi change nahi (already complete)
3 BlockedEntry + source field (default "static")
4 __slots__ + _issuers
5 __init__ build issuer-name index alongside prefix trie
6 from_sources + 2 helpers NEW — merge blocklist.json + registry by issuer name
7 from_json thin wrapper over _read_blocklist_json
8 is_issuer_blocked NEW — name-based lookup
9 all_entries expose source in output

jo nahi badla: match(), is_blocked(), __len__, _by_len lookup pattern.

BLOCKED_ISSUER_NAMES set — kahaan aayega? Do options:

· Option A: main.py mein constant rakho → Blocklist.from_sources(BL, REG, BLOCKED_ISSUER_NAMES)
· Option B: data/blocklist.json mein ek top-level _blocked_issuers: [...] key rakho, _read_blocklist_json use bhi padhe

Recommend Option B — ek hi file mein sab config. Bolo toh data/blocklist.json ka change spec bhi ship karta hoon (chhota hai, ~15 lines).


Title: data/blocklist.json — change spec (shape change + _blocked_issuers key)

---

§1 — top-level shape (replace)

```json
// OLD — plain array
[
  { "prefix": "34",   "issuer": "American Express", "country": "USA", "network": "AMEX" },
  ...
]

// NEW — object with two keys
{
  "_blocked_issuers": [
    "American Express Centurion",
    "Chase Sapphire",
    "Barclays Premier",
    "HSBC Premier",
    "Deutsche Bank Private",
    "RBC Avion"
  ],
  "entries": [
    { "prefix": "34",   "issuer": "American Express", "country": "USA", "network": "AMEX" },
    ...
  ]
}
```

---

§2 — _blocked_issuers (new key)

Names yahan issuer_registry.json ke issuer field se exact match hona chahiye. Blocklist.from_sources() inhe padhega aur registry mein matching IIN prefixes ko block kar dega.

Example list (issuer_registry.json ke naam se match):

```json
"_blocked_issuers": [
  "American Express Centurion"
]
```

Note: seed registry mein filhaal sirf "American Express Centurion" hi high-security issuer hai. Baaki naam (Chase/Barclays/HSBC) registry mein regular entries hain — unhe block nahi karna. Isliye list short rakhi.

---

§3 — entries (existing data, wrapped)

Pehle ka poora array ab entries key ke andar chala jaata hai. Content wahi — kuch nahi badla per entry.

---

§4 — core/blocklist.py ka _read_blocklist_json (patch — §6 se related)

_read_blocklist_json ab array ya object dono accept kare:

```python
# REPLACE the top of _read_blocklist_json
raw = json.loads(path.read_text(encoding="utf-8"))

if isinstance(raw, list):
    # legacy array form — still supported
    rows = raw
    blocked_issuers: list[str] = []
elif isinstance(raw, dict):
    rows = raw.get("entries", [])
    blocked_issuers = list(raw.get("_blocked_issuers", []))
    if not isinstance(rows, list):
        raise ValueError("blocklist.json 'entries' must be an array")
else:
    raise ValueError("blocklist.json must be an array or object")
```

Aur from_sources mein:

```python
# inside from_sources, before reading registry
entries, names_from_file = cls._read_blocklist_json(path)   # returns tuple now
all_blocked_names = set(blocked_issuer_names) | set(names_from_file)
```

_read_blocklist_json ab (entries, blocked_issuer_names) return kare.

---

summary — kaunse hisse badle

# Section Change
1 top-level shape array → object { "_blocked_issuers": [...], "entries": [...] }
2 _blocked_issuers NEW — issuer names jo registry se auto-block honge
3 entries existing array isi key ke andar wrap
4 core/blocklist.py §6 _read_blocklist_json array + object dono handle kare, tuple return kare
5 core/blocklist.py §6 from_sources file-derived names + caller names merge kare

legacy array form still works — jo file abhi disk pe hai, loader use bhi padh lega.

---

data/blocklist.json ka change chhota hai — bas pehli line [ ko { "_blocked_issuers": [...], "entries": [ se replace, aur aakhir mein ] ko ]} se. Bolo toh poora naya file bhi ship kar deta hoon ek shot mein, ya aise hi rehne do.
