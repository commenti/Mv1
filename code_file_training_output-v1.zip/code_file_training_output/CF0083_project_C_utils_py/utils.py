import html
import xml.etree.ElementTree as ET

def format_timestamp(seconds_float):
    """Converts seconds (float) to [HH:MM:SS] format."""
    seconds = int(seconds_float)
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    return f"[{h:02d}:{m:02d}:{s:02d}]"

def format_srt_timestamp(seconds_float):
    """Converts seconds to SRT format 00:00:00,000"""
    seconds = int(seconds_float)
    milliseconds = int((seconds_float - seconds) * 1000)
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d},{milliseconds:03d}"

def parse_xml_to_formats(xml_content):
    """
    Parses YouTube XML and returns a dictionary with all 3 formats.
    """
    try:
        root = ET.fromstring(xml_content)
        
        clean_lines = []
        timed_lines = []
        srt_lines = []
        
        counter = 1

        for i, text_node in enumerate(root.findall('text')):
            # Raw text content (decode HTML entities)
            raw_text = html.unescape(text_node.text) if text_node.text else ""
            raw_text = raw_text.replace('\n', ' ').strip()
            
            if not raw_text:
                continue

            start = float(text_node.get('start', 0))
            dur = float(text_node.get('dur', 0))
            end = start + dur

            # 1. Clean Text logic
            clean_lines.append(raw_text)

            # 2. Time-Stamped Logic (Business Requirement)
            time_tag = format_timestamp(start)
            timed_lines.append(f"{time_tag} {raw_text}")

            # 3. SRT Logic (Secondary)
            srt_block = (
                f"{counter}\n"
                f"{format_srt_timestamp(start)} --> {format_srt_timestamp(end)}\n"
                f"{raw_text}\n"
            )
            srt_lines.append(srt_block)
            counter += 1

        return {
            "clean": "\n".join(clean_lines),
            "timed": "\n".join(timed_lines),
            "srt": "\n".join(srt_lines)
        }
    except Exception as e:
        print(f"Error parsing XML: {e}")
        return None