import re
import requests
import xml.etree.ElementTree as ET

# --- Headers (Browser जैसा दिखने के लिए) ---
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.youtube.com/",
}

BASE_URL = "https://www.youtube.com/api/timedtext"

def extract_video_id(url: str):
    if not url: return None
    regex = r"(?:v=|\/v\/|youtu\.be\/|\/embed\/|\/shorts\/)([^#\&\?]*).*"
    match = re.search(regex, url)
    if match: return match.group(1)
    return None

def fetch_track_list(video_id: str):
    """
    REPORT STEP 4: Language List निकालना
    API: https://www.youtube.com/api/timedtext?v={id}&type=list
    """
    url = f"{BASE_URL}?v={video_id}&type=list"
    tracks = []
    
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        
        # Agar response XML hai, to parse karo
        if response.status_code == 200 and response.content:
            try:
                root = ET.fromstring(response.content)
                for track in root.findall('track'):
                    tracks.append({
                        'lang_code': track.get('lang_code'),
                        'name': track.get('name', track.get('lang_original', 'Unknown')),
                        'kind': track.get('kind', 'standard') # 'asr' means auto-generated
                    })
            except ET.ParseError:
                pass # XML valid nahi tha
    except Exception as e:
        print(f"List Error: {e}")

    # Fallback: Agar API list nahi deti (Shorts me aksar hota hai), 
    # to hum Default Options dikhayenge taaki user Manual Try kar sake.
    if not tracks:
        tracks = [
            {'lang_code': 'en', 'name': 'English (Auto/Manual)', 'kind': 'asr'},
            {'lang_code': 'hi', 'name': 'Hindi (Auto/Manual)', 'kind': 'asr'},
            {'lang_code': 'es', 'name': 'Spanish', 'kind': 'asr'}
        ]
            
    return tracks

def clean_xml_to_text(xml_content, format_type):
    """
    REPORT STEP 10: Server-side XML Parsing
    XML ko User-Friendly Text/SRT me badalna.
    """
    try:
        root = ET.fromstring(xml_content)
        lines = []
        
        for i, text_node in enumerate(root.findall('text')):
            # HTML Entities Fix (&amp;#39; -> ')
            raw_text = text_node.text or ""
            raw_text = raw_text.replace('&#39;', "'").replace('&quot;', '"').replace('&amp;', '&').strip()
            
            if not raw_text: continue
            
            start = float(text_node.get('start', 0))
            
            if format_type == 'clean':
                lines.append(raw_text)
            
            elif format_type == 'timed':
                # Seconds to [HH:MM:SS]
                m, s = divmod(int(start), 60)
                h, m = divmod(m, 60)
                lines.append(f"[{h:02d}:{m:02d}:{s:02d}] {raw_text}")
            
            elif format_type == 'srt':
                # SRT Format Calculation
                dur = float(text_node.get('dur', 0))
                end = start + dur
                def t(sec):
                    ms = int((sec % 1) * 1000)
                    s = int(sec)
                    m, s = divmod(s, 60)
                    h, m = divmod(m, 60)
                    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
                lines.append(f"{i+1}\n{t(start)} --> {t(end)}\n{raw_text}\n")
                
        separator = " " if format_type == 'clean' else "\n"
        return separator.join(lines)
        
    except Exception as e:
        print(f"XML Parse Error: {e}")
        return None

def download_captions(video_id: str, target_lang: str, format_type: str = 'clean'):
    """
    REPORT STEP 2 & 8: Direct API Download
    API: https://www.youtube.com/api/timedtext?v={id}&lang={lang}&fmt=srv1
    """
    print(f"DEBUG: Direct API Request -> ID: {video_id} | Lang: {target_lang}")
    
    # Hum 2 URL try karenge:
    # 1. Standard (Manual)
    # 2. ASR (Auto-generated) - Report point #8
    
    urls_to_try = [
        # Priority 1: Manual Caption
        f"{BASE_URL}?v={video_id}&lang={target_lang}&fmt=srv1",
        # Priority 2: Auto-Generated (kind=asr)
        f"{BASE_URL}?v={video_id}&lang={target_lang}&kind=asr&fmt=srv1"
    ]

    for url in urls_to_try:
        try:
            print(f"🔗 Trying: {url}")
            res = requests.get(url, headers=HEADERS, timeout=10)
            
            # Check: Status 200 AND Content hona chahiye (Report point #9)
            if res.status_code == 200 and res.content:
                if "<transcript>" in res.text or "<text" in res.text:
                    print("✅ Valid XML Received!")
                    
                    # XML Parse karo
                    final_content = clean_xml_to_text(res.text, format_type)
                    
                    if final_content:
                        return final_content, target_lang
                    else:
                        print("⚠️ XML Parsing Failed.")
                else:
                    print("⚠️ Response empty or invalid format.")
            else:
                print(f"⚠️ Failed. Status: {res.status_code}")
                
        except Exception as e:
            print(f"Connection Error: {e}")

    # Agar Direct fail hua, aur user ne 'en' manga tha, 
    # to ek bar 'a.en' (legacy code) try kar lete hain
    if not target_lang.startswith('a.'):
        print("🔄 Trying legacy code variant...")
        return download_captions(video_id, f"a.{target_lang}", format_type)

    return None, None
