import os
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.base import BaseHTTPMiddleware
from pydantic import BaseModel
import logging

# MODULES
import security
import engine 

logging.basicConfig(level=logging.INFO)
app = FastAPI(title="Subtitle Intelligence Platform")

# SECURITY MIDDLEWARE
@app.middleware("http")
async def security_middleware(request: Request, call_next):
    if hasattr(security, 'is_ip_banned'):
        if security.is_ip_banned(request.client.host):
            return JSONResponse(status_code=403, content={"error": "Banned"})
    return await call_next(request)

templates = Jinja2Templates(directory="frontend")

class AnalyzeRequest(BaseModel):
    url: str

class DownloadRequest(BaseModel):
    video_id: str
    lang: str = None      
    lang_code: str = None 
    format: str = None    
    format_type: str = None 

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/api/analyze")
async def analyze_video(request: Request, data: AnalyzeRequest):
    print(f"DEBUG: Analyzing URL: {data.url}")
    video_id = engine.extract_video_id(data.url)
    if not video_id:
        raise HTTPException(status_code=400, detail="Invalid YouTube URL")

    # Step 4 from Report: Fetch List
    tracks = engine.fetch_track_list(video_id)
    
    available = []
    for t in tracks:
        available.append({
            "code": t['lang_code'], 
            "label": t['name'],
            "is_auto": t.get('kind') == 'asr'
        })
        
    return {"video_id": video_id, "languages": available}

@app.post("/api/download")
async def download_subtitle(data: DownloadRequest):
    target_lang = data.lang if data.lang else data.lang_code or 'en'
    target_format = data.format if data.format else data.format_type or 'clean'
    
    print(f"DEBUG: Request - ID: {data.video_id}, Lang: {target_lang}, Format: {target_format}")

    # Direct API Call
    content, found_lang = engine.download_captions(data.video_id, target_lang, target_format)
    
    if not content:
        print("❌ Download returned None")
        raise HTTPException(status_code=404, detail="Captions not found or API blocked.")

    # Save File
    os.makedirs("data", exist_ok=True)
    ext = 'srt' if target_format == 'srt' else 'txt'
    filename = f"caption_{data.video_id}_{found_lang}.{ext}"
    filepath = os.path.join("data", filename)
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
        
    return FileResponse(path=filepath, filename=filename, media_type='application/octet-stream')

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
